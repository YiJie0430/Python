import os,time,traceback
from testlibs import *
from toolslib import *
from htx import Win32Message
import wx
import random
from NIWTS import *
from LibFun import *

execfile("config.ini")
execfile("IQ_DUT.ini")






def TxVerifyDVT(parent,ni,dut_id,term,chip_type,interface,cal_freq,AntChOffsetTab,log): 
    test_time = time.time()
    parent.SendMessage(dut_id,"%s Tx verify Start...\n"%chip_type ,log)
    
    testfail = 0
    bw_delta = 0
    pwrfail = 0
    #samplingTimeSecs=0.00017
    port=dut_id+1
    if cal_freq == "2G": 
        extAttenDb=SearchPathLossTable(AntChOffsetTab,0,1)
        #TX_Gain = Get2GPower(parent,dut_id,term,chip_type,interface,log)
    else: 
        extAttenDb=SearchPathLossTable(AntChOffsetTab,36,1)
                
    triggerLevelDb=-25.0
    result={}
    freqOffset = GetOffset(term,chip_type,interface)
    TargetPower_Offset = Tx_Power_Offset[cal_freq]
    if cal_freq == '5G': Tx_verify_mode_bw_rate = Tx_parameter_5G
    else: Tx_verify_mode_bw_rate = Tx_parameter_2G
    #bw_name = {2:"HT20",3:"HT40",4:"VHT20",5:"VHT40",6:"VHT40"}
    count = 0
    for mod in Tx_verify_mode_bw_rate.keys():
        for bwide in Tx_verify_mode_bw_rate[mod][0].keys(): 
            modbw = mod + bwide                 
            for channel in Tx_verify_mode_bw_rate[mod][0][bwide]:
                Verify_Power = chip_prameter_dic[chip_type][3][1][modbw]
                if cal_freq == '5G':                                              
                    rfFreqHz=(5180+(channel-36)*5)*1000000
                    rfFreqMHz=(5180+(channel-36)*5)
                else:
                    rfFreqHz=(2412+(channel-1)*5)*1000000 
                    rfFreqMHz=(2412+(channel-1)*5)
                for mcs in Tx_verify_mode_bw_rate[mod][1]:
                    if mod < 2: rate_name = packet_name[mod][mcs]
                    else: rate_name = "%s_MCS%d"%(bw_name[modbw],mcs)   
                    for ant in dvt_verify_ant[cal_freq]:
                        
                        print mod,bwide,mcs,ant,channel
                        cable_loss = SearchPathLossTable(AntChOffsetTab,ant,channel)
                        print cable_loss 
                        cable_compensation = cable_loss + connector_loss[ant][cal_freq]
                        Evm_top = packet_dic[rate_name][5]
                        ni_bw = packet_dic[rate_name][2] 
                        ni_mode = packet_dic[rate_name][6]
                        count+=1
                            
       
        
        
                        parent.SendMessage(dut_id,"\n",log)
                        parent.SendMessage(dut_id,"%d.%s , Path Loss: %.2f + %.2f\n"%(count,"IQ_VERIFY_TX",cable_loss,connector_loss[ant][cal_freq]),log)
                        parent.SendMessage(dut_id,"----------------------------------------------------------------------------------------------------\n",log)
                        #parent.SendMessage("freqOffset=%d , Full Packet=%d\n"%(freqOffset,fpkt_dic[mode]),log)
                        parent.SendMessage(dut_id,"freqOffset=%d\n"%(freqOffset),log)
                        
                        msg_log = "%s , ch%s , %s, TX%d , "%("IQ_VERIFY_TX",channel,rate_name,ant)  
                        
                       
                        ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode,0,Verify_Power,fpkt_dic[mod])
                        lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)  #Stop AP function and enter ATE Command mode.
                        lWaitCmdTerm(term,"iwpriv %s set ATETXMODE=%d"%(interface,mod),promp,5)     
                        lWaitCmdTerm(term,"iwpriv %s set ATETXMCS=%d"%(interface,mcs),promp,5)    
                        lWaitCmdTerm(term,"iwpriv %s set ATETXBW=%d"%(interface,bwide),promp,5)
                        lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,40),promp,5)
                          
                        retry_flag = 1
                        retry_num = 0
                        while (retry_flag>0) and  (retry_num<TX_RETRY_TIMES):
                            retry_flag = 0
                            retry_num += 1
                            lWaitCmdTerm(term,"iwpriv %s set ATETXANT=%d"%(interface,ant+1),promp,5)
                            lWaitCmdTerm(term,"iwpriv %s set ATETXPOW%d=%d"%(interface,ant,34),promp,5)
                            lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%d"%(interface,channel),promp,5)
                            lWaitCmdTerm(term,"iwpriv %s set ATE=TXFRAME"%interface,promp,5)
                            #time.sleep(0.1)
                            if chip_type == 'MT7615': time.sleep(0.5) 
                            #result = ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode)
                            result=ni.RFSARead() 
                            if not result:
                                retry_flag+=1
                                if retry_num >=TX_RETRY_TIMES: raise Except ("%s Tx measure signal FAIL"%chip_type)
                                print "retry %d ......"%retry_num 
                                continue
                             
                            
                            Evm_msg= msg_log + "Evm = %.3f (%.2f~%.2f) dB"%(result["EVM"],Evm_top,Evm_low)
                            if result["EVM"]<Evm_low or result["EVM"]>Evm_top:
                                Evm_msg=Evm_msg+"   Fail"
                                retry_flag += 1
                            result["FreqErr"] =(result["FreqErr"]/rfFreqHz)*1000000
                            Freq_msg= msg_log + "Freq Err = %.2f (%.2f~%.2f) ppm"%(result["FreqErr"],(FREQ_AVG+FREQ_ERROR_LIMIT),(FREQ_AVG-FREQ_ERROR_LIMIT))
                            if abs(result["FreqErr"]-FREQ_AVG)>FREQ_ERROR_LIMIT:
                                Freq_msg=Freq_msg+"   Fail"
                                retry_flag += 1
                                     
                            Power_msg= msg_log + "Power = %.3f (%.2f~%.2f) dBm"%(result["Power"],Verify_Power+TargetPower_Offset,Verify_Power-TargetPower_Offset)
                            if abs(result["Power"]-Verify_Power)>TargetPower_Offset:
                                #if int(packet_dic[msg[2]][1]) == 2:
                                if result["Power"] < (Verify_Power - TargetPower_Offset): pwrfail+=1
                                Power_msg=Power_msg+"   Fail"
                                retry_flag += 1
                            Mask_msg= msg_log + "Spec Mask = %.3f (%.2f~%.2f) Percent"%(result["Mask"],Mask_top,Mask_low)
                            if result["Mask"]<Mask_low or result["Mask"]>Mask_top:
                                Mask_msg=Mask_msg+"   Fail"
                                retry_flag += 1
                            #print Spec Flat and LO Leakage
                            if mod==1:
                                Flat_msg= msg_log + "Spec Flat = %.3f (%.2f~%.2f) pt"%(result["Flatness"],Flat_top,Flat_low)
                                if result["Flatness"]<Flat_low or result["Flatness"]>Flat_top:
                                    Flat_msg=Flat_msg+"   Fail"
                                    retry_flag += 1
                                    
                                LO_msg= msg_log + "LO Leakage = %.3f (%.2f~%.2f) dB"%(result["LoLeakage"],LO_Leakage_top,LO_Leakage_low)
                                if result["LoLeakage"]<LO_Leakage_low or result["LoLeakage"]>LO_Leakage_top:
                                    LO_msg=LO_msg+"   Fail"
                                    retry_flag += 1
                                    
                            if retry_flag==0 or retry_num==TX_RETRY_TIMES :
                                for msg in [Freq_msg,Evm_msg,Power_msg,Mask_msg]:
                                    if "Fail" in msg:
                                        testfail=testfail+1
                                        parent.SendMessage(dut_id,msg + "\n",log,color=1)
                                    else:
                                        parent.SendMessage(dut_id,msg + "\n",log,color=2)
                  
                                if mod==1:
                                    for msg in [Flat_msg,LO_msg]:
                                        if "FAIL" in msg:
                                            testfail=testfail+1
                                            parent.SendMessage(dut_id,msg + "\n",log,color=1)
                                        else:
                                            parent.SendMessage(dut_id,msg + "\n",log,color=2)
        #if (dut_id == 1 and mode == 2): raw_input("pause")  
        #lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTOP"%interface,promp,5)
    if testfail > 0 or result == 0: raise Except ("%s Tx verify FAIL"%chip_type) 
    parent.SendMessage(dut_id, "%s Tx verify Test time: %3.2f (sec)\n"%(chip_type,(time.time()- test_time)) ,log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------\n",log)     
    

def RxVerifyDVT(parent,ni,dut_id,term,chip_type,interface,cal_freq,AntChOffsetTab,log):
    test_time = time.time()
    parent.SendMessage(dut_id,"%s Rx Verify Start...\n"%chip_type,log)   
    port=dut_id+1  #When set to 2 even though the cable is connected to the 2,it won't get the packets.
            #Pehaps it is the bug of the API.
    testfail = 0
    
    if 0: #if chip_type == 'MT7612':
        lWaitCmdTerm(term,"ifconfig %s down"%interface,"forwarding state",5)
        term.get()
        #lWaitCmdTerm(term,"ifconfig %s up"%interface,"forwarding state",20)
        lWaitCmdTerm(term,"ifconfig %s up"%interface,"entering learning state",20)
        lWaitCmdTerm(term,"","#",5)
        SetWifiDefault(term,interface)
  
    freqOffset = GetOffset(term,chip_type,interface)
    if cal_freq == '5G': Rx_verify_mode_bw_rate = Rx_parameter_5G
    else: Rx_verify_mode_bw_rate = Rx_parameter_2G
    #for i in range(len(print_flow[cal_freq])):
    count = 0
    for mod in Rx_verify_mode_bw_rate.keys():
        for bwide in Rx_verify_mode_bw_rate[mod][0].keys(): 
            modbw = mod + bwide 
            if mod ==2: rx_mode = mod + bwide
            elif mod ==4: rx_mode = mod + bwide - 2
            else: rx_mode = mod  
                            
            for channel in Rx_verify_mode_bw_rate[mod][0][bwide]:
                if cal_freq == '5G':                         
                    rfFreqHz=(5180+(channel-36)*5)*1000000
                    rfFreqMHz=(5180+(channel-36)*5)
                else: 
                    rfFreqHz=(2412+(channel-1)*5)*1000000 
                    rfFreqMHz=(2412+(channel-1)*5)
                for mcs in Rx_verify_mode_bw_rate[mod][1]:
                    if mod < 2: rate_name = packet_name[mod][mcs]
                    else: rate_name = "%s_MCS%d"%(bw_name[modbw],mcs)   
                    for ant in dvt_verify_ant[cal_freq]:
                        
                        print mod,bwide,mcs,ant,channel
                        cable_loss = SearchPathLossTable(AntChOffsetTab,ant,channel)
                        print cable_loss 
                        cable_compensation = cable_loss + connector_loss[ant][cal_freq]
                        ni_bw = packet_dic[rate_name][2] 
                        ni_mode = packet_dic[rate_name][6]
                        ni_rate = packet_dic[rate_name][7]                        
                        count+=1
            
                                
                        retry_flag = 1
                        retry_num = 0        
                        
                        lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,7)
                        lWaitCmdTerm(term,"iwpriv %s set ResetCounter=0"%interface,promp,7)
                        lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,freqOffset),promp,10)
                        lWaitCmdTerm(term,"iwpriv %s set ATETXMODE=%d"%(interface,mod),promp,7)
                        lWaitCmdTerm(term,"iwpriv %s set ATETXMCS=%d"%(interface,mcs),promp,7)
                        lWaitCmdTerm(term,"iwpriv %s set ATETXBW=%s"%(interface,bwide),promp,7)
                        lWaitCmdTerm(term,"iwpriv %s set ATERXANT=%d"%(interface,ant+1),promp,7)        
                        lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%s"%(interface,channel),promp,7)
                        
                        parent.SendMessage(dut_id,"\n",log)        
                        parent.SendMessage(dut_id,"%d.%s , Path Loss: %.2f + %.2f\n"%(count,"IQ_VERIFY_RX",cable_loss,connector_loss[ant][cal_freq]),log)
                        parent.SendMessage(dut_id,"----------------------------------------------------------------------------------------------------\n",log)
                        rx_attn = rfPower_dic[rx_mode][mcs] 
                        log_msg = "%s , ch%s , %s , RX%s , %d dB, "%("IQ_VERIFY_RX",channel,rate_name,ant,rx_attn)        
                        while (retry_flag==1 and retry_num<PER_RETRY_TIMES):
                            retry_num += 1 
         
                            lWaitCmdTerm(term,"iwpriv %s set ATE=RXFRAME"%interface,promp,7)
                            lWaitCmdTerm(term,"",promp,7)
                            #print rfFreqMHz,cable_compensation,ni_bw,ni_mode,ni_rate,rfPower_dic[rx_mode]
                            #raw_input("####################")
                            ni.RFGenerate(rfFreqMHz,cable_compensation,ni_bw,ni_mode,ni_rate,rfPower_dic[rx_mode][mcs])
                            time.sleep(packet_dic[rate_name][3]) #The important delay 
                            Per_top = packet_dic[rate_name][4] 
                            for j in range(3):
                                try:
                                    data=lWaitCmdTerm(term,"iwpriv %s stat"%interface,promp,7)
                                    #print data 
                                    pat = r"Rx success\s+..\d+"
                                    pat_=r"=.\d+"
                                    result = int(find(pat_,find(pat,data))[2:])
                                    Per=((1000-result)/1000.0)*100.0
                                    if Per<= Per_top:
                                        break     
                                    time.sleep(0.1)
                                except ValueError:
                                    print "Try %d check %s stat"%(i,interface)
                                    
                            lWaitCmdTerm(term,"iwpriv %s set ResetCounter=0"%interface,promp,7)  
                            Per_msg= log_msg + "PER = %.3f (%.1f ~ 0.0) Percent"%(Per,Per_top)
                            if Per>Per_top:
                                Per_msg=Per_msg+"         Fail"
                            else:
                                retry_flag = 0
                
                            if retry_flag==0 or retry_num==PER_RETRY_TIMES:
                                if "Fail" in Per_msg:
                                    parent.SendMessage(dut_id,Per_msg+ "\n",log,color=1)
                                    testfail+=1
                                    print mod_path
                                    #raw_input("pause")
                                else:
                                    parent.SendMessage(dut_id,Per_msg + "\n",log,color=2)
    lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTOP"%interface,promp,5)
    parent.SendMessage(dut_id,"\n")
    if testfail > 0: raise Except ("%s Rx Verify FAIL..."%chip_type) 
    parent.SendMessage(dut_id, "%s Rx Verify Test time: %3.2f (sec)\n"%(chip_type,(time.time()- test_time)) ,log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------\n",log)   
    return testfail

def RxSweep(parent,ni,dut_id,term,chip_type,interface,cal_freq,AntChOffsetTab,log):
    test_time = time.time()
    parent.SendMessage(dut_id,"%s Rx Verify Start...\n"%chip_type,log)   
    port=dut_id+1  #When set to 2 even though the cable is connected to the 2,it won't get the packets.
            #Pehaps it is the bug of the API.
    
  
    freqOffset = GetOffset(term,chip_type,interface)
    if cal_freq == '5G': Rx_verify_mode_bw_rate = Rx_parameter_5G
    else: Rx_verify_mode_bw_rate = Rx_parameter_2G
    #for i in range(len(print_flow[cal_freq])):
    count = 0
    for mod in Rx_verify_mode_bw_rate.keys():
        for bwide in Rx_verify_mode_bw_rate[mod][0].keys(): 
            modbw = mod + bwide 
            if mod ==2: rx_mode = mod + bwide
            elif mod ==4: rx_mode = mod + bwide - 2
            else: rx_mode = mod  
                            
            for channel in Rx_verify_mode_bw_rate[mod][0][bwide]:
                if cal_freq == '5G':                         
                    rfFreqHz=(5180+(channel-36)*5)*1000000
                    rfFreqMHz=(5180+(channel-36)*5)
                else: 
                    rfFreqHz=(2412+(channel-1)*5)*1000000 
                    rfFreqMHz=(2412+(channel-1)*5)
                for mcs in Rx_verify_mode_bw_rate[mod][1]:
                    if mod < 2: rate_name = packet_name[mod][mcs]
                    else: rate_name = "%s_MCS%d"%(bw_name[modbw],mcs)   
                    for ant in dvt_verify_ant[cal_freq]:
                        
                        print mod,bwide,mcs,ant,channel
                        cable_loss = SearchPathLossTable(AntChOffsetTab,ant,channel)
                        print cable_loss 
                        cable_compensation = cable_loss + connector_loss[ant][cal_freq]
                        ni_bw = packet_dic[rate_name][2] 
                        ni_mode = packet_dic[rate_name][6]
                        ni_rate = packet_dic[rate_name][7]                        
                        count+=1
            
                                
                        retry_flag = 1
                        retry_num = 0        
                        
                        lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,7)
                        lWaitCmdTerm(term,"iwpriv %s set ResetCounter=0"%interface,promp,7)
                        lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,freqOffset),promp,10)
                        lWaitCmdTerm(term,"iwpriv %s set ATETXMODE=%d"%(interface,mod),promp,7)
                        lWaitCmdTerm(term,"iwpriv %s set ATETXMCS=%d"%(interface,mcs),promp,7)
                        lWaitCmdTerm(term,"iwpriv %s set ATETXBW=%s"%(interface,bwide),promp,7)
                        lWaitCmdTerm(term,"iwpriv %s set ATERXANT=%d"%(interface,ant+1),promp,7)        
                        lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%s"%(interface,channel),promp,7)
                        
                        parent.SendMessage(dut_id,"\n",log)        
                        parent.SendMessage(dut_id,"%d.%s , Path Loss: %.2f + %.2f\n"%(count,"IQ_VERIFY_RX",cable_loss,connector_loss[ant][cal_freq]),log)
                        parent.SendMessage(dut_id,"----------------------------------------------------------------------------------------------------\n",log)
                        rx_attn = rfPower_dic[rx_mode][mcs] 
                        
                        PER_RETRY_TIMES = 10
                        testfail = 0
                        #db_step = 5      
                        while (retry_flag==1 and retry_num<PER_RETRY_TIMES):
                            retry_num += 1 
                            log_msg = "%s , ch%s , %s , RX%s , %d dB, "%("IQ_VERIFY_RX",channel,rate_name,ant,rx_attn) 
                            lWaitCmdTerm(term,"iwpriv %s set ATE=RXFRAME"%interface,promp,7)
                            lWaitCmdTerm(term,"",promp,7)
                            #print rfFreqMHz,cable_compensation,ni_bw,ni_mode,ni_rate,rfPower_dic[rx_mode]
                            #raw_input("####################")
                            ni.RFGenerate(rfFreqMHz,cable_compensation,ni_bw,ni_mode,ni_rate,rx_attn)
                            time.sleep(packet_dic[rate_name][3]) #The important delay 
                            Per_top = packet_dic[rate_name][4] 
                            for j in range(1):
                                try:
                                    data=lWaitCmdTerm(term,"iwpriv %s stat"%interface,promp,7)
                                    #print data 
                                    pat = r"Rx success\s+..\d+"
                                    pat_=r"=.\d+"
                                    result = int(find(pat_,find(pat,data))[2:])
                                    Per=((1000-result)/1000.0)*100.0
                                    if Per<= Per_top:
                                        break     
                                    time.sleep(0.1)
                                except ValueError:
                                    print "Try %d check %s stat"%(i,interface)
                                    
                            lWaitCmdTerm(term,"iwpriv %s set ResetCounter=0"%interface,promp,7)  
                            Per_msg= log_msg + "PER = %.3f (%.1f ~ 0.0) Percent"%(Per,Per_top)
                            if Per>Per_top:
                                Per_msg=Per_msg+"         Fail"
                                rx_attn += 1
                                #rx_attn = rx_attn+db_step 
                                #db_step = int(round(db_step/2.0))
                                #if db_step ==0: db_step=1 
                                parent.SendMessage(dut_id,Per_msg+ "\n",log)
                                testfail+=1
                            else:
                                rx_attn = rx_attn-1
                                #rx_attn = rx_attn-db_step
                                if testfail > 0:
                                    Per_msg=Per_msg+"         Pass"
                                    parent.SendMessage(dut_id,Per_msg+ "\n",log,color=2) 
                                    break
                                else:
                                    parent.SendMessage(dut_id,Per_msg+ "\n",log)
                                    #retry_flag = 0
                            
                            #if retry_num==PER_RETRY_TIMES:
                            #    if "Fail" in Per_msg:
                            #        parent.SendMessage(dut_id,Per_msg+ "\n",log,color=1)
                            #        testfail+=1
                            #        print mod_path
                                    #raw_input("pause")
                                #else:
                                #    parent.SendMessage(dut_id,Per_msg + "\n",log,color=2)
    lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTOP"%interface,promp,5)
    parent.SendMessage(dut_id,"\n")
    if testfail > 0: raise Except ("%s Rx Verify FAIL..."%chip_type) 
    parent.SendMessage(dut_id, "%s Rx Verify Test time: %3.2f (sec)\n"%(chip_type,(time.time()- test_time)) ,log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------\n",log)   
    return testfail