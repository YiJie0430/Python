# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Jun 30 2011)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx,time,threading
import wx.xrc,wxMPL
#import inspect
from toolslib import *
from LibFun import *
from htx import Win32Message
from NIWTS import *
execfile('config.ini')
execfile('IQ_DUT.ini')
if os.path.isfile('parameter.ini'):
    execfile('parameter.ini')

logPath = os.getcwd() + "\\Station.Cal"
if not os.path.isdir(logPath):
   os.system("mkdir %s"%logPath)

iq_init = 0
###########################################################################
## Class MyFrame4
###########################################################################

class PathCalGui ( wx.Frame ):
    def __init__( self, parent ):
        self.TxtTx = [None,None,None,None]
        wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"Path Loss Calibration", pos = wx.DefaultPosition, size = wx.Size( 630,570 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
        self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
        self.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_INACTIVECAPTION ) )
        bSizer1000 = wx.BoxSizer( wx.VERTICAL )
        bSizer1100 = wx.BoxSizer( wx.HORIZONTAL )
        sbSizer1110 = wx.StaticBoxSizer( wx.StaticBox( self, wx.ID_ANY, u"Config" ), wx.VERTICAL )
        bSizer1111 = wx.BoxSizer( wx.HORIZONTAL )
        self.LblAntenna = wx.StaticText( self, wx.ID_ANY, u"Antenna Select", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.LblAntenna.Wrap( -1 )
        bSizer1111.Add( self.LblAntenna, 0, wx.ALL, 5 )
        bSizer1111.AddSpacer( ( 48, 0), 0, wx.EXPAND, 5 )
        CboAnttenaChoices = []
        #self.CboAnttena = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, CboAnttenaChoices, 0 )
        self.CboAnttena = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 120,-1 ), CboAnttenaChoices, 0 )
        bSizer1111.Add( self.CboAnttena, 0, wx.ALL, 5 )
        sbSizer1110.Add( bSizer1111, 1, 0, 5 )
        
        bSizer11131 = wx.BoxSizer( wx.HORIZONTAL )
        self.LblAntenna1 = wx.StaticText( self, wx.ID_ANY, u"Frequency Select", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.LblAntenna1.Wrap( -1 )
        bSizer11131.Add( self.LblAntenna1, 0, wx.ALL, 5 )
        bSizer11131.AddSpacer( ( 38, 0), 0, wx.EXPAND, 5 )
        FreqCboChoices = [ u"2G", u"5G"]
        self.FreqCbo = wx.ComboBox( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, FreqCboChoices, 0 )
        bSizer11131.Add( self.FreqCbo, 1, wx.ALL, 5 )
        sbSizer1110.Add( bSizer11131, 1, wx.EXPAND, 5 )
        
        bSizer1112 = wx.BoxSizer( wx.HORIZONTAL )
        self.LblTx0 = wx.StaticText( self, wx.ID_ANY, u"Channels", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.LblTx0.Wrap( -1 )
        bSizer1112.Add( self.LblTx0, 0, wx.ALL, 5 )
        bSizer1112.AddSpacer( ( 10, 0), 0, wx.EXPAND, 5 )
        self.TxtTx[0] = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer1112.Add( self.TxtTx[0], 1, wx.ALL, 5 )
        sbSizer1110.Add( bSizer1112, 1, wx.EXPAND, 5 )
        bSizer1113 = wx.BoxSizer( wx.HORIZONTAL )
        '''
        self.LblTx1 = wx.StaticText( self, wx.ID_ANY, u"Tx1 Channels", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.LblTx1.Wrap( -1 )
        bSizer1113.Add( self.LblTx1, 0, wx.ALL, 5 )
        bSizer1113.AddSpacer( ( 10, 0), 0, wx.EXPAND, 5 )
        self.TxtTx[1] = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer1113.Add( self.TxtTx[1], 1, wx.ALL, 5 )
        sbSizer1110.Add( bSizer1113, 1, wx.EXPAND, 5 )
        bSizer1114 = wx.BoxSizer( wx.HORIZONTAL )
        self.LblTx2 = wx.StaticText( self, wx.ID_ANY, u"Tx2 Channels", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.LblTx2.Wrap( -1 )
        bSizer1114.Add( self.LblTx2, 0, wx.ALL, 5 )
        bSizer1114.AddSpacer( ( 10, 0), 0, wx.EXPAND, 5 )
        self.TxtTx[2] = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer1114.Add( self.TxtTx[2], 1, wx.ALL, 5 )
        sbSizer1110.Add( bSizer1114, 1, wx.EXPAND, 5 )
        '''
        sbSizer1110.AddSpacer( ( 0, 10), 0, wx.EXPAND, 5 )
        
        bSizer11141 = wx.BoxSizer( wx.HORIZONTAL )
        self.save_btn = wx.Button( self, wx.ID_ANY, u"SAVE", wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer11141.Add( self.save_btn, 0, wx.ALL, 5 )
        sbSizer1110.Add( bSizer11141, 0, wx.ALIGN_CENTER_HORIZONTAL, 5 )
        
        bSizer1100.Add( sbSizer1110, 0, 0, 5 )
        sbSizer1120 = wx.StaticBoxSizer( wx.StaticBox( self, wx.ID_ANY, u"Diagram" ), wx.VERTICAL )
        self.BtmDiagram = wx.StaticBitmap( self, wx.ID_ANY, wx.Bitmap( u"Icon/WTS_pathcal.jpg", wx.BITMAP_TYPE_ANY ), wx.DefaultPosition, wx.DefaultSize, 0 )
        sbSizer1120.Add( self.BtmDiagram, 0, wx.ALL, 5 )
        bSizer1100.Add( sbSizer1120, 0, wx.EXPAND, 5 )
        bSizer1000.Add( bSizer1100, 0, 0, 5 )
        bSizer1200 = wx.BoxSizer( wx.VERTICAL )
        self.m_staticline3 = wx.StaticLine( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.LI_HORIZONTAL )
        bSizer1200.Add( self.m_staticline3, 0, wx.EXPAND |wx.ALL, 5 )
        bSizer1210 = wx.BoxSizer( wx.HORIZONTAL )
        self.Btn_ExtendLoss = wx.Button( self, wx.ID_ANY, u"Extend Cable Loss", wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer1210.Add( self.Btn_ExtendLoss, 0, wx.ALL, 5 )
        self.BtnRun = wx.Button( self, wx.ID_ANY, u"RUN", wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer1210.Add( self.BtnRun, 0, wx.ALL, 5 )
        bSizer1210.AddSpacer( ( 20, 0), 0, wx.EXPAND, 5 )
        self.LblMessage = wx.StaticText( self, wx.ID_ANY, u"Message....", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.LblMessage.Wrap( -1 )
        self.LblMessage.SetForegroundColour( wx.Colour( 0, 0, 255 ) )
        bSizer1210.Add( self.LblMessage, 1, wx.ALL|wx.EXPAND, 5 )
        bSizer1200.Add( bSizer1210, 0, wx.EXPAND, 5 )
        self.m_staticline4 = wx.StaticLine( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.LI_HORIZONTAL )
        bSizer1200.Add( self.m_staticline4, 0, wx.EXPAND |wx.ALL, 5 )
        bSizer1000.Add( bSizer1200, 0, wx.EXPAND, 5 )
        
        self.MPL = wxMPL.MPL_Panel_base(self)
        bSizer23 = wx.BoxSizer( wx.VERTICAL )
        bSizer23.Add(self.MPL,proportion =-10, border = 2,flag = wx.ALL | wx.EXPAND)
        bSizer1000.Add( bSizer23, 1, wx.EXPAND, 5 )

        self.SetSizer( bSizer1000 )
        self.Layout()
        self.Centre( wx.BOTH )
        # Connect Events 
        #self.IQiniBtn.Enable(False)
        self.save_btn.Bind( wx.EVT_BUTTON, self.SaveIni)
        self.FreqCbo.Bind( wx.EVT_COMBOBOX, self.SelectFreqType )
        self.Btn_ExtendLoss.Bind( wx.EVT_BUTTON, self.ExtendCalibrate)
        self.BtnRun.Bind( wx.EVT_BUTTON, self.RunCalibrate)
        self.init()
        
        #self.SaveIni()
       

    def init(self):
        #self.IQiniBtn.Hide()
        self.CboAnttena.Clear()
        for item in ant_list:
            self.CboAnttena.Append(item)
        self.CboAnttena.SetSelection(ant_type)
        self.FreqCbo.SetSelection(freq_type)
        if freq_type==0: cal_ch = path_cal_list[0]
        else: cal_ch = path_cal_list[1] 
        for i in range(1):
            ch = ""
            for j in cal_ch:
                ch = ch + "%d,"%j 
            self.TxtTx[i].SetValue(ch[:-1])
        
        
    def ExtendCalibrate(self,event):
        y_val = [] 
        self.Btn_ExtendLoss.Enable(False)
        date_str = map(str,time.gmtime()[:3])
        date_str[1] = "%02d"%int(date_str[1])
        date_str[2] = "%02d"%int(date_str[2])
        
        #log=open(logPath+'\\ExtendCableLoss_%s_%s.%s'%(self.FreqCbo.GetValue(),self.CboAnttena.GetValue(),"".join(date_str)),'w') 
        log=open(logPath+'\\ExtendCableLoss.%s'%("".join(date_str)),'w')        
        log.write('Channel,Loss\n')
        channels = []
        powers = []
        #extend_pwr = []
        extend_level = -10
        self.MessageBox("Please extend cable from VSA to VSG",'Calibration Note',wx.OK|wx.ICON_INFORMATION)
        ni_vsa = WTS(NI_ip,0)    
        print ni_vsa.Init()
        ni_vsg = WTS(NI_ip,1)    
        print ni_vsg.Init()
        #ch = self.TxtTx[0].GetValue().split(',')
        ch = PathLoss_cal_list 
        for j in ch:
            self.LblMessage.SetLabel("Extend cable Ch%d Calibrating...."%int(j))
            loss = extend_level - self.Vsg2Vsa(ni_vsa,ni_vsg,int(j),extend_level)   
            #pwr = abs(Vsg2Vsa(IQip,int(j),extend_level))
            print "Extend cable Ch%d path loss = %.2f"%(int(j),loss)
            log.write('%d,%.2f\n'%(int(j),loss))
            channels.append(int(j))
            powers.append(round(loss,2))
        self.DrawMap(channels,powers)
        y_val.append(powers)
        log.close()        
        self.DrawAllMap(channels,y_val)   
        self.Btn_ExtendLoss.Enable(True)
        self.LblMessage.SetLabel("Path Loss Calibrate Finish....")
    
    def ReadCompensation(self,filename,path=""):
        import glob
        #result = {}
        result = []
        if not path:
            path = "."
        if path[-1] not in ["/","\\"]: path += "/"
        fs = glob.glob(path+filename+".*")
        if not fs:
            print "Can't read %s%s.*"%(path,filename)
            #parent.SendMessage("Can't read %s%s.*\n"%(path,filename),log)
        else:
            fs.sort()
            #print fs
            print "Read Compensation from:",fs[-1]
            #parent.SendMessage("Read Compensation from:\n"%fs[-1],log)
            for i in open(fs[-1]).readlines():
                if not i.strip(): continue
                if 'Loss' in i: continue
                ch,offset = i.split(',')
                result.append((int(ch),float(offset)))
                #result[int(ch)] = float(offset) 
        return result    
    
    def SearchExtendPathLoss(self,AntChOffsetTab,ch): 
        #for i in AntChOffsetTab:
        for i in range(len(AntChOffsetTab)):
            if ch == AntChOffsetTab[i][0]: return AntChOffsetTab[i][1]
            if AntChOffsetTab[i][0] > ch : 
                    max_ch = AntChOffsetTab[i][0]
                    min_ch = AntChOffsetTab[i-1][0]
                    max_val = AntChOffsetTab[i][1]
                    min_val = AntChOffsetTab[i-1][1]
                    y_val = Interpolate(max_val,min_val,max_ch,min_ch,ch)
                    return y_val
             
            
    
    def SaveIni(self,event):
        output = open("parameter.ini","r")
        f = output.readlines()
        output.close()
        w = open("parameter.ini","w")
        for i in range(len(f)):
            if "ant_type" in f[i]: f[i] = "ant_type = %s\n"%self.CboAnttena.GetSelection()
            elif "freq_type" in f[i]: f[i] = "freq_type = %s\n"%self.FreqCbo.GetSelection()
            w.write(f[i])
        w.close() 
        self.MessageBox('Save OK...','Save Parameter',wx.OK|wx.ICON_INFORMATION)
    
    def SelectFreqType(self,event): 
        if self.FreqCbo.GetValue() == '2G': cal_ch = path_cal_list[0] #IQ_CAL_TX_CHANNEL_2G 
        else: cal_ch = path_cal_list[1] #IQ_CAL_TX_CHANNEL_5G     
        for i in range(1):
            ch = ""
            for j in cal_ch:
                ch = ch + "%d,"%j 
            self.TxtTx[i].SetValue(ch[:-1])
    
    def Vsg2Vsa(self,ni_vsa,ni_vsg,channel,level):
        if channel > 15: 
            rfFreqMHz=5180+(channel-36)*5
        elif channel==14:
            rfFreqMHz=2484     
        else: 
            rfFreqMHz=(2412+(channel-1)*5)
        ni_vsa.RFSAConfig(rfFreqMHz,0,"BW20","A_G",0,level)
        ni_vsg.RFGenerate(rfFreqMHz,0,"BW20","A_G","OFDM_54M",level,"CONTinuous")
        result=ni_vsa.RFSARead()
        return result["Power"]
    
    def RunCalibrate(self,event):
        y_val = []
        channels = []
        powers = []
        extend_level = 0 
        self.BtnRun.Enable(False)
        date_str = map(str,time.gmtime()[:3])
        date_str[1] = "%02d"%int(date_str[1])
        date_str[2] = "%02d"%int(date_str[2])
                
        id_=self.InputBox(message = 'Input DUT ID?')
        id_vsg=self.InputBox(message = 'Input VSG Port?')
        ni_vsa = WTS(NI_ip,int(id_)-1)    
        print ni_vsa.Init()
        ni_vsg = WTS(NI_ip,int(id_vsg)-1)    
        print ni_vsg.Init()
        if path_cal_extend_cable:
            #extend_table = self.ReadCompensation("ExtendCableLoss_%s_%s"%(self.FreqCbo.GetValue(),self.CboAnttena.GetValue()),"Station.Cal")  
            extend_AntChOffsetTab = self.ReadCompensation("ExtendCableLoss","Station.Cal")
        #raw_input(extend_AntChOffsetTab)      
        log=open(logPath+'\\PathLoss_%s_%s_%s.%s'%(self.FreqCbo.GetValue(),self.CboAnttena.GetValue(),id_,"".join(date_str)),'w')
        #log=open(logPath+'\\PathLoss_%s.%s'%(id_,"".join(date_str)),'w')        
        log.write('Anttena,Channel,Loss\n')
        for i in range(int(self.CboAnttena.GetValue()[0])):                
            self.MessageBox("Please Connect Tx%d from VSA to VSG"%i,'Calibration Note',wx.OK|wx.ICON_INFORMATION)
            ch = self.TxtTx[0].GetValue().split(',')
            #ch = path_cal_list
            count = 0
            for j in ch:
                self.LblMessage.SetLabel("Tx%d Ch%d Calibrating...."%(i,int(j))) 
                #pwr = abs(Vsg2Vsa(IQip,int(j),amp_level))
                m_loss = extend_level - self.Vsg2Vsa(ni_vsa,ni_vsg,int(j),extend_level) 
                #print loss
                if path_cal_extend_cable:
                    #loss = loss - extend_table[int(j)]
                    e_loss = self.SearchExtendPathLoss(extend_AntChOffsetTab,int(j))
                    loss = m_loss - e_loss   
                    count+=1 
                else: e_loss = 0  
                print "Tx%d Ch%d Extend loss = %.2f , Measure loss = %.2f, path loss = %.2f"%(i,int(j),e_loss,m_loss,loss)
                log.write('%d,%d,%.2f\n'%(i,int(j),loss))
                channels.append(int(j))
                powers.append(round(loss,2))
            self.DrawMap(channels,powers)
            y_val.append(powers)
        log.close()
        self.DrawAllMap(channels,y_val)   
        self.BtnRun.Enable(True)
        self.LblMessage.SetLabel("Path Loss Calibrate Finish....")
        
    
      
    def MessageBox(self,content,title,msg_type):
        dlg = wx.MessageDialog(self, content, title, msg_type)
        dlg.ShowModal()
        dlg.Destroy() 
    
    def InputBox(self, message='', default_value=''):
        dlg = wx.TextEntryDialog(self, message, defaultValue=default_value)
        dlg.ShowModal()
        result = dlg.GetValue()
        dlg.Destroy()
        return result   
                    
    def DrawMap(self,x,y):
        self.MPL.cla()
        #self.MPL.plot(x,y1,'--*y',label='Tx0',linewidth=1)
        #self.MPL.plot(x,y2,'--*r',label='Tx1')
        self.MPL.plot(x,y,'--*b')
        #self.MPL.xticker(1.0,0.5)
        #self.MPL.yticker(0.2,0.1)
        self.MPL.xlabel('Channel')
        self.MPL.ylabel('Power (dbm)')
        self.MPL.title_MPL("Path Loss table ")
        self.MPL.grid()
        self.MPL.UpdatePlot()
        return 0  
    def DrawAllMap(self,x,y_val):
        color_type = ['--*b','--*r','--*y','--*g']
        self.MPL.cla()
        for i in range(len(y_val)):
            self.MPL.plot(x,y_val[i],color_type[i])
        self.MPL.xlabel('Channel')
        self.MPL.ylabel('Power (dbm)')
        self.MPL.title_MPL("Path Loss table ")
        self.MPL.grid()
        self.MPL.UpdatePlot()
        return 0              
         
        
                  

    def __del__( self ):
        pass

def gui(Parent):
    PathCalGui(Parent).Show(True)
    
def DeltaPwr(ymax,ymin,xmax,xmin,xval):
    return ymin + ((ymax - ymin)*(xval-xmin))/(xmax-xmin)



    
class App(wx.App):
    def OnInit(self):
        try:
            self.main = PathCalGui(None)
            self.main.Show(True)
            self.SetTopWindow(self.main)
        except Exception,e:
            print e
        return True

def main():
    application = App(0)
    application.MainLoop()

if __name__ == '__main__':
   main()
