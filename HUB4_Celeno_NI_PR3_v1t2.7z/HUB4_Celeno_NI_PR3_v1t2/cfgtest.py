import os,time,traceback
from testlibs import *
from toolslib import *
from htx import Win32Message
import wx
import random
from NIWTS import *
from LibFun import *
#from FunDVT import * 
import math

execfile("config.ini")
execfile("IQ_DUT.ini")
frame = 1

def USBTest():
    print 'hereUSB'

def Reset_file(): 
    print 'hereReset_file'

def Poweroffset():
    print 'herePow'

def SetupMAC():
    print 'hereMAC'
    return 1

def RxVerify():
    print 'here RX'

def TxCal():
    print 'here TX'

#test_function={'USB':USBTest(),'cal_mode':Reset_file(),'SET_MAC':SetupMAC(),'RX_VERIFY':RxVerify(),'OFFSET_TABLE':Poweroffset()}
test_function={'USB':'USBTest()','cal_mode':'Reset_file()','SET_MAC':'SetupMAC()','RX_VERIFY':'RxVerify()','OFFSET_TABLE':'Poweroffset()'}
sub_function={'TX_CAL':'TxCal()','SET_MAC':'SetupMAC()'}
for item in test_item:
    if item is '2G' or item is '5G':
        for item_ in eval('sub_item_%s'%item):
            print '-----'+item+item_
            if eval('sub_item_toogle_%s[item_]'%item): a=eval(sub_function[item_]); print a
    else: print '======'+item; exec(test_function[item])