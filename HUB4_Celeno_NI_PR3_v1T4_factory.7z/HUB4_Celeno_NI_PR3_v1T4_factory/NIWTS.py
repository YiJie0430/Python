import htx,time
execfile("config.ini")

class Except:
    """    example:
        try:
            if ....:
                raise Except("Error!!")
        except Except, msg:
            print msg    """
    def __init__(self,msg):
        self.value = msg
    def __str__(self):
        return self.value
    def __repr__(self):
        return self.value


def TcpWaitCmdTerm(term,cmd,waitstr):
    for try_ in range(1000):
        term << "%s"%cmd
        data = term.get()
        if waitstr in data:
           return data
        time.sleep(0.005)
    raise Except("failed: %s data: %s"%(cmd,data))
    
    
class WTS:
      '''
      Port:1000~1007
      BW: BW20|BW40|BW80|BW160
      Standard: A_G|B|N|AC
      TRACking:CHANnel ON|OFF
      '''
      def __init__(self,ip,port):
          self.term = htx.TCPClient(ip,1000+port,timeout=5)
          
      def Init(self):
          return TcpWaitCmdTerm(self.term,"*IDN?","NI")
          
      def RFSAConfig(self,freq,loss,bw="BW20",stan="N",calpower=1,targetpower=15,fullpacket="ON",lpfilter="OFF",ALENgth=150):          
          self.stan = stan.upper()
          self.freq = freq
          self.calpower = calpower
          if stan == "B":
             targetpower = targetpower+6
             ALENgth = 500
          else:
             targetpower = targetpower+12
          Threshold = targetpower-22
          
          if stan == "A_G":ALENgth = 100
          #if stan == "N":ALENgth = 150
          #if stan == "AC":ALENgth = 300
          if stan == "N":ALENgth = 600
          if stan == "AC":ALENgth = 900

          self.term << "CONFigure:ATTenuation:LOSS:EXTernal %d,%2f"%(freq,abs(loss))
          self.term << "CONFigure:RFSA:WLAN:SAMAsk 1"
          self.term << "CONFigure:RFSA:WLAN:STANdard %s"%stan
          self.term << "CONFigure:RFSA:WLAN:FREquency %d MHz"%freq    
          self.term << "CONFigure:RFSA:WLAN:BWIDth %s"%bw       
          self.term << "TRIGger:RFSA:WLAN:THReshold %.4f"%Threshold
          self.term << "CONFigure:RFSA:WLAN:POWer %d"%targetpower
          self.term << "TRIGger:RFSA:WLAN:DELay 3 us"
          #self.term << "TRIGger:RFSA:WLAN:TOUT 10 s"
          self.term << "CONFigure:RFSA:WLAN:ALENgth %d us"%ALENgth
          self.term << "CONFigure:RFSA:WLAN:MEASurement:TXPower ON"
          #self.term << "CONFigure:RFSA:WLAN:MEASurement:PRAMp ON"
          self.term << "CONFigure:RFSA:WLAN:MEASurement:PRAMp OFF"
          self.term << "CONFigure:RFSA:WLAN:MEASurement:SEM:AVERaging 3"   # 20161226 new add by James Huang
          self.term << "CONFigure:RFSA:WLAN:MEASurement:OBW:AVERaging 3"
          self.term << "CONFigure:RFSA:WLAN:MEASurement:TXPower:AVERaging 3"
          self.term << "CONFigure:RFSA:WLAN:MEASurement:PRAMp:AVERaging 3"
          self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:AVERaging 3"
          if self.calpower:
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:OFDM:MSYMbols 16"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:OFDM..................................................................................................................................................................................................................................................................................00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000:TRACking:AMPLitude ON"
             #se1f.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:OFDM:TRACking:CHANnel ON"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:OFDM:TRACking:PHASe INSTANT"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:OFDM:TRACking:TIME ON"
             self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation OFF"
             self.term << "CONFigure:RFSA:WLAN:MEASurement:SEM OFF" 
             self.term << "CONFigure:RFSA:WLAN:MEASurement:OBW OFF"             
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:AVERaging 3"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:GPOW:TIME 4 us"              
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:HDETection ON"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:GPOW ON"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation ON"
          else:
             self.term << "CONFigure:RFSA:WLAN:MEASurement:SEM:AVERaging 1"   # 20161226 new add by James Huang
             self.term << "CONFigure:RFSA:WLAN:MEASurement:OBW:AVERaging 1"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:TXPower:AVERaging 3"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:PRAMp:AVERaging 3"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:AVERaging 3"             
             self.term << "CONFigure:RFSA:WLAN:MEASurement:SEM ON"
             self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation ON" 
             self.term << "CONFigure:RFSA:WLAN:MEASurement:OBW ON"
             self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:OFDM:TRACking:CHANnel %s"%fullpacket
             if fullpacket == "ON": self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:OFDM:TRACking:PHASe INSTant"
             else: self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:OFDM:TRACking:PHASe STANdard"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:OFDM:TRACking:PHASe STANdard"
             #self.term << "CONFigure:RFSA:WLAN:MEASurement:MODulation:OFDM:LPFilter %s"%lpfilter
          
      def RFSARead(self):
          try:
              self.term << "INITiate:RFSA:WLAN"
              #self.term << "INITiate:RFSA:WLAN:ANALyze" #Only analyze
              TcpWaitCmdTerm(self.term,"FETCH:RFSA:WLAN:STATe?","OFF")
              TcpWaitCmdTerm(self.term,"SYSTEM:ERROR?","No error")       
              if self.stan == "B":
                 self.term << "FETCh:RFSA:WLAN:MEASurement:TXPower:RESults?"
                 pwr = self.term.get().split(",")[0]
                 #pwr = float(self.term.wait("\n",3)[-1].split(",")[0])
                 if (pwr == 'NaN') or (pwr =='nan'): pwr = -100.0
                 else: pwr = float(pwr)
                 if self.calpower:return {"Power":pwr}
                 self.term << "FETCh:RFSA:WLAN:MEASurement:SEM:RESults?"
                 mask = float(self.term.get().split(",")[4])
                 #mask = float(self.term.wait("\n",3)[-1].split(",")[4])
                 self.term << "FETCh:RFSA:WLAN:MEASurement:MODulation:DSSS:IMPairments?"
                 val = self.term.get().split(",")
                 #val = self.term.wait("\n",3)[-1].split(",")
                 clk_error = float(val[0])
                 freq_error = float(val[1])
                 lo_leakage = float(val[3])
                 self.term << "FETCh:RFSA:WLAN:MEASurement:MODulation:DSSS:EVM?"
                 evm = self.term.get().split(",")[0]
                 #evm = float(self.term.wait("\n",3)[-1].split(",")[0])
                 if (evm == 'NaN') or (evm =='nan'): evm = 0.0
                 else: evm = float(evm)
                 values = {"Power":pwr,"Mask":mask,"EVM":evm,"ClkErr":clk_error,
                           "FreqErr":freq_error,"LoLeakage":lo_leakage}
              else:
                 self.term << "FETCh:RFSA:WLAN:MEASurement:TXPower:RESults?"
                 #self.term << "FETCh:RFSA:WLAN:MEASurement:MODulation:GPOW:VALue?"
                 pwr = self.term.get().split(",")[0]; #print 'measure:'+pwr
                 
                 #pwr = float(self.term.wait("\n",3)[-1].split(",")[0])
                 if (pwr == 'NaN') or (pwr == 'nan') or pwr == '': pwr = -100.0
                 else: pwr = float(pwr)
                 if self.calpower:return {"Power":pwr}
                 self.term << "FETCh:RFSA:WLAN:MEASurement:SEM:RESults?"
                 a = self.term.get() 
                 mask = float(a.split(",")[4])
                 #mask = float(self.term.get().split(",")[4])
                 #mask = float(self.term.wait("\n",3)[-1].split(",")[4])
                 self.term << "FETCh:RFSA:WLAN:MEASurement:MODulation:OFDM:IMPairments?"
                 val = self.term.get().split(",")
                
                 clk_error = float(val[0])
                 freq_error = float(val[1])
                 lo_leakage = float(val[3])
                 self.term << "FETCh:RFSA:WLAN:MEASurement:MODulation:OFDM:EVM?"
                 evm = self.term.get().split(",")[0]
                 #evm = float(self.term.wait("\n",3)[-1].split(",")[0])
                 if (evm == 'NaN') or (evm =='nan'): evm = 0.0
                 else: evm = float(evm)
                 self.term << "FETCh:RFSA:WLAN:MEASurement:MODulation:OFDM:SFMargin?"
                 flatness = float(self.term.get().split(",")[0])
                 #flatness = float(self.term.wait("\n",3)[-1].split(",")[0])
                 values = {"Power":pwr,"Mask":mask,"EVM":evm,"ClkErr":clk_error,
                           "FreqErr":freq_error,"LoLeakage":lo_leakage,
                           "Flatness":flatness} 
          except:values={}                      
          return values      
                   
      def RFGenerate(self,freq,loss,bw="BW20",stan="N",drate="MCS7",plevel=-50,packet=1000, MAC="0x010000C0FFEE",intervaltime='0.0001'):   
          #plevel = plevel + abs(loss) 
          self.term << "CONFigure:ATTenuation:LOSS:EXTernal %d,%.2f"%(freq,abs(loss))
          if stan=="B":
             self.term << "SOURce:RFSG:WLAN:IINTerval 0.0002"
          else:
             #self.term << "SOURce:RFSG:WLAN:IINTerval 0.0001"
             self.term << "SOURce:RFSG:WLAN:IINTerval %s"%intervaltime 
          self.term << "SOURce:RFSG:WLAN:SGMAsk 1"
          self.term << "SOURce:RFSG:WLAN:NOCHains 1"
          self.term << "SOURce:RFSG:WLAN:PACKets %s"%packet
          self.term << "SOURce:RFSG:WLAN:PAYLoad:MACAddress %s"%MAC #0x010000C0FFEE
          self.term << "SOURce:RFSG:WLAN:PAYLoad:LENGth 1024"
          self.term << "SOURce:RFSG:WLAN:STANdard %s"%stan
          self.term << "SOURce:RFSG:WLAN:CFRequency %d MHz"%freq    
          self.term << "SOURce:RFSG:WLAN:BWIDth %s"%bw       
          #self.term << "SOURce:RFSG:WLAN:PLEVel %f"%plevel
          self.term << "SOURce:RFSG:WLAN:POWer %.2f"%plevel
          self.term << "SOURce:RFSG:WLAN:DRATe %s"%drate
          self.term << "SOURce:RFSG:WLAN:PAYLoad:TYPE PN9"
          self.term << "SOURce:RFSG:WLAN:CWAVeform"
          self.term << "SOURce:RFSG:RADio ON"
          self.term << "SOURce:RFSG:WLAN:GENerate"
          #print TcpWaitCmdTerm(self.term,"*OCP?","1")
          #TcpWaitCmdTerm(self.term,"FETCH:RFSA:WLAN:STATe?","OFF")
          #TcpWaitCmdTerm(self.term,"SYSTEM:ERROR?","No error") 
          self.term << "FETCH:RFSA:WLAN:STATe?"
          return self.term.get()[-1]

 
      def RFStop(self):   
          self.term << "SOURce:RFSG:GPRF:STATUS OFF"
          
'''
try:
    #NI = WTS('127.0.0.1',0)
    NI = WTS('192.168.1.10',6)
    NI.Init() 
    NI.RFSAConfig(5530,15.02,calpower=1) 
    print NI.RFSARead()
    #NI.RFGenerate(2442,28.8)
    #NI.RFStop()
except Except,msg:
    print msg    
'''
    
    
    
    
