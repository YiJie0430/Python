#! /bin/sh
cp /tmp/mnt/diska1/hub4_production_file/hub4_shipping_default/default_5g.dat /nvram/cl2400/CL2400.dat && sync
cp /tmp/mnt/diska1/hub4_production_file/hub4_shipping_default/default_24g.dat /nvram/cl2400_24g/CL2400.dat && sync