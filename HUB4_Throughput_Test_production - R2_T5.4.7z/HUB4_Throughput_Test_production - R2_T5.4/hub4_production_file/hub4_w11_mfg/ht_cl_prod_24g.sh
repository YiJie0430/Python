#! /bin/sh

#PATH=/usr/local/bin:/usr/bin:/bin:/sbin:/usr/sbin:/cl2400/bin:/cl2400/scripts
#export PATH

	
#cl_init=`lsmod cfg80211`
#if [ "$cl_init" != "" ];then
#	/cl2400/scripts/ce_host.sh stop dual
#	rmmod cfg80211
#	rmmod compat
#fi

ifconfig eth0 0.0.0.0
vconfig add eth0 2
ip link set eth0.2 up
ifconfig eth0.2 192.168.100.2 netmask 255.255.255.0

#/cl2400/scripts/ce_host.sh start production
/cl2400/scripts/ce_host.sh production 24g
ifconfig eth0 0.0.0.0
vconfig add eth0 2
ip link set eth0.2 up
ifconfig eth0.2 192.168.100.2 netmask 255.255.255.0
