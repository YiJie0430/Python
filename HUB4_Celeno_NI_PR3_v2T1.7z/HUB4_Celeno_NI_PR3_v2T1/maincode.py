import os,time,traceback
import random
import htx_wifi
from toolslib import *
from NIWTS import *
from F_function import *
import math

execfile("config.ini")

def W11_production(parent):
    try:
        val = parent.id_ 
        result = 0
        log = None
        th_lock = False
        mac = str()
        parent.SendMessage(val,"START",state = "START")
        start_time = end_time = 0
        term =htx_wifi.SerialTTY(comport[0],b_rate)
        mac = GetMacAddress(parent)
        mac = mac.strip().upper()
        if mac[:3] <> 'F81' or len(mac) <> 12: raise Except("Mac scan Fail!")
        log = open(logPath+mac+".w11","w")
        #checktravel(mac,'127.0.0.1',1800,30)
        log = open(logPath+mac+".w11","w")
        start_time=time.time()
        station_ip = getSelfAddr()
        msg = "station_ip=%s"%(station_ip)
        #parent.SendMessage(val,"%s"%msg,log)
        parent.SendMessage(val,"Celeno WIFI Prodcution Version: %s , Station: %s"%(version,station_ip),log)
        parent.SendMessage(val,"---------------------------------------",log)
        parent.SendMessage(val,"Start Time:"+time.ctime()+"",log)
        parent.SendMessage(val,"Scan MAC address:"+mac+"",log)
        parent.SendMessage(val, "---------------------------------------------------------------------------",log)
        if not IsConnect('%s'%NI_ip,20): raise Except("FAIL: Connect NI Fail")         
        ni = WTS(NI_ip,((val-1) + (wts_station-1)*4))
        ni.Init()            
        
        if WaitBoot(parent,val,mac,term,log): raise Except ('!!-- wifi interface up, please power cycle DUT --!!')
        if USB: USBTest(parent,val,term,log)
        for i in cal_freq:
            AntChOffsetTab=ReadCompensation("PathLoss_%s_3T3R_%d"%(i, val),"C:\\WiFi_CableLoss")
            if cal_mode: Reset_file(parent,val,term,i,log)
            InitWifiProduction(parent,val,chip_list[i],term,log)           
            if SET_MAC: SetupMAC(parent,val,chip_list[i],mac,mac_rule[i],term,log)
            if FREQ_CAL: FreqCalibrate(parent,ni,val,term,chip_list[i],AntChOffsetTab,freq_offset,log)            
            if TX_CAL: result+=CalTxPower(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
            if TX_VERIFY: result+=TxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
            if RX_VERIFY: result+=RxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log)                                   
    except Except,msg:
        parent.SendMessage(val,"%s"%msg,log,color=1)
        result = 1               
    except: 
        parent.SendMessage(val,"%s"% traceback.print_exc(),log,color=1)
        result = 1

    end_time = time.time()
    parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
    parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log)
    if result: parent.SendMessage(val,"Test Result: FAIL"+"",log,color=1)
    else: parent.SendMessage(val,"Test Result: PASS"+"",log,color=2)
    if log: log.close()                    
    #if term: term.close()
    if mac: 
       #travel = passtravel(mac,'127.0.0.1',1800,30)
       #if travel or result:
       if result:
          parent.SendMessage(val,"",state = "FAIL")
       else:
          parent.SendMessage(val,"",state = "PASS")   
    else: parent.SendMessage(val,"",state = "FAIL")
    term=None
    
    
def pwrcheck_production(parent):
    try:
        val = parent.id_ 
        result = 0
        log = None
        th_lock = False
        mac = str()
        parent.SendMessage(val,"START",state = "START")
        start_time = end_time = 0
        term =htx_wifi.SerialTTY(comport[0],b_rate)
        mac = GetMacAddress(parent)
        mac = mac.strip().upper()
        if mac[:3] <> 'F81' or len(mac) <> 12: raise Except("Mac scan Fail!")
        log = open(logPath+mac+".w11","w")
        #checktravel(mac,'127.0.0.1',1800,30)
        log = open(logPath+mac+".w11","w")
        start_time=time.time()
        station_ip = getSelfAddr()
        msg = "station_ip=%s"%(station_ip)
        parent.SendMessage(val,"%s"%msg,log)
        parent.SendMessage(val,"Celeno WIFI Prodcution Version: %s , Station: %s"%(version,station_ip),log)
        parent.SendMessage(val,"---------------------------------------",log)
        parent.SendMessage(val,"Start Time:"+time.ctime()+"",log)
        parent.SendMessage(val,"Scan MAC address:"+mac+"",log)
        parent.SendMessage(val, "---------------------------------------------------------------------------",log)
        if not IsConnect('%s'%NI_ip,20): raise Except("FAIL: Connect NI Fail")         
        ni = WTS(NI_ip,((val-1) + (wts_station-1)*4))
        ni.Init()            
        
        if WaitBoot(parent,val,mac,term,log): raise Except ('!!-- wifi interface up, please power cycle DUT --!!')
        for i in cal_freq:
            AntChOffsetTab=ReadCompensation("PathLoss_%s_3T3R_%d"%(i, val),"C:\\WiFi_CableLoss")
            InitWifiProduction(parent,val,chip_list[i],term,log)            
            if TX_VERIFY: result+=TxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log)                       
    except Except,msg:
        parent.SendMessage(val,"%s"%msg,log,color=1)
        result = 1               
    except: 
        parent.SendMessage(val,"%s"% traceback.print_exc(),log,color=1)
        result = 1

    end_time = time.time()
    parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
    parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log)
    if result: parent.SendMessage(val,"Test Result: FAIL"+"",log,color=1)
    else: parent.SendMessage(val,"Test Result: PASS"+"",log,color=2)
    if log: log.close()                    
    #if term: term.close()
    if mac: 
       #travel = passtravel(mac,'127.0.0.1',1800,30)
       #if travel or result:
       if result:
          parent.SendMessage(val,"",state = "FAIL")
       else:
          parent.SendMessage(val,"",state = "PASS")   
    else: parent.SendMessage(val,"",state = "FAIL")
    term=None
    

def W11_lab(parent):
    try:
        val = parent.id_ 
        result = 0
        log = None
        th_lock = False
        mac = str()
        parent.SendMessage(val,"START",state = "START")
        start_time = end_time = 0
        mac = GetMacAddress(parent)
        mac = mac.strip().upper()
        log = open(logPath+mac+".w11","w")
        start_time=time.time()
        parent.SendMessage(val,"Celeno WIFI Prodcution Version: %s , Station: %s"%(version,Test_station),log)
        parent.SendMessage(val,"---------------------------------------",log)
        parent.SendMessage(val,"Start Time:"+time.ctime()+"",log)
        parent.SendMessage(val,"Scan MAC address:"+mac+"",log)
        parent.SendMessage(val, "---------------------------------------------------------------------------",log)
        if not IsConnect('%s'%NI_ip_lab,20): raise Except("FAIL: Connect NI Fail")         
        ni = WTS(NI_ip_lab,((val-1) + (wts_station-1)*4))
        ni.Init()            
        if telnet: term=Check_boot(parent,val,atom,time_out,log)
        else: term =htx_wifi.SerialTTY(comport[0],b_rate)
        if WaitBoot(parent,val,mac,term,log): raise Except ('!!-- wifi interface up, please power cycle DUT --!!')
        if USB: USBTest(parent,val,term,log)
        for i in cal_freq:
            AntChOffsetTab=ReadCompensation("PathLoss_%s_3T3R_%d"%(i, val),"Station.Cal")
            if cal_mode: Reset_file(parent,val,term,i,log)
            InitWifiProduction(parent,val,chip_list[i],term,log)           
            if SET_MAC: SetupMAC(parent,val,chip_list[i],mac,mac_rule[i],term,log)
            if FREQ_CAL: FreqCalibrate(parent,ni,val,term,chip_list[i],AntChOffsetTab,freq_offset,log)            
            if TX_CAL: result+=CalTxPower(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
            if TX_VERIFY: result+=TxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
            if RX_VERIFY: result+=RxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log)                                   
    except Except,msg:
        parent.SendMessage(val,"%s"%msg,log,color=1)
        result = 1               
    except: 
        parent.SendMessage(val,"%s"% traceback.print_exc(),log,color=1)
        result = 1

    end_time = time.time()
    parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
    parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log)
    if result: parent.SendMessage(val,"Test Result: FAIL"+"",log,color=1)
    else: parent.SendMessage(val,"Test Result: PASS"+"",log,color=2)
    if log: log.close()                    
    #if term: term.close()
    if mac: 
       #travel = passtravel(mac,'127.0.0.1',1800,30)
       #if travel or result:
       if result:
          parent.SendMessage(val,"",state = "FAIL")
       else:
          parent.SendMessage(val,"",state = "PASS")   
    else: parent.SendMessage(val,"",state = "FAIL")
    term=None

def pwrcheck_production_lab(parent):
    try:
        val = parent.id_ 
        result = 0
        log = None
        th_lock = False
        mac = str()
        parent.SendMessage(val,"START",state = "START")
        start_time = end_time = 0
        term =htx.SerialTTY(comport[0],b_rate)
        mac = GetMacAddress(parent)
        mac = mac.strip().upper()
        log = open(logPath_check+mac+".pwrcheck","w")
        start_time=time.time()
        parent.SendMessage(val,"Celeno WIFI Prodcution Version: %s , Station: %s"%(version,Test_station),log)
        parent.SendMessage(val,"---------------------------------------",log)
        parent.SendMessage(val,"Start Time:"+time.ctime()+"",log)
        parent.SendMessage(val,"Scan MAC address:"+mac+"",log)
        parent.SendMessage(val, "---------------------------------------------------------------------------",log)
        if not IsConnect('%s'%NI_ip_lab,20): raise Except("FAIL: Connect NI Fail")         
        ni = WTS(NI_ip_lab,((val-1) + (wts_station-1)*4))
        ni.Init()            
        
        if WaitBoot(parent,val,mac,term,log): raise Except ('!!-- wifi interface up, please power cycle DUT --!!')
        #if USB: USBTest(parent,val,term,log)
        for i in cal_freq:
            AntChOffsetTab=ReadCompensation("PathLoss_%s_3T3R_%d"%(i, val),"Station.Cal")
            #if cal_mode: Reset_file(parent,val,term,i,log)
            InitWifiProduction(parent,val,chip_list[i],term,log)           
            #if SET_MAC: SetupMAC(parent,val,chip_list[i],mac,mac_rule[i],term,log)
            #if FREQ_CAL: FreqCalibrate(parent,ni,val,term,chip_list[i],AntChOffsetTab,freq_offset,log)            
            #if TX_CAL: result+=CalTxPower(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
            if TX_VERIFY: result+=TxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
            #if RX_VERIFY: result+=RxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log)                                   
    except Except,msg:
        parent.SendMessage(val,"%s"%msg,log,color=1)
        result = 1               
    except: 
        parent.SendMessage(val,"%s"% traceback.print_exc(),log,color=1)
        result = 1

    end_time = time.time()
    parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
    parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log)
    if result: parent.SendMessage(val,"Test Result: FAIL"+"",log,color=1)
    else: parent.SendMessage(val,"Test Result: PASS"+"",log,color=2)
    if log: log.close()                    
    #if term: term.close()
    if mac: 
       #travel = passtravel(mac,'127.0.0.1',1800,30)
       #if travel or result:
       if result:
          parent.SendMessage(val,"",state = "FAIL")
       else:
          parent.SendMessage(val,"",state = "PASS")   
    else: parent.SendMessage(val,"",state = "FAIL")
    term=None

def Lab_loop(parent):
    term=0
    arm_term=0
    val = parent.id_ 
    result = 0
    log = None
    th_lock = False
    mac = str()
    parent.SendMessage(val,"START",state = "START")
    term =htx_wifi.SerialTTY(comport[0],b_rate)
    #arm_term =htx_wifi.SerialTTY(comport[0],b_rate)
    mac = GetMacAddress(parent)
    mac =mac.strip().upper()
    ni = WTS(NI_ip_lab,((val-1) + (wts_station-1)*4))
    ni.Init()            
    #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
    #time.sleep(20); 
    for run in xrange(1,roundtime+1):
        result = 0
        parent.SendMessage(val,"START",state = "START")
        run=str(run)
        log = open(logPath+run+".w11","w")
        clog = open(logPath_check+run+".check","w")
        file=logPath+run+'.w11'
        file_c=logPath_check+run+'.check'
        start_time = end_time = 0
        start_time=time.time()
        parent.SendMessage(val,"----------------Run%s-----------------"%run,log)
        parent.SendMessage(val,"Celeno WIFI Calibration loop version: %s , Station: %s"%(version,Test_station),log)
        parent.SendMessage(val,"---------------------------------------",log)
        parent.SendMessage(val,"Start Time:"+time.ctime()+"",log)
        parent.SendMessage(val,"Scan MAC address:"+mac+"",log)
        parent.SendMessage(val, "---------------------------------------------------------------------------",log)
        internal_test_time=time.time()
        try:
            case=0
            while True:
              if WaitBoot(parent,val,mac,term,log): 
                 Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
                 #Snmp.SnmpSet("192.168.10.254","1.3.6.1.4.1.26104.3.3.3.1.5.1","i",3,community="public")
                 time.sleep(30); 
                #raise Except ('!!-- wifi interface up, please power cycle the DUT --!!')
              else: break
            if USB: USBTest(parent,val,term,log)
            for i in cal_freq:
                if cal_mode: Reset_file(parent,val,term,i,log)
                InitWifiProduction(parent,val,chip_list[i],term,log)
                AntChOffsetTab = ReadCompensation("PathLoss_%s_3T3R_%d"%(i, val),"Station.Cal")
                if SET_MAC: SetupMAC(parent,val,chip_list[i],mac,mac_rule[i],term,log)
                if FREQ_CAL: FreqCalibrate(parent,ni,val,term,chip_list[i],AntChOffsetTab,freq_offset,log)            
                if TX_CAL: result+=CalTxPower(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
                if TX_VERIFY: result+=TxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
                if RX_VERIFY: result+=RxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log)                                    
            parent.SendMessage(val,"Round%s >> total test time: %3.2f sec"%(run,(time.time()-internal_test_time)),log)
            if not result: 
                parent.SendMessage(val,'',state = "PASS"); parent.SendMessage(val,"Test Result: PASS"+'',log,color=2)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log)
            else: 
                parent.SendMessage(val,'',state = "FAIL"); parent.SendMessage(val,"Test Result: FAIL"+'',log,color=1) 
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log) 
            log.close()
            if not result: 
               update_file=logPath+run+'_PASS.W11'
               os.rename(file,update_file+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')               
            else: 
               update_file=logPath+run+'_Fail.W11'
               os.rename(file,update_file+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')
            Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
            #Snmp.SnmpSet("192.168.10.254","1.3.6.1.4.1.26104.3.3.3.1.5.1","i",3,community="public")
            #arm_term << 'reboot'
            time.sleep(30)
            result = 0
            parent.SendMessage(val,"START",state = "START")
            parent.SendMessage(val,"----------------Run%s-----------------"%run,clog)
            parent.SendMessage(val,"Celeno WIFI Power check loop version: %s , Station: check"%(version),clog)
            parent.SendMessage(val,"---------------------------------------",clog)
            parent.SendMessage(val,"Start Time:"+time.ctime()+"",clog)
            parent.SendMessage(val,"Scan MAC address:"+mac+"",clog)
            parent.SendMessage(val, "---------------------------------------------------------------------------",clog)
            internal_test_time=time.time()
            start_time = end_time = 0
            start_time=time.time()
            case=1
           
            while True:
              if WaitBoot(parent,val,mac,term,clog):
                 Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
                 #Snmp.SnmpSet("192.168.10.254","1.3.6.1.4.1.26104.3.3.3.1.5.1","i",3,community="public")
                 time.sleep(30); 
                 #raise Except ('!!-- wifi interface up, please power cycle the DUT --!!')
              else: break
            for i in cal_freq:
                InitWifiProduction(parent,val,chip_list[i],term,clog)
                AntChOffsetTab = ReadCompensation("PathLoss_%s_3T3R_%d"%(i, val),"Station.Cal")
                if TX_VERIFY: result+=TxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,clog) 
            parent.SendMessage(val,"Round%s >> total test time: %3.2f sec"%(run,(time.time()-internal_test_time)),clog)
            #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
            #time.sleep(20)
            if not result: 
                parent.SendMessage(val,'',state = "PASS"); parent.SendMessage(val,"Test Result: PASS"+'',clog,color=2)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',clog)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',clog)       
            else: 
                parent.SendMessage(val,'',state = "FAIL"); parent.SendMessage(val,"Test Result: FAIL"+'',clog,color=1)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',clog)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',clog)
            clog.close()            
            if not result:
               update_file_check=logPath_check+run+'_PASS.check'
               os.rename(file_c,update_file_check+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')
            else:
               update_file_check=logPath_check+run+'_Fail.check' 
               os.rename(file_c,update_file_check+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')
            #arm_term << 'reboot'
            Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
            #Snmp.SnmpSet("192.168.10.254","1.3.6.1.4.1.26104.3.3.3.1.5.1","i",3,community="public")
            time.sleep(30)
        except Except,msg:
            raw_input('aaa')
            parent.SendMessage(val,"%s"%msg,log,color=1)
            Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
            #Snmp.SnmpSet("192.168.10.254","1.3.6.1.4.1.26104.3.3.3.1.5.1","i",3,community="public")
            #time.sleep(20);
            #parent.SendMessage(val,'',state = "FAIL") 
            result=1
        except: 
            raw_input('bbb')     
            parent.SendMessage(val,"%s"%traceback.print_exc(),log,color=1)
            Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
            result=1
        if result:
            if not case: 
                parent.SendMessage(val,"Test Result: FAIL"+'',log,color=1)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log)
                log.close()
                update_file=logPath+run+'_Fail.W11'
                os.rename(file,update_file+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')
                msg='Notesting'
                parent.SendMessage(val,"%s"%msg,clog,color=1)
                parent.SendMessage(val,"Test Result: FAIL"+'',clog,color=1)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',clog)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',clog)       
                clog.close()
                update_file_check=logPath_check+run+'_Fail.check'
                os.rename(file_c,update_file_check+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')                
            else:
                parent.SendMessage(val,"Test Result: FAIL"+'',clog,color=1)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',clog)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',clog)       
                clog.close()
                update_file_check=logPath_check+run+'_Fail.check'
                os.rename(file_c,update_file_check+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')
                #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
                #if not keepalive: arm_term << 'reboot'
            #arm_term << 'reboot'
            #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8           
            parent.SendMessage(val,'',state = "FAIL")
            time.sleep(20);
            
    if not result: parent.SendMessage(val,'',state = "PASS")
    else: parent.SendMessage(val,'',state = "FAIL")
    term=None
    arm_term=None

#F81D0F253B46
def Lab_retest_opt(parent):
    try:
        val = parent.id_ 
        result = 0
        log = None
        th_lock = False
        mac = str()
        rcd=None
        parent.SendMessage(val,"START",state = "START")
        #start_time = end_time = 0
        start_time=time.time()
        #term =SerialTTY("com1",b_rate)
        term =htx_wifi.SerialTTY(comport[0],b_rate)
        mac = GetMacAddress(parent)
        mac = mac.strip().upper()
        
        if mac[0]=="2":mac=getmac(mac)
        if len(mac) <> 12:
            raise Except("Mac scan Fail!") 
        
        #sn = GetSN(parent) 
        log = open(logPath+mac+".w11","w")
        #checktravel(mac,'127.0.0.1',1800,30)
        start_time=time.time()
        station_ip = getSelfAddr()
        msg = "station_ip=%s"%(station_ip)
        parent.SendMessage(val,"%s"%msg,log)
        if not IsConnect('%s'%NI_ip,20):
            raise Except("FAIL: Connect NI Fail")         
        ni = WTS(NI_ip,((val-1) + (wts_station-1)*4))
        ni.Init()

        flow=R_Flow(term)

        test_function={'USB':'USBTest(parent,val,term,log)',\
                       'OFFSET_TABLE':'Poweroffset(parent,val,term,shipping_offset_table,log)'}      
        if WaitBoot(parent,val,mac,term,log): raise Except ('wifi interface up, please power cycle DUT')
        #term<<"rm /nvram/w11mfgrcd"
        term<<"find /nvram -name 'w11*' -delete"
        time.sleep(0.3)
        #term<<"rm /nvram/w11mfgrcd"
        term<<"find /nvram -name 'w11*' -delete"
        rcd=flow.GetMfgRecord(term)
        for idx,item in enumerate(test_item):
            if flow.ChkMfgRecord(rcd,idx): continue
            if item is '2G' or item is '5G':
                AntChOffsetTab=ReadCompensation("PathLoss_%s_3T3R_%d"%(item, val),"C:\\WiFi_CableLoss")
                sub_item_toogle=flow.GetSubRcd(term,item); print sub_item_toogle; #raw_input('hold')
                if sub_item_toogle['cal_mode']: Reset_file(parent,val,term,item,log)
                #Poweroffset(parent,val,term,productin_offset_table,log)
                InitWifiProduction(parent,val,chip_list[item],term,log)
                if sub_item_toogle['FREQ_CAL']: FreqCalibrate(parent,ni,val,term,chip_list[item],AntChOffsetTab,freq_offset,log)            
                if sub_item_toogle['TX_CAL']: result=CalTxPower(parent,ni,val,term,chip_list[item],AntChOffsetTab,item,log) 
                if sub_item_toogle['TX_VERIFY']: result=TxVerify(parent,ni,val,term,chip_list[item],AntChOffsetTab,item,log)
                if not result:
                    flow.SetSubRcd(term,sub_item_toogle,item,'cal_mode')
                    flow.SetSubRcd(term,sub_item_toogle,item,'FREQ_CAL')
                    flow.SetSubRcd(term,sub_item_toogle,item,'TX_CAL')
                    flow.SetSubRcd(term,sub_item_toogle,item,'TX_VERIFY')
                if sub_item_toogle['RX_VERIFY']: result=RxVerify(parent,ni,val,term,chip_list[item],AntChOffsetTab,item,log)
                if not result:
                    flow.SetSubRcd(term,sub_item_toogle,item,'RX_VERIFY')
                if sub_item_toogle['SET_MAC']: SetupMAC(parent,val,chip_list[item],mac,mac_rule[item],term,log)
                if not result: flow.SetMfgRecord(term,rcd,idx)
            else: 
                toogle=eval(test_function[item]) 
                if toogle: flow.SetMfgRecord(term,rcd,idx)        
        flow.SaveRcdLog(term,rcd)        
    except Except,msg:
        parent.SendMessage(val,"%s"%msg,log,color=1,uart=term)
        flow.SaveRcdLog(term,rcd)
        result = 1               
    except: 
        parent.SendMessage(val,"%s"% traceback.print_exc(),log,color=1,uart=term)
        flow.SaveRcdLog(term,rcd)       
        result = 1
        #term=None
    end_time = time.time()
    parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log,uart=term)
    parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log,uart=term)
    if result:
       parent.SendMessage(val,"Test Result: FAIL"+'\n',log,color=1)
       if not keepalive: Telnet_arm(parent,val,arm,log); #term<<'reboot'
    else:
       parent.SendMessage(val,"Test Result: PASS"+'\n',log,color=2)
       #Bridge_up(parent,val,arm,log)
       #Telnet_arm(parent,val,arm,log)
    if log:
        log.close()        
        oriFile = logPath+mac+".w11"
        if (not result): newFile = oriFile+"-pass"
        else: newFile = oriFile+"-fail"
        #newFile += time.strftime("%M-%S"%time.localtime())
            
        #os.rename(oriFile, newFile)
            
    if term: term.close()
    if mac: 
       travel = passtravel(mac,'127.0.0.1',1800,30)
       if travel or result:
       #if result:
          parent.SendMessage(val,'\n',state = "FAIL",color=1)
       else:
          parent.SendMessage(val, "",state = "PASS")   
    else: parent.SendMessage(val,"",state = "FAIL")  
