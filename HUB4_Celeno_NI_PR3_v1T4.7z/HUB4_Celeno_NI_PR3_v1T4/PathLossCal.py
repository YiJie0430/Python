import htx_wifi,time
from ctypes import *
from htx_wifi import Win32Message
execfile('config.ini')
execfile('IQ_DUT.ini')


samplingRate = 80e6   #For IQflex

def ShowErrorMsg(title,result):
    Ret=IQmeas.LP_GetErrorString
    Ret.restype=c_char_p
    char_point=c_char_p(" "*20)
    char_point=IQmeas.LP_GetErrorString(c_int(result))
    boxtitle = "Error %s"%title
    bodymsg = "ERROR:%s!!"%char_point
    Win32Message(boxtitle,bodymsg)
    
def IniIQ(IQip):
    '''
    print "Try to connect IQ tester at %s"%IQip
    if not htx.IsConnect(IQip,connect_timeout):
        raise Except("%s never connect"%IQip)
    print "Initialize Lib."
    IQmeas.LP_Init()
    print "Reset Tester."
    IQmeas.InitTester1(ip="%s"%IQip)
    print "IQ instrument initial OK...."
    '''
    
    if IQxls:
        print "IQ xls initial.........." 
        result = IQmeas.LP_Init(c_int(1),c_int(0))
    else:
        print "IQ flex initial.........." 
        result = IQmeas.LP_Init()      #1: IQ-Xel
    
    
    if result<>0: ShowErrorMsg("LP_Init",result)
    print "Instrument ip: %s"%IQip
    result = IQmeas.LP_DualHead_ConOpen(1,                  #tokenID    1=left,2=right
                                         c_char_p("%s"%IQip),       #testerIP,		//*ipAddress1
                                         c_void_p(0).value,  #null, #ctypes.c_void_p(0).value == None  			//*ipAddress2
                                         c_void_p(0).value,  #null,			//*ipAddress3
                                         c_void_p(0).value)  #null			//*ipAddress4
    if result<>0: ShowErrorMsg("LP_DualHead_ConOpen",result)
    result = IQmeas.LP_DualHead_ObtainControl(c_uint(500),					#probeTimeMS
    						                              c_uint(10000))	      #timeOutMS
    
    if result<>0: ShowErrorMsg("LP_DualHead_ObtainControl",result)
    result = IQmeas.LP_SetDefault()
    if result<>0: ShowErrorMsg("LP_SetDefault",result)
    print "IQ flex initial..........Done"

def Vsg2Vsa(ni,channel):
    if channel > 15: 
        rfFreqMHz=5180+(channel-36)*5
    elif channel==14:
        rfFreqMHz=2484     
    else: 
        rfFreqMHz=(2412+(channel-1)*5)
    ni.RFSAConfig(rfFreqMHz,0,"BW20","A_G",0,-10)
    ni.RFGenerate(rfFreqMHz,0,"BW20","A_G","OFDM_54M",-10,"CONTinuous")
    result = ni.RFSAConfig(rfFreqMHz,0,"BW20","A_G")
    return result["power"]
        
        
        
    

