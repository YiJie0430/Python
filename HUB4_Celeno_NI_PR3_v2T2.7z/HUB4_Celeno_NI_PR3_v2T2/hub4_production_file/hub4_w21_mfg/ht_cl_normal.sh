#! /bin/sh
cp /tmp/mnt/diska1/hub4_production_file/hub4_w21_mfg/CL2400_mfg_5g.dat /nvram/cl2400/CL2400.dat && sync
cp /tmp/mnt/diska1/hub4_production_file/hub4_w21_mfg/CL2400_mfg_24g.dat /nvram/cl2400_24g/CL2400.dat && sync