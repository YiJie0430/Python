# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Jun 30 2011)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
from htx import Win32Message

###########################################################################
## Class MyFrame2
###########################################################################

class MyFrame ( wx.Frame ):
    def __init__( self, parent ):
        wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"select", pos = wx.DefaultPosition, size = wx.Size( 500,300 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
        self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
        bSizer9 = wx.BoxSizer( wx.VERTICAL )
        self.m_checkBox2 = wx.CheckBox( self, wx.ID_ANY, u"Check Me!", wx.DefaultPosition, wx.DefaultSize, 0 )
        #self.m_checkBox2.SetValue(True) 
        bSizer9.Add( self.m_checkBox2, 0, wx.ALL, 5 )
        self.m_checkBox3 = wx.CheckBox( self, wx.ID_ANY, u"Check Me!", wx.DefaultPosition, wx.DefaultSize, 0 )
        bSizer9.Add( self.m_checkBox3, 0, wx.ALL, 5 )
        
        self.SetSizer( bSizer9 )
        self.Layout()
        self.Centre( wx.BOTH )
    
        self.Bind(wx.EVT_CHECKBOX,self.OnChkBox,self.m_checkBox2)
    
    def OnChkBox(self, evt):
        
        sender = evt.GetEventObject()
        isChecked = sender.GetValue()
        if isChecked:
            self.SetTitle('wx.CheckBox')
            Win32Message("",str(isChecked))           
        else: 
            self.SetTitle('')
            Win32Message("",str(isChecked))
        
        #self.m_checkBox3.SetValue(evt.IsChecked())
        
    def __del__( self ):
        pass
        

class App(wx.App):
    def OnInit(self):
        try:
            self.main = MyFrame(None)
            self.main.Show(True)
            self.SetTopWindow(self.main)
        except Exception,e:
            print e
        return True

def main():
    application = App(0)
    application.MainLoop()

if __name__ == '__main__':
   main()