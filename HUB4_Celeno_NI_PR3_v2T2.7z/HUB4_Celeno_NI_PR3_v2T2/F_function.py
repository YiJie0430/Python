import os,time,traceback
from toolslib import *
import random
from NIWTS import *
from Retest import * 
import math
import htx_wifi
import NIadj

execfile("config.ini")
execfile("IQ_DUT.ini")
frame = 1

def lWaitCmdTerm(term,cmd,waitstr,sec,count=1):
    for i in range(count):
        data=list()
        term << cmd
        data = term.wait(waitstr,sec); print'[cmd]:'+cmd+'\n[return]:\n'+data[-1]
        if cmd == 'sh -x /tmp/mnt/diska1/hub4_production_file/hub4_w11_mfg/ht_cl_prod_24g.sh' or cmd == 'sh -x /tmp/mnt/diska1/hub4_production_file/hub4_w11_mfg/ht_cl_prod_5g.sh':
           data=data[-1].split(cmd+'\r\n')[-1].split(waitstr)[0].strip()
           return data	
        if "help" in data[-1]: 
            if cmd =='doc' or cmd == 'bootfrom 1': pass
            else: raise Except("ErrorCode[2000]: DUT Issue | wifi interface down")        
        if "ttyS" in data[-1]:
            time.sleep(2)
            term<<""
            term.get()            
            #data = term.wait("%s"%promp,sec) 
            term << "%s"%cmd
            data = term.wait("%s"%waitstr,sec); #print data
        data1=data[-1].split(cmd+'\r\n')[-1]; #print data1
        if waitstr not in data1: raise Except("ErrorCode[1000]: CMD Issue | cmd: %s, return: %s"%(cmd,data)) 
        data2=data[-1].split(cmd+'\r\n')[-1].split(waitstr)[0].strip()  
        return data2

def Interpolate(yMax,yMin,xMax,xMin,xVal):
        #Description:
        #   A generic function for interpolating. Find y_val when xVal is present.
        #
        #                             (yMax - yMin)
        #    Returns y_val = yMin + (--------------- * (xVal - xMin))
        #                             (xMax - xMin)
        #
        return (float(yMin) + ((float(yMax - yMin) / float(xMax - xMin)) * float(xVal - xMin)))

def SearchPathLossTable(AntChOffsetTab,ant,ch): 
    #for i in AntChOffsetTab:
    for i in range(len(AntChOffsetTab)):
        if ant== AntChOffsetTab[i][0]:
            if ch == AntChOffsetTab[i][1]: return AntChOffsetTab[i][2]
            if AntChOffsetTab[i][1] > ch : 
                    max_ch = AntChOffsetTab[i][1]
                    min_ch = AntChOffsetTab[i-1][1]
                    max_val = AntChOffsetTab[i][2]
                    min_val = AntChOffsetTab[i-1][2]
                    y_val = Interpolate(max_val,min_val,max_ch,min_ch,ch)
                    return y_val 
             
def ReadCompensation(filename,path=""):
    import glob
    result = []
    if not path:
        path = "."
    if path[-1] not in ["/","\\"]: path += "/"
    fs = glob.glob(path+filename+".*")
    if not fs:
        print "Can't read %s%s.*"%(path,filename)
        #parent.SendMessage("Can't read %s%s.*"%(path,filename),log)
    else:
        fs.sort()
        #print fs
        print "Read Compensation from:",fs[-1]
        #parent.SendMessage("Read Compensation from:"%fs[-1],log)
        for i in open(fs[-1]).readlines():
            if not i.strip(): continue
            if 'Loss' in i: continue
            ant,ch,offset = i.split(',')
            result.append((int(ant),
                           int(ch),
                           float(offset)))
    return result

def GetMacAddress(parent):
    #val = parent.MAC.GetValue()
    if frame == 1: val = eval('parent.MAC1').GetValue()
    else: val = eval('parent.MAC%d'%parent.id_).GetValue()
    val=str(val.upper())
    try:
        #if len(val) == 12 and int(val,16):
        if len(val) == 12 and mac_final == val[-1] :
           return val
    except ValueError:
           pass
    raise Except("ErrorCode[0000]: Operating Issue | Input Label Error [%s] !"%val)

def getmac(mac):
    ServerIP = '127.0.0.1'
    ServerPort = 1800
    timeout = 30
    sn = ""
    MesSocket=htx_wifi.UDPService(ServerIP,int(ServerPort),int(timeout))
    MesSocket.set('2,' + mac)  
    Result=MesSocket.get()
    print Result
    Result=Result.strip()
    if Result:
       if len(Result)<>12 or Result[0] == '2':
          raise Except("ErrorCode(0005):Get MAC Failed:%s"%Result)
       else:
          sn = Result
          return sn
    raise Except("ErrorCode(0005):Connection MES Server Fail ")
    
def FPing(ip,length,count,interval):
    print ip
    """    Ping(ip,length,count,interval), return the loss rate (float)
        where ip is target ip address, length is IP packet length
              count is packet number, interval is ms unit"""
    result = os.popen("Fping %s -s %d -t %d -n %d"%(ip,length,interval,count)).read()
    return float(result[result.rfind("(")+1:result.rfind("%")])

def LinkPing(ip,count):
    #print ip
    result = os.popen('ping -w 1000 -n %d %s'%(count,ip)).read()
    return float(result[result.rfind("(")+1:result.rfind("%")])

def IsConnect(ip,timeout):
    ip = ip.strip()
    current = time.time()
    timeout += current
    os.popen("arp -d").read()
    while current < timeout:
        rate = FPing(ip,64,5,1)
        if rate == 0: return 1 
        time.sleep(1)                             
        current = time.time()
    return 0

def IsDisconnect(ip,timeout):
    ip = ip.strip()
    current = time.time()
    timeout += current
    os.popen("arp -d")
    while current < timeout:
        rate = LinkPing(ip,3)
        if rate == 100: return 1  
        time.sleep(1)
        current = time.time()
    return 0

def getSelfAddr():
    ip = socket.gethostbyname_ex(socket.gethostname())
    for i in ip[-1]:
       if '172.28.' in i:
          return i
    return 0

def TelnetLogin(term,username=None,password=None):
    print "Telnet Login..."
    data = term.wait('login:',5)
    term<<username
    data = term.wait('Password:',5)
    term<<password
    data = term.wait('#',5)

def Telnet_arm(parent,dut_id,arm,log):
    parent.SendMessage(dut_id,"telnet to arm...\n", log)
    arm_term=htx_wifi.Telnet(arm); time.sleep(5)
    test_time=time.time()
    while 1: 
        if time.time()-test_time>20: raise Except('Telnet Arm Fail')
        data=arm_term.get(); print data
        if 'Password' in data: arm_term << 'Hitron'; time.sleep(1)
        elif 'login as' in data: arm_term << 'admin'; time.sleep(1)
        if 'Menu>' in data: return arm_term                 

def Telnet_atom(parent,dut_id,atom,log):
    test_time=time.time()
    parent.SendMessage(dut_id,"telnet to atom ",log)
    atom_term =htx_wifi.Telnet(atom)
    while 1: 
        if time.time()-test_time>20: raise Except('Telnet ATOM Fail')
        atom_term << '\r\n'; #time.sleep(1)
        data=atom_term.get(); print data
        if promp in data: break
    parent.SendMessage(dut_id,"Telnet to ATOM time: %3.2f (sec)"%(time.time()- test_time) ,log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)
    return atom_term

def Bridge_up(parent,dut_id,target,log):
    parent.SendMessage(dut_id,"Waitting for bridge(%s)..."%target,log)
    test_time=time.time()    
    if not IsConnect(target,300):  raise Except("ErrorCode[2000]: DUT Issue | Can't Ping Atom") 
    parent.SendMessage(dut_id,"ping %s sucess time: %3.2f (sec)"%(target,(time.time()- test_time)) ,log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)

def Check_boot(parent,dut_id,ip,timeout,log):
    test_time=time.time()  
    if not IsConnect(ip,timeout): raise Except("ErrorCode[2000]: DUT Issue | Can't Ping Atom") 
    #term =htx_wifi.Telnet(cpu)    
    term=Telnet_atom(parent,dut_id,ip,log)
    parent.SendMessage(dut_id,"Waitting for DUT bootup...\n",log)
    parent.SendMessage(dut_id,"ATOM-%s ping success...\n"%ip,log,color=2)
    parent.SendMessage(dut_id,"DUT bootup Check time: %3.2f (sec)\n"%(time.time()- test_time),log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------\n",log)
    return term

def WaitBoot(parent,dut_id,mac,term,log):
    test_time = time.time()
    cmd_list=['root','export PATH=$PATH:/cl2400/bin']
    #raise Except( "Wifi boot FAIL." )
    while 1:
        if time.time()-test_time>60: raise Except("ErrorCode[2000]: DUT Issue | Can't Enter Shell")
        term<<'';time.sleep(0.5)
        data=term.get(); #print data
        term<<'';time.sleep(0.5)
        data=term.get(); #print data
        if promp in data: break
        if "shell>" in data: term<<'boot'; continue
        if "Password:" in data: term<<''; time.sleep(5); continue
        elif "login:" in data:
           for cmd in cmd_list: term<<cmd; time.sleep(0.5)
        else: time.sleep(5)    
    '''
    parent.SendMessage(dut_id,"Celeno WIFI Calibration Version: %s , Station: %s"%(version,Test_station),log)
    parent.SendMessage(dut_id,"---------------------------------------",log)
    parent.SendMessage(dut_id,"Start Time:"+time.ctime()+"",log)
    parent.SendMessage(dut_id,"Scan MAC address:"+mac+"",log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log)
    '''
    parent.SendMessage(dut_id,"Wait ATOM Boot Ready...",log)
    #data=lWaitCmdTerm(term,"ifconfig",promp,5)
    parent.SendMessage(dut_id,lWaitCmdTerm(term,"ifconfig",promp,5)+'',log)
    parent.SendMessage(dut_id,"ATOM boot ready time: %3.2f (sec)"%(time.time()- test_time),log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)
    data=lWaitCmdTerm(term,"ifconfig",promp,5); #print data
    if 'wlan0_0' in data or 'wlan1_0' in data: return 1
    else: return 0

def USBTest(parent,dut_id,term,log):
    parent.SendMessage(dut_id,"USB2.0 Test...",log)   
    test_time=time.time()
    while time.time()-test_time<10:
        data=lWaitCmdTerm(term,"mount",promp,5); print data
        if '/tmp/mnt/diska1' not in data: flag=0; time.sleep(1) 
        else:
           wr=lWaitCmdTerm(term,"echo 'MFGUSBTEST' > /tmp/mnt/diska1/test.txt && tail -n 1 /tmp/mnt/diska1/test.txt",promp,5,3); print wr
           d=lWaitCmdTerm(term,'rm -f /tmp/mnt/diska1/test.txt && tail -n 1 /tmp/mnt/diska1/test.txt',promp,15,3); print d
           if 'MFGUSBTEST' in wr and 'MFGUSBTEST' not in d: 
              parent.SendMessage(dut_id,"%s\n%s\nUSB test pass"%(wr,d),log)
              parent.SendMessage(dut_id, "USB test time: %3.2f (sec)"%(time.time()-test_time),log)
              parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log)
              return 1
           else: flag=1; time.sleep(1)
    if not flag: raise Except('ErrorCode[2000]: DUT Issue | USB mount fail:%s'%data)
    else: raise Except('ErrorCode[2000]: DUT Issue | USB R/W fail:%s'%wr)

def Reset_file(parent,dut_id,term,i,log):
    test_time=time.time()
    if i is '5G': folder='/nvram/cl2400/'
    elif i is '2G': folder='/nvram/cl2400_24g/'
    parent.SendMessage(dut_id,"[%s]Delete IQ/DC Cal. file "%i,log)
    while 1:
      if time.time()-test_time>20: raise Except("ErrorCode[2000]: DUT Issue | Delete File FAIL")
      #lWaitCmdTerm(term,"find %s -name *.ini -type f -delete && find %s -name *.txt -type f -delete"%(folder,folder),promp,5)
      #data= lWaitCmdTerm(term,"find %s -name *.ini -o -name *.txt -type f"%folder,promp,5)
      #if 'dc' in data or 'iq' in data or 'temp' in data: continue
      lWaitCmdTerm(term,"rm %s* -rf"%folder,promp,5)
      data= lWaitCmdTerm(term,"ls -l %s | wc -l"%folder,promp,5); print data
      file=data.split('\n'); print file
      if int(file[-1]): continue
      else: 
         data=lWaitCmdTerm(term,"ls %s -al"%folder,promp,5)
         parent.SendMessage(dut_id,"%s"%data,log)
         break
    parent.SendMessage(dut_id,"Delete file time: %3.2f (sec)"%(time.time()- test_time),log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)
    
def InitWifiProduction(parent,dut_id,chip,term,log):
    testflag=0
    test_time = time.time()
    parent.SendMessage(dut_id,"Init %s..."%chip[0],log)
    cmd_dict={'cl2432':'ce_host.sh production 24g',\
              'cl2430':'ce_host.sh production'}    
    term.get()
    data=lWaitCmdTerm(term,'%s'%cmd_dict[chip[0]],promp,80)
    if 'NOT detected' in data: lWaitCmdTerm(term,'%s'%cmd_dict[chip[0]],'does not exists',80)
    for re_try in xrange(3):
        term.get()
        data=lWaitCmdTerm(term,'ifconfig',promp,5); print data
        #term.get()
        #term<<'ifconfig'
        time.sleep(0.1)
        #data=term.get() 
        if chip[1] not in data: testflag=1; continue
        else: testflag=0; break                 
        parent.SendMessage(dut_id,'%s'%data,log)
    if testflag: raise Except("ErrorCode[2000]: DUT Issue | Production Mode FAIL")
    parent.SendMessage(dut_id,"Wifi Init time: %3.2f (sec)"%(time.time()- test_time),log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)

def InitWifiProduction(parent,dut_id,chip,term,log):
    testflag=0
    test_time = time.time()
    parent.SendMessage(dut_id,"Init %s..."%chip[0],log)
    if telnet:
        file={'cl2432':'cat /tmp/mnt/diska1/hub4_production_file/hub4_w11_mfg/ht_cl_prod_24g.sh',\
              'cl2430':'cat /tmp/mnt/diska1/hub4_production_file/hub4_w11_mfg/ht_cl_prod_5g.sh'}
    	cmd_dict={'cl2432':'sh -x /tmp/mnt/diska1/hub4_production_file/hub4_w11_mfg/ht_cl_prod_24g.sh',\
                  'cl2430':'sh -x /tmp/mnt/diska1/hub4_production_file/hub4_w11_mfg/ht_cl_prod_5g.sh'}        
    else:
        cmd_dict={'cl2432':'ce_host.sh production 24g',\
                  'cl2430':'ce_host.sh production'}    
    data=lWaitCmdTerm(term,'%s'%file[chip[0]],promp,3)
    if 'No such file' in data: raise Except("ErrorCode[2000]: Operating Issue | hub4_production_file not exists") 
    #term.get()
    data=lWaitCmdTerm(term,'%s'%cmd_dict[chip[0]],'does not exists',80)
    if 'NOT detected' in data: lWaitCmdTerm(term,'%s'%cmd_dict[chip[0]],'does not exists',80)
    for re_try in xrange(3):
        #term.get()
        data=lWaitCmdTerm(term,'ifconfig',promp,5); print data
        #term.get()
        #term<<'ifconfig'
        time.sleep(1)
        #data=term.get() 
        if chip[1] not in data: testflag=1; continue
        else: testflag=0; break                 
    if testflag: 
        parent.SendMessage(dut_id,data,log)
        if testflag: raise Except("ErrorCode[2000]: DUT Issue | [%s] Production Mode FAIL"%chip[1])
    parent.SendMessage(dut_id,"Wifi Init time: %3.2f (sec)"%(time.time()- test_time),log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)

def SetupMAC(parent,dut_id,chip,rfmac,rule,term,log):
    parent.SendMessage(dut_id," Setup %s WIFI MAC... "%chip[0],log)
    test_time=time.time()
    mac = "%012X"%(int(rfmac,16)+int(rule))
    mac=mac.upper()
    wifimac = mac[0:2]+":"+mac[2:4]+":"+mac[4:6]+":"+mac[6:8]+":"+mac[8:10]+":"+mac[10:12]
    lWaitCmdTerm(term,"iw %s e2p set mac %s"%(chip[1],wifimac),promp,5,2)
    data=lWaitCmdTerm(term,"iw %s e2p get mac"%(chip[1]),promp,5,2)
    if wifimac.lower() not in data: raise Except('ErrorCode[2000]: DUT Issue | [%s] set mac'%chip[0])
    parent.SendMessage(dut_id,"%s"%data ,log) 
    parent.SendMessage(dut_id, "WIFI MAC setup time: %3.2f (sec)"%(time.time()-test_time),log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log)
######################################    
#argv : term,cbterm,bp,bw,freqplan,log
def FreqCalibrate(parent,ni,dut_id,term,chip_type,AntChOffsetTab,freq_offset,log):
    #chip_type=[chip,interface,[start_freq,default_channel]]
    test_time = time.time()
    parent.SendMessage(dut_id,"%s Frequency Offset Calibrate Start..."%chip_type[0],log)
    #freqOffset = GetOffset(term,chip_type,interface)
    retry=0
    samplingTimeSecs=0.0001
    if chip_type[0] is 'cl2432': #2.4G
       rfFreqMHz=int(chip_type[2][0])+(int(chip_type[2][1])-1)*5; #print rfFreqMHz
       rfFreqHz=(int(chip_type[2][0])+(int(chip_type[2][1])-1)*5)*1000000; #print rfFreqHz     
    elif chip_type[0] is 'cl2430': #5G
       rfFreqMHz=int(chip_type[2][0])+(int(chip_type[2][1])-36)*5; #print rfFreqMHz
       rfFreqHz=(int(chip_type[2][0])+(int(chip_type[2][1])-36)*5)*1000000; #print rfFreqHz 
    extAttenDb=SearchPathLossTable(AntChOffsetTab,0,int(chip_type[2][1])); #print extAttenDb
    triggerLevelDb=-25
    rfAmplDb=4+5-extAttenDb #gain 5
   
    #ni.RFSAConfig(int(rfFreqHz/1000000), extAttenDb, "BW20", chip_type[3][3][1], 0, 10, "ON")
    ni.RFSAConfig(rfFreqMHz, extAttenDb, "BW20", chip_type[3][3][1], 0, 10, "ON")
    parent.SendMessage(dut_id,"%s OSC Value    OSC Freq(Hz)"%chip_type[0],log)
    parent.SendMessage(dut_id,"------------------------------------------------",log)    
    cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],\
                    'mode %s'%chip_type[3][3][0],'txlen 1280','txcnt 10000000',\
                    'channel %s'%chip_type[2][1],'ant 0',\
                    'TXFREQOFFSET 36','pow 20 20 20 0','txframe']
    for cmd in cmd_sequential:
        lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
    while 1:
        retry+=1             
        lWaitCmdTerm(term,"iw %s ATE TXFREQOFFSET %d"%(chip_type[1],freq_offset),promp,5)         
        ni.RFSAConfig(rfFreqMHz, extAttenDb, "BW20", chip_type[3][3][1], 0, 13, "ON")
        time.sleep(0.3)
        result=ni.RFSARead(); #print result
        if (not result) or (result["Power"] == -100):
           if (retry > 3): raise Except ("ErrorCode[2000]: DUT Issue | [%s] lo measure signal FAIL"%chip_type[0])
           parent.SendMessage(dut_id, " -Measure failed >> %s, Retry: %d"%(result,retry), log, color=0)
           continue        
        freq_err_ppm =(result["FreqErr"]/rfFreqHz)*1000000
        #freq_err_ppm =round((result["FreqErr"]*1000000)/rfFreqMHz,1)                
        msg="frequency offset index=%d, freq error=%.2f ppm"%(freq_offset,freq_err_ppm)
        if (freq_err_ppm<freq_cal_err[0]) or (freq_err_ppm>freq_cal_err[1]):
            parent.SendMessage(dut_id," -Retry%d %s"%(retry,msg),log) 
            freq_offset+=round(freq_err_ppm,0)               
            if retry>20:
                parent.SendMessage(dut_id,"%s Frequency offset calibrate fail"%chip_type[0],log,color=1)
                raise Except ("ErrorCode[2000]: DUT Issue | %s Freq Offset Calibratet FAIL"%chip_type[0])   
        else:           
            lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd_sequential[0]),promp,5)
            lWaitCmdTerm(term,"iw %s e2p set freq_offset %d"%(chip_type[1],freq_offset),promp,5)            
            break
    while 1:
        try:
           freqOffset=lWaitCmdTerm(term,"iw %s e2p get freq_offset"%chip_type[1],promp,5)
           freqOffset=int(freqOffset.split('set')[-1].split(promp)[0]); #print freqOffset
           if freqOffset==freq_offset: break
           else: lWaitCmdTerm(term,"iw %s e2p set freq_offset %d"%(chip_type[1],freq_offset),promp,5)
        except: 
           if times==9: raise Except ("ErrorCode[2000]: DUT Issue | FAIL - freqoffset set error (%s)"%freqOffset)
           else: continue
    parent.SendMessage(dut_id,"[%s] frequency offset index=%d, freq error=%.2f (%.2f~%.2f) ppm"%(chip_type[0],freq_offset,freq_err_ppm,freq_cal_err[0],freq_cal_err[1]),log,color=2)
    parent.SendMessage(dut_id,"Store %s freq. offset value = %s to EEPROM Done"%(chip_type[0],freq_offset),log)
    parent.SendMessage(dut_id, "%s Freq Calibrate Test time: %3.2f (sec)"%(chip_type[0],(time.time()- test_time)),log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)

def CalTxPower(parent,ni,dut_id,term,chip_type,AntChOffsetTab,cal_freq,log):    
    #cluster by ant
    test_time = time.time()
    testfail=0
    channel_list=list()
    for band in sorted(chip_type[3][0].keys()):
        channel_list+=chip_type[3][0][band][0]
    evm_criteria=int(chip_type[3][2])
    for times in xrange(10):
        try:
           freqOffset=lWaitCmdTerm(term,"iw %s e2p get freq_offset"%chip_type[1],promp,5)
           freqOffset=int(freqOffset.split('set')[-1].split(promp)[0]); print freqOffset
           break
        except: 
           if times==9: raise Except ("ErrorCode[2000]: DUT Issue | freqoffset get error (%s)"%freqOffset)
           else: continue 
    #parent.SendMessage(dut_id,"[%s] Calibrate Tx Power...(Cal Power:%d(%s), Freq. Offset:%s)"%(chip_type[0],cal_pwr,CAL_METHOD[0],freqOffset),log)
    #parent.SendMessage(dut_id,"**************************************************",log)    
    pivot_channel=' '.join(channel_list); print pivot_channel
    #lWaitCmdTerm(term,"iw %s cecli temp_loop 0"%chip_type[1],promp,5)
    lWaitCmdTerm(term,"iw %s ATE vector reset"%chip_type[1],promp,5)
    lWaitCmdTerm(term,"iw %s ATE vector %s"%(chip_type[1], pivot_channel),promp,5)
    cmd_sequential=['stop','stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                    'TXFREQOFFSET %s'%freqOffset] #default txlen is 1024, bw 0    
    for chain in xrange(int(chip_type[4])):
        for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
        for cal_pwr in sorted(chip_type[3][0].keys()):
            gain=[0,0,0]
            for channel in chip_type[3][0][cal_pwr][0]: 
                #parent.SendMessage(dut_id,"[%s] Calibrate Tx Power...(Cal Power:%s(%s), Freq. Offset:%s)"%(chip_type[0],cal_pwr,CAL_METHOD[0],freqOffset),log)
                #parent.SendMessage(dut_id,"**************************************************",log)
                gain_record=list(); diffPwr_record=list(); current_record=tuple()
                retry=0; no_result_cnt=0; over_pwr_cnt=0; cal_retry=0
                pathloss = SearchPathLossTable(AntChOffsetTab,int(chain),int(channel)); print pathloss
                compensation=pathloss+connector_loss[chain][cal_freq]
                if chip_type[0] is 'cl2432':
                   rfFreqMHz = int(chip_type[2][0])+(int(channel)-1)*5; print rfFreqMHz
                   #rfFreqHz=(int(chip_type[2][0])+((int(channel)-1)*5))*1000000; print rfFreqHz     
                elif chip_type[0] is 'cl2430':
                   rfFreqMHz = int(chip_type[2][0])+(int(channel)-36)*5; print rfFreqMHz
                   #rfFreqHz=(int(chip_type[2][0])+((int(channel)-36)*5))*1000000; print rfFreqHz 
            
                ni.RFSAConfig(rfFreqMHz,compensation,"BW20",chip_type[3][3][1],1,float(cal_pwr),"ON","OFF")
                
                #cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                #                'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                #                'ant %s'%chain,'txframe']
                cmd_sequential=['txcnt 10000000','channel %s'%channel,'ant %s'%chain,'txframe'] # default: channel <channel>
                for cmd in cmd_sequential: 
                    lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                #parent.SendMessage(dut_id," Tx%s: ch:%s p_loss=%.2f+%.2f "%(chain,channel,pathloss,connector_loss[chain][cal_freq]),log)
                parent.SendMessage(dut_id,"[%s] Calibrate Tx%s ch%s Power...(Cal Power:%s(%s), Freq. Offset:%s, p_loss=%.2f+%.2f)"%(chip_type[0],chain,channel,cal_pwr,CAL_METHOD[0],freqOffset,pathloss,connector_loss[chain][cal_freq]),log)
                ALENgth=150
                while 1:                
                    #cmd_sequential=['txcnt 10000000','channel %s'%channel,'ant %s'%chain,'txframe'] # default: channel <channel>
                    #for cmd in cmd_sequential: 
                        #lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    if cal_retry>5: raise Except ("ErrorCode[2000]: DUT Issue | [%s] TX%s Power Abnormal"%(chip_type[0],chain))
                    if not retry: gain[chain]=int(chip_type[3][0][cal_pwr][1]) #gain[chain]=int(chip_type[3][5])
                    '''
                    cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                    'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                                    'ant %s'%chain]
                    for cmd in cmd_sequential: 
                        lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    '''
                    lWaitCmdTerm(term,"iw %s ATE pow %d %d %d 0"%(chip_type[1],gain[0],gain[1],gain[2]),promp,5)
                    #lWaitCmdTerm(term,"iw %s ATE txframe"%(chip_type[1]),promp,5)
                    ni.RFSAConfig(rfFreqMHz,compensation,"BW20",chip_type[3][3][1],1,float(cal_pwr),"ON","OFF",ALENgth)
                    result=ni.RFSARead(); print (result)
                    if not result or int(result["Power"]) == -100:
                       no_result_cnt+=1
                       #ALENgth+=(50*no_result_cnt)                       
                       if no_result_cnt > 30: 
                          if run_flow: parent.SendMessage(dut_id, " FAIL - No signal (Chain%s)"%chain, log, color=1); testfail=1; break
                          else: raise Except ("ErrorCode[2000]: DUT Issue | [%s] TX Power Measure FAIL"%chip_type[0])
                       #parent.SendMessage(dut_id, "Measure(%d)> %s"%(no_result_cnt, result), log, color=0)
                       cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                       'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                                       'ant %s'%chain,'txframe']
                       for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                       continue        
                    
                    ###sort method####
                    #evm=round(result["EVM"],1)
                    diffPwr=round(round(result["Power"],1)-float(cal_pwr),1)
                    
                    if abs(diffPwr)>7:  ###avoid hardware issue to cause nustable output power | threshold set as 7(experience)###
                       if over_pwr_cnt > 5:
                          print diffPwr
                          if run_flow: parent.SendMessage(dut_id, " FAIL - Abnormal Output Power (Chain%s) | check default gain word"%chain, log, color=1); testfail=1; break
                          else: raise Except ("ErrorCode[2000]: DUT Issue | [%s] TX%s Power Abnormal | check default gain word--(Power:%s)"%(chip_type[0],chain,result["Power"]))
                       else: 
                          over_pwr_cnt+=1
                          cmd_sequential=['stop','stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                          'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                                          'ant %s'%chain,'txframe']
                          for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                          continue
                    '''
                    else:                    
                        gain_record.append(gain[chain]); print gain_record
                        diffPwr_record.append(diffPwr); print diffPwr_record
                        if len(gain_record)>1 and len(gain_record)==len(diffPwr_record):                   
                           if gain_record[-1]>=gain_record[0]:
                              if int(diffPwr_record[-1])>=int(diffPwr_record[0]):
                                 gain_diff=((gain_record[-1]-gain_record[0]))
                                 power_diff=math.ceil(abs(float(gain_diff)/2))
                                 _diffPwr=((diffPwr_record[-1]-diffPwr_record[0]))
                                 if abs(_diffPwr-power_diff) <= 1.5: gain[chain]=gain_record[-1]
                                 else: print 'gain power abnormal'; gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue      
                              else: gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue
                           elif gain_record[-1]<=gain_record[0]:
                               if int(diffPwr_record[-1])<=int(diffPwr_record[0]):
                                  gain_diff=(gain_record[0]-gain_record[-1])
                                  power_diff=math.ceil(abs(float(gain_diff)/2))
                                  _diffPwr=(diffPwr_record[0]-diffPwr_record[-1])
                                  if abs(_diffPwr-power_diff) <= 1.5: gain[chain]=gain_record[-1]
                                  else: print 'gain power abnormal'; gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue      
                               else: gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue
                           #else:cal_retry+=1; continue      
                    '''
                    no_result_cnt=0; retry+=1
                    current_record=(gain[chain],result["Power"],diffPwr); #raw_input(current_record)
                    gain_record.append(current_record); #raw_input(gain_record)
                    #parent.SendMessage(dut_id, " -%d: current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f EVM:%s"%(retry,gain[chain], result["Power"], diffPwr, evm), log, color=0)
                    parent.SendMessage(dut_id, " -%d: current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f"%(retry,gain[chain], result["Power"], diffPwr), log, color=0)
                    if abs(diffPwr)>CAL_METHOD[1]:
                       if abs(diffPwr)>=1.0: 
                          if diffPwr>0: pwrOffset=int(abs(round(diffPwr)))*2; gain[chain]-=pwrOffset
                          else: pwrOffset=int(abs(round(diffPwr)))*2; gain[chain]+=pwrOffset
                       elif 0.9<=abs(diffPwr)<=1: 
                          if diffPwr>0: gain[chain]-=1
                          else: gain[chain]+=1
                       if gain[chain]>63 or gain[chain]<=0: gain[chain]=int(chip_type[3][0][cal_pwr][1]); continue                           
                       if retry>=2:
                          cmd_sequential=['stop','stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                          'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                                          'ant %s'%chain,'txframe']
                          for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    else:  
                       if abs(diffPwr)<=0.2: break                                                            
                       if diffPwr>0: gain[chain]-=1
                       else: gain[chain]+=1                          
                       if gain[chain]>63 or gain[chain]<=0: gain[chain]=int(chip_type[3][0][cal_pwr][1]); continue
                    
                    if retry==5: 
                       len_cunt=len(gain_record)
                       while len_cunt>0:
                           len_cunt-=1
                           if abs(float(gain_record[len_cunt][2]))>CAL_METHOD[1]: gain_record.pop(len_cunt)   
                       if not len(gain_record):
                           if run_flow: 
                              #parent.SendMessage(dut_id, " FAIL - current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f, EVM:%s**************************************************"%(gain[chain], result["Power"], diffPwr,evm), log, color=1)
                              parent.SendMessage(dut_id, " FAIL - current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f**************************************************"%(current_record[0], current_record[1], current_record[2]), log, color=1)
                              testfail=1; break
                           else: raise Except ("ErrorCode[2000]: DUT Issue | [%s] TX Cal FAIL > Chain%s Channel%s Gain_idx:%s PwrDiff:%.1f"%(chip_type[0],chain,channel,current_record[0],current_record[2]))                            
                                 #raise Except ("[%s] TX Cal FAIL > Chain%s Channel%s Gain_idx:%s PwrDiff:%.1f EVM:%s"%(chip_type[0],chain,channel,gain[chain],diffPwr,evm))
                       while len(gain_record)>0:
                           #raw_input(gain_record)
                           if len(gain_record)==1: break
                           if abs(float(gain_record[-1][2]))<=abs(float(gain_record[(-2)][2])): gain_record.pop((-2)); #print 'previous-1'
                              #if (0-float(gain_record[-1][2]))<=(0-float(gain_record[(-2)][2])):gain_record.pop((-2)); print 'previous-2'
                              #else: gain_record.pop((-1)); print'last-2'
                           else: gain_record.pop((-1)); #print 'last-1'
                            
                       current_record=gain_record[-1]
                       break    
    
                retry=0; case=0
                while True:
                    try:
                        if not case:
                          msg='[%s] Get Temp.'%chip_type[0]
                          #parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5),log)
                          #lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5)
                          #lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5)
                          if temp_chip:
                             Tempt=lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5)
                             Tempt=int(Tempt.split('temperature')[-1].split('root')[0].strip()); #print Tempt
                          else:
                             Tempt=lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5)
                             Tempt=int(Tempt.split('External + Delta = ')[-1].split('\r\n')[0].strip()); #print Tempt

                          if Tempt<=0: 
                            retry+=1                                              
                            if retry==3:
                                lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5) 
                                parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5) ,log); 
                                parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5),log); 
                                #raise Except("[%s] Temperature abnormal")
                                Tempt=abs(Tempt); case=1; retry=0
                            else: continue
                          if Tempt>=Tempt_max: 
                             parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5) ,log); 
                             parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5),log);    
                             msg='[%s] Tempt. too high (%d)>%d'%(chip_type[0],Tempt,Tempt_max)
                             raise Except("ErrorCode[2000]: DUT Issue | %s"%msg)
                          else: case=1; retry=0
                        while case:
                          msg='[%s] Set e2p Calib'%chip_type[0]
                          parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s e2p set calib %d %s %d %s %d"%(chip_type[1],chain,channel,current_record[0],cal_pwr,Tempt),promp,5),log)
                          gain_code_data=lWaitCmdTerm(term,"iw %s e2p get calib %d %s"%(chip_type[1],chain,channel),promp,5)
                          gain_code=int(gain_code_data.split('parsed %s'%channel)[-1].split('root')[0].strip()); #print gain_code
                          if gain_code==int(current_record[0]): break
                          else: retry+=1
                          if retry==3: raise Except("ErrorCode[2000]: DUT Issue | [%s] Cal value dismatch"%(chip_type[0]))
                        break
                    except: 
                        if retry==3: raise Except("ErrorCode[2000]: DUT Issue | %s Fail"%msg)
                        else: retry+=1; continue 
                #parent.SendMessage(dut_id,"Tx:%s ch:%s PwrIdx=%s MeasurePwr=%.1f PwrDiff=%.1f EVM=%s Temperature=%s"%(chain,channel,gain[chain],result["Power"],diffPwr,evm,Tempt),log,color=2)
                parent.SendMessage(dut_id,"Tx:%s ch:%s PwrIdx=%s MeasurePwr=%.1f PwrDiff=%.1f Temperature=%s"%(chain,channel,current_record[0],current_record[1],current_record[2],Tempt),log,color=2)
                parent.SendMessage(dut_id,"**************************************************",log) 
                #break       

    parent.SendMessage(dut_id, "Power calibration test time: %3.2f (sec)"%(time.time()- test_time),log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log)
    return testfail

def CalTxPower(parent,ni,dut_id,term,chip_type,AntChOffsetTab,cal_freq,log):    
    #cluster by channel
    test_time = time.time()
    testfail=0
    channel_list=list()
    for band in sorted(chip_type[3][0].keys()):
        channel_list+=chip_type[3][0][band][0]
    evm_criteria=int(chip_type[3][2])
    for times in xrange(10):
        try:
           freqOffset=lWaitCmdTerm(term,"iw %s e2p get freq_offset"%chip_type[1],promp,5)
           freqOffset=int(freqOffset.split('set')[-1].split(promp)[0]); #print freqOffset
           break
        except: 
           if times==9: raise Except ("ErrorCode[2000]: DUT Issue | Freqoffset Get Error (%s)"%freqOffset)
           else: continue 
    #parent.SendMessage(dut_id,"[%s] Calibrate Tx Power...(Cal Power:%d(%s), Freq. Offset:%s)"%(chip_type[0],cal_pwr,CAL_METHOD[0],freqOffset),log)
    #parent.SendMessage(dut_id,"**************************************************",log)    
    pivot_channel=' '.join(channel_list); #print pivot_channel
    #lWaitCmdTerm(term,"iw %s cecli temp_loop 0"%chip_type[1],promp,5)
    lWaitCmdTerm(term,"iw %s ATE vector reset"%chip_type[1],promp,5)
    lWaitCmdTerm(term,"iw %s ATE vector %s"%(chip_type[1], pivot_channel),promp,5)
    cmd_sequential=['stop','start','bw 0','gi 0','mcs 7','mode 2','txlen 1280',\
                    'txcnt 10000000',] #default txlen is 1280, bw 0    
    for cal_pwr in sorted(chip_type[3][0].keys()):
        for channel in chip_type[3][0][cal_pwr][0]:        
            for chain in xrange(int(chip_type[4])):
                gain=[0,0,0]
                for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5) 
                #parent.SendMessage(dut_id,"[%s] Calibrate Tx Power...(Cal Power:%s(%s), Freq. Offset:%s)"%(chip_type[0],cal_pwr,CAL_METHOD[0],freqOffset),log)
                #parent.SendMessage(dut_id,"**************************************************",log)
                gain_record=list(); diffPwr_record=list(); current_record=tuple()
                retry=0; no_result_cnt=0; over_pwr_cnt=0; cal_retry=0
                pathloss = SearchPathLossTable(AntChOffsetTab,int(chain),int(channel)); #print pathloss
                compensation=pathloss+connector_loss[chain][cal_freq]
                if chip_type[0] is 'cl2432':
                   rfFreqMHz = int(chip_type[2][0])+(int(channel)-1)*5; #print rfFreqMHz
                   #rfFreqHz=(int(chip_type[2][0])+((int(channel)-1)*5))*1000000; print rfFreqHz     
                elif chip_type[0] is 'cl2430':
                   rfFreqMHz = int(chip_type[2][0])+(int(channel)-36)*5; #print rfFreqMHz
                   #rfFreqHz=(int(chip_type[2][0])+((int(channel)-36)*5))*1000000; print rfFreqHz 
            
                ni.RFSAConfig(rfFreqMHz,compensation,"BW20",chip_type[3][3][1],1,float(cal_pwr),"ON","OFF")
                
                #cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                #                'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                #                'ant %s'%chain,'txframe']
                cmd_sequential=['channel %s'%channel,'ant %s'%chain,'TXFREQOFFSET %s'%freqOffset,'pow 20 0 0 0','txframe','pow 20 0 0 0'] # default: channel <channel>
                for cmd in cmd_sequential: 
                    lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                #parent.SendMessage(dut_id," Tx%s: ch:%s p_loss=%.2f+%.2f "%(chain,channel,pathloss,connector_loss[chain][cal_freq]),log)
                parent.SendMessage(dut_id,"[%s] Calibrate Tx%s ch%s Power...(Cal Power:%s(%s), Freq. Offset:%s, p_loss=%.2f+%.2f)"%(chip_type[0],chain,channel,cal_pwr,CAL_METHOD[0],freqOffset,pathloss,connector_loss[chain][cal_freq]),log)
                ALENgth=300
                while 1:                
                    #cmd_sequential=['txcnt 10000000','channel %s'%channel,'ant %s'%chain,'txframe'] # default: channel <channel>
                    #for cmd in cmd_sequential: 
                        #lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    if cal_retry>5: raise Except ("ErrorCode[2000]: DUT Issue | [%s]-TX%s Power Abnormal"%(chip_type[0],chain))
                    if not retry: gain[chain]=int(chip_type[3][0][cal_pwr][1]) #gain[chain]=int(chip_type[3][5])
                    '''
                    cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                    'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                                    'ant %s'%chain]
                    for cmd in cmd_sequential: 
                        lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    '''
                    lWaitCmdTerm(term,"iw %s ATE pow %d %d %d 0"%(chip_type[1],gain[0],gain[1],gain[2]),promp,5)
                    #lWaitCmdTerm(term,"iw %s ATE txframe"%(chip_type[1]),promp,5)
                    ni.RFSAConfig(rfFreqMHz,compensation,"BW20",chip_type[3][3][1],1,float(cal_pwr),"ON","OFF",ALENgth)
                    result=ni.RFSARead(); #print result["Power"]
                    if not result or int(result["Power"]) == -100:
                       no_result_cnt+=1
                       #ALENgth+=(50*no_result_cnt)                       
                       if no_result_cnt > 30: 
                          if run_flow: parent.SendMessage(dut_id, " FAIL - No signal (Chain%s)"%chain, log, color=1); testfail=1; break
                          else: raise Except ("ErrorCode[2000]: DUT Issue | [%s] TX Power Measure FAIL"%chip_type[0])
                       #parent.SendMessage(dut_id, "Measure(%d)> %s"%(no_result_cnt, result), log, color=0)
                       print'wait%d'%no_result_cnt
                       cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                       'txcnt 10000000','channel %s'%channel,'ant %s'%chain,'TXFREQOFFSET %s'%freqOffset,'pow %d %d %d 0'%(gain[0],gain[1],gain[2]),\
                                       'txframe','pow %d %d %d 0'%(gain[0],gain[1],gain[2])]
                       for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                       continue        
                    
                    ###sort method####
                    #evm=round(result["EVM"],1)
                    diffPwr=round(round(result["Power"],1)-float(cal_pwr),1)
                    
                    if abs(diffPwr)>7:  ###avoid hardware issue to cause nustable output power | threshold set as 7(experience)###
                       if over_pwr_cnt > 5:
                          print diffPwr
                          if run_flow: parent.SendMessage(dut_id, " FAIL - Abnormal Output Power (Chain%s) | check default gain word"%chain, log, color=1); testfail=1; break
                          else: raise Except ("ErrorCode[2000]: DUT Issue | [%s]-TX%s Power Abnormal | check default gain word--(Power:%s)"%(chip_type[0],chain,result["Power"]))
                       else: 
                          over_pwr_cnt+=1
                          cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                          'txcnt 10000000','channel %s'%channel,'ant %s'%chain,'TXFREQOFFSET %s'%freqOffset,'pow %d %d %d 0'%(gain[0],gain[1],gain[2]),\
                                          'txframe','pow %d %d %d 0'%(gain[0],gain[1],gain[2])]
                          for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                          continue
                    '''
                    else:                    
                        gain_record.append(gain[chain]); print gain_record
                        diffPwr_record.append(diffPwr); print diffPwr_record
                        if len(gain_record)>1 and len(gain_record)==len(diffPwr_record):                   
                           if gain_record[-1]>=gain_record[0]:
                              if int(diffPwr_record[-1])>=int(diffPwr_record[0]):
                                 gain_diff=((gain_record[-1]-gain_record[0]))
                                 power_diff=math.ceil(abs(float(gain_diff)/2))
                                 _diffPwr=((diffPwr_record[-1]-diffPwr_record[0]))
                                 if abs(_diffPwr-power_diff) <= 1.5: gain[chain]=gain_record[-1]
                                 else: print 'gain power abnormal'; gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue      
                              else: gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue
                           elif gain_record[-1]<=gain_record[0]:
                               if int(diffPwr_record[-1])<=int(diffPwr_record[0]):
                                  gain_diff=(gain_record[0]-gain_record[-1])
                                  power_diff=math.ceil(abs(float(gain_diff)/2))
                                  _diffPwr=(diffPwr_record[0]-diffPwr_record[-1])
                                  if abs(_diffPwr-power_diff) <= 1.5: gain[chain]=gain_record[-1]
                                  else: print 'gain power abnormal'; gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue      
                               else: gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue
                           #else:cal_retry+=1; continue      
                    '''
                    no_result_cnt=0; retry+=1
                    current_record=(gain[chain],result["Power"],diffPwr); #raw_input(current_record)
                    gain_record.append(current_record); #raw_input(gain_record)
                    #parent.SendMessage(dut_id, " -%d: current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f EVM:%s"%(retry,gain[chain], result["Power"], diffPwr, evm), log, color=0)
                    parent.SendMessage(dut_id, " -%d: current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f"%(retry,gain[chain], result["Power"], diffPwr), log, color=0)
                    if abs(diffPwr)>CAL_METHOD[1]:
                       if abs(diffPwr)>=1.0: 
                          if diffPwr>0: pwrOffset=int(abs(round(diffPwr)))*2; gain[chain]-=pwrOffset
                          else: pwrOffset=int(abs(round(diffPwr)))*2; gain[chain]+=pwrOffset
                       elif 0.9<=abs(diffPwr)<=1: 
                          if diffPwr>0: gain[chain]-=1
                          else: gain[chain]+=1
                       if gain[chain]>63 or gain[chain]<=0: gain[chain]=int(chip_type[3][0][cal_pwr][1]); continue                           
                       if retry>=2:
                          cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                          'txcnt 10000000','channel %s'%channel,'ant %s'%chain,'TXFREQOFFSET %s'%freqOffset,'pow %d %d %d 0'%(gain[0],gain[1],gain[2]),\
                                          'txframe','pow %d %d %d 0'%(gain[0],gain[1],gain[2])]
                          for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    else:  
                       if abs(diffPwr)<=0.2: break                                                            
                       if diffPwr>0: gain[chain]-=1
                       else: gain[chain]+=1                          
                       if gain[chain]>63 or gain[chain]<=0: gain[chain]=int(chip_type[3][0][cal_pwr][1]); continue
                    
                    if retry==5: 
                       len_cunt=len(gain_record)
                       while len_cunt>0:
                           len_cunt-=1
                           if abs(float(gain_record[len_cunt][2]))>CAL_METHOD[1]: gain_record.pop(len_cunt)   
                       if not len(gain_record):
                           if run_flow: 
                              #parent.SendMessage(dut_id, " FAIL - current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f, EVM:%s**************************************************"%(gain[chain], result["Power"], diffPwr,evm), log, color=1)
                              parent.SendMessage(dut_id, " FAIL - current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f**************************************************"%(current_record[0], current_record[1], current_record[2]), log, color=1)
                              testfail=1; break
                           else: raise Except ("ErrorCode[2000]: DUT Issue | [%s] TX Cal FAIL > Chain%s Channel%s Gain_idx:%s PwrDiff:%.1f"%(chip_type[0],chain,channel,current_record[0],current_record[2]))                            
                                 #raise Except ("[%s] TX Cal FAIL > Chain%s Channel%s Gain_idx:%s PwrDiff:%.1f EVM:%s"%(chip_type[0],chain,channel,gain[chain],diffPwr,evm))
                       while len(gain_record)>0:
                           #raw_input(gain_record)
                           if len(gain_record)==1: break
                           if abs(float(gain_record[-1][2]))<=abs(float(gain_record[(-2)][2])): gain_record.pop((-2)); #print 'previous-1'
                              #if (0-float(gain_record[-1][2]))<=(0-float(gain_record[(-2)][2])):gain_record.pop((-2)); print 'previous-2'
                              #else: gain_record.pop((-1)); print'last-2'
                           else: gain_record.pop((-1)); #print 'last-1'
                            
                       current_record=gain_record[-1]
                       break    
    
                retry=0; case=0
                while True:
                    try:
                        if not case:
                          msg='[%s] Get Temp.'%chip_type[0]
                          #parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5),log)
                          #lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5)
                          #lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5)
                          if temp_chip:
                             Tempt=lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5)
                             Tempt=int(Tempt.split('temperature')[-1].split('root')[0].strip()); #print Tempt
                          else:
                             Tempt=lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5)
                             Tempt=int(Tempt.split('External + Delta = ')[-1].split('\r\n')[0].strip()); #print Tempt

                          if Tempt<=0: 
                            retry+=1                                              
                            if retry==3:
                                lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5) 
                                parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5) ,log); 
                                parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5),log); 
                                #raise Except("[%s] Temperature abnormal")
                                Tempt=abs(Tempt); case=1; retry=0
                            else: continue
                          if Tempt>=Tempt_max: 
                             parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5) ,log); 
                             parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5),log);    
                             msg='[%s] Tempt. too high (%d)>%d'%(chip_type[0],Tempt,Tempt_max)
                             raise Except("ErrorCode[2000]: DUT Issue | %s"%msg)
                          else: case=1; retry=0
                        while case:
                          msg='[%s] Set e2p Calib'%chip_type[0]
                          parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s e2p set calib %d %s %d %s %d"%(chip_type[1],chain,channel,current_record[0],cal_pwr,Tempt),promp,5),log)
                          gain_code_data=lWaitCmdTerm(term,"iw %s e2p get calib %d %s"%(chip_type[1],chain,channel),promp,5)
                          gain_code=int(gain_code_data.split('parsed %s'%channel)[-1].split('root')[0].strip()); #print gain_code
                          if gain_code==int(current_record[0]): break
                          else: retry+=1
                          if retry==3: raise Except("ErrorCode[2000]: DUT Issue | [%s] Cal value dismatch"%(chip_type[0]))
                        break
                    except: 
                        if retry==3: raise Except("ErrorCode[2000]: DUT Issue | %s Fail"%msg)
                        else: retry+=1; continue 
                #parent.SendMessage(dut_id,"Tx:%s ch:%s PwrIdx=%s MeasurePwr=%.1f PwrDiff=%.1f EVM=%s Temperature=%s"%(chain,channel,gain[chain],result["Power"],diffPwr,evm,Tempt),log,color=2)
                parent.SendMessage(dut_id,"Tx:%s ch:%s PwrIdx=%s MeasurePwr=%.1f PwrDiff=%.1f Temperature=%s"%(chain,channel,current_record[0],current_record[1],current_record[2],Tempt),log,color=2)
                parent.SendMessage(dut_id,"**************************************************",log) 
                #break       

    parent.SendMessage(dut_id, "Power calibration test time: %3.2f (sec)"%(time.time()- test_time),log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log)
    return testfail
                    
def TxVerify(parent,ni,dut_id,term,chip_type,AntChOffsetTab,cal_freq,log): 
    #parent.SendMessage(dut_id,"%s Tx verify Start...| Target Power: %s"%(chip_type[0],chip_type[3][0]) ,log)
    parent.SendMessage(dut_id,"%s Tx verify Start..."%(chip_type[0]),log)
    test_time = time.time()
    testfail=0
    ht20_fail=0
    #cal_pwr=int(chip_type[3][0])
    for times in xrange(10):
        try:
           freqOffset=lWaitCmdTerm(term,"iw %s e2p get freq_offset"%chip_type[1],promp,5)
           freqOffset=int(freqOffset.split('set')[-1].split('root')[0].strip()); #print freqOffset
           break
        except: 
           if times==9: raise Except ("ErrorCode[2000]: DUT Issue | Freqoffset Get Error (%s)"%freqOffset)
           else: continue 
    ver_item=str()
    ver_flow=list()
    print_flow=dict()
    if cal_freq is '2G':
        flag=cl2432_ver_parameter['flag']
        if flag: ver_paramter=cl2432_ver_parameter['TX']
        else: print_flow=manual_flow
    else: 
        flag=cl2430_ver_parameter['flag']
        if flag: ver_paramter=cl2430_ver_parameter['TX']
        else: print_flow=manual_flow
    if flag:
        for channel in ver_paramter[0]:
            for mode in ver_paramter[1]:
                if mode is 'HT40_MCS7' and channel in [10,11,12,13]: continue
                else:
                    for ant in ver_paramter[2]:
                        ver_item="IQ_VERIFY_TX\t%d\t%s\tTX%d"%(channel,mode,ant); #print ver_item
                        ver_flow.append(ver_item)
        print_flow={cal_freq:ver_flow}
    #print print_flow   
    
    for i in range(len(print_flow[cal_freq])): 
        retry_flag=1
        retryCnt = 0
        msg = print_flow[cal_freq][i].split("\t")
        if "RX" in msg[0]: continue
        if msg[2] != 'HT20_MCS7':
           if just_ht20_mcs7: continue
           else: 
           	  Tx_Power_Offset= {'2G':2,'5G':2}
           	  msg_note="            alarm"
        else: 
           Tx_Power_Offset={'2G':1.5,'5G':1.5}
           msg_note="            Fail"
        # Defind Tx paramter              
        bwide=packet_dic[msg[2]][1]
        ant=int(msg[3][-1])
        mode=packet_dic[msg[2]][0]
        Evm_top=packet_dic[msg[2]][5]
        ni_bw=packet_dic[msg[2]][2] 
        ni_mode=packet_dic[msg[2]][6]
        mcs=packet_dic[msg[2]][8] 
        mode_bw=int(bwide)+int(mode)
        channel=int(msg[1])
        gain=['0']*int(chip_type[4])
        for key,value in chip_type[3][0].iteritems():
            if str(channel) in value[0]:
                cal_pwr=float(key)
        for times in xrange(10):
            try:
               gain_code=lWaitCmdTerm(term,"iw %s e2p get calib %d %d"%(chip_type[1],ant,channel),promp,5)
               gain_code=int(gain_code.split('parsed %d'%channel)[-1].split('root')[0].strip()); #print gain_code
               break
            except:
               if times==9: raise Except ("ErrorCode[2000]: DUT Issue | TX%d gain get error (%s)"%(ant, gain_code))
               else: continue 
        gain[ant]=str(gain_code); #print gain
        gain_str=' '.join(gain); #print gain_str 

        if chip_type[0] is 'cl2432':
               if bwide: rfFreqMHz = int(chip_type[2][0])+((int(channel)+2)-1)*5; #print rfFreqMHz
               else: rfFreqMHz = int(chip_type[2][0])+(int(channel)-1)*5; #print rfFreqMHz
        elif chip_type[0] is 'cl2430': rfFreqMHz = int(chip_type[2][0])+(int(channel)-36)*5; #print rfFreqMHz 
        TargetPower_Offset = Tx_Power_Offset[cal_freq]  
          
        cable_loss = SearchPathLossTable(AntChOffsetTab,ant,channel); #print cable_loss 
        cable_compensation = cable_loss + connector_loss[int(msg[3].strip()[-1])][cal_freq]         
        extAttenDb=cable_compensation

        '''
        if mode==0:
            mcs=3
            Verify_Power=cal_pwr
            rfAmplDb=Verify_Power+3-extAttenDb+5 #target power + Pk_Avg -cableloss + range
        elif mode==1:
            Verify_Power=cal_pwr
            rfAmplDb=Verify_Power+10-extAttenDb+5
            mcs=7 
        elif mode==2:
            Verify_Power=cal_pwr
            rfAmplDb=Verify_Power+10-extAttenDb+5
            mcs=7 
        else:
            Verify_Power=cal_pwr
            rfAmplDb=Verify_Power+10-extAttenDb+5
            if  packet_dic[msg[2]][0] == 4: mcs = 9 
            else: mcs=7
        '''
        if len(msg)>4:
            Verify_Power=float(msg[4])
            '''
            gain_offset=abs(float(cal_pwr)-int(Verify_Power))
            if not mode:
               if Verify_Power>=cal_pwr: adj_gain_code=(int(gain_code)-9)+int(gain_offset*2)
               else: adj_gain_code=(int(gain_code)-9)-int(gain_offset*2)
            else:
               if Verify_Power>=cal_pwr: adj_gain_code=int(gain_code)+int(gain_offset*2)
               else: adj_gain_code=int(gain_code)-int(gain_offset*2)
            gain[ant]=str(adj_gain_code); print gain
            gain_str=' '.join(gain); print gain_str
            '''   
        else: Verify_Power=cal_pwr

        parent.SendMessage(dut_id,"\n%d.%s , Path Loss: %.2f + %.2f"%(i,print_flow[cal_freq][i],cable_loss,connector_loss[int(msg[3][-1])][cal_freq]),log)
        parent.SendMessage(dut_id,"----------------------------------------------------------------------------------------------------",log)
        parent.SendMessage(dut_id,"freqOffset=%s | Cal_gain=%s | GainWord=%s"%(freqOffset,gain_code,gain[ant]),log)
        msg = print_flow[cal_freq][i].split("\t")
        msg_log = "%s, ch%s, %s, %s, "%(msg[0].strip(),msg[1].strip(),msg[2].strip(),msg[3].strip())         
        ALENgth=150
        #ni.RFSAConfig(rfFreqMHz,compensation,"BW20",chip_type[3][3][1],0,float(cal_pwr),"ON","OFF",ALENgth)
        ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode,0,Verify_Power,'ON','OFF')
        while retry_flag and (retryCnt<TX_RETRY_TIMES):            
            NI_testfail=0
            if temp_compensation: lWaitCmdTerm(term,"iw %s cecli temp_loop 1"%chip_type[1],promp,5)
            else: lWaitCmdTerm(term,"iw %s cecli temp_loop 0"%chip_type[1],promp,5)
            cmd_sequential=['stop','stop','start','bw %s'%bwide,'gi 0','mcs %d'%mcs,'mode %s'%mode,'txlen 1536',\
                            'txcnt 10000000','channel %d'%channel,'ant %d'%ant,'TXFREQOFFSET %s'%freqOffset,\
                            'pow %s 0'%gain_str,'txframe','pow %s 0'%gain_str]
            for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
            retry_flag=0; retryCnt+=1;
            #ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode,0,Verify_Power,fpkt_dic[mode])
            ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode,0,Verify_Power,'ON','OFF',ALENgth)
            time.sleep(0.1)
            result=ni.RFSARead(); #print result 
            if not result or int(result["Power"]) == -100:
                NI_testfail=1;retry_flag=1;
                #ALENgth+=(50*retryCnt) 
                #parent.SendMessage(dut_id, "Measure(%d)> %s"%(retryCnt, result),log,color=0)
                print '..'
                if retryCnt >=TX_RETRY_TIMES:
                    if run_flow: parent.SendMessage(dut_id, " FAIL - No signal (Chain%s)"%ant,log,color=1); retry_flag=1; break
                    else: raise Except ("ErrorCode[2000]: DUT Issue | No signal (Chain%s)"%ant)
                continue
                        
            Evm_msg= msg_log + "Evm = %.2f (<= %.2f) dB"%(result["EVM"],Evm_top)
            if result["EVM"]>Evm_top:
                Evm_msg=Evm_msg+msg_note
                retry_flag=1                
                
            #result["FreqErr"] =(result["FreqErr"]/rfFreqHz)*1000000
            result["FreqErr"] =(result["FreqErr"]/(rfFreqMHz*1000000))*1000000
            Freq_msg= msg_log + "Freq Err = %.2f (%.2f~%.2f) ppm"%(result["FreqErr"],(FREQ_AVG+FREQ_ERROR_LIMIT),(FREQ_AVG-FREQ_ERROR_LIMIT))            
            if abs(result["FreqErr"]-FREQ_AVG)>FREQ_ERROR_LIMIT:
                Freq_msg=Freq_msg+msg_note
                retry_flag=1
                     
            Power_msg= msg_log + "Power = %.2f (%.2f~%.2f) dBm"%(result["Power"],Verify_Power+TargetPower_Offset,Verify_Power-TargetPower_Offset)            
            if abs(result["Power"]-Verify_Power)>TargetPower_Offset:
                final=0
                if retryCnt==TX_RETRY_TIMES-1:
                   final,Power_msg=NIadj.evilsoul(msg_log,result['Power'],Verify_Power,TargetPower_Offset)
                if not final:   
                   Power_msg=Power_msg+msg_note
                   retry_flag=1
                
            Mask_msg= msg_log + "Spec Mask = %.2f (%.2f~%.2f) Percent"%(result["Mask"],Mask_top,Mask_low)
            if result["Mask"]<Mask_low or result["Mask"]>Mask_top:
                Mask_msg=Mask_msg+msg_note
                retry_flag=1
                
            LO_msg= msg_log + "LO Leakage = %.2f (%.2f~%.2f) dB"%(result["LoLeakage"],LO_Leakage_top,LO_Leakage_low)
            if result["LoLeakage"]<LO_Leakage_low or result["LoLeakage"]>LO_Leakage_top:
                LO_msg=LO_msg+msg_note
                retry_flag=1

            #print Spec Flat and LO Leakage
            if mode:
                Flat_msg= msg_log + "Spec Flat = %.2f (%.2f~%.2f) pt"%(result["Flatness"],Flat_top,Flat_low)
                if result["Flatness"]<Flat_low or result["Flatness"]>Flat_top:
                    Flat_msg=Flat_msg+msg_note
                    retry_flag=1
                '''    
                LO_msg= msg_log + "LO Leakage = %.3f (%.2f~%.2f) dB"%(result["LoLeakage"],LO_Leakage_top,LO_Leakage_low)
                if result["LoLeakage"]<LO_Leakage_low or result["LoLeakage"]>LO_Leakage_top:
                    LO_msg=LO_msg+"   Fail"
                    retry_flag=1
                '''    
            
            if not retry_flag or retryCnt>=TX_RETRY_TIMES :
                for msg in [Freq_msg,Evm_msg,Power_msg,Mask_msg,LO_msg]:
                    if "Fail" in msg:
                        testfail=1
                        parent.SendMessage(dut_id,msg + "",log,color=1)
                    else: parent.SendMessage(dut_id,msg + "",log,color=2)
                if mode:
                    for msg in [Flat_msg]:
                        if "FAIL" in msg:
                            testfail=1
                            parent.SendMessage(dut_id,msg + "",log,color=1)
                        else: parent.SendMessage(dut_id,msg + "",log,color=2)
                if testfail: 
                    if run_flow: parent.SendMessage(dut_id,"%s Tx verify FAIL"%chip_type[0],log,color=1)
                    else: raise Except ("ErrorCode[2000]: DUT Issue | [%s] Tx verify FAIL"%chip_type[0])

    if testfail or NI_testfail or not result:
        testfail=1 
        if run_flow: parent.SendMessage(dut_id,"%s Tx verify FAIL"%chip_type[0],log,color=1)
        else: raise Except ("ErrorCode[2000]: DUT Issue | [%s] Tx verify FAIL"%chip_type[0])
    else: parent.SendMessage(dut_id,"%s Tx verify PASS"%chip_type[0],log,color=2)
    lWaitCmdTerm(term,"iw %s ATE stop"%(chip_type[1]),promp,5)
    parent.SendMessage(dut_id, "%s Tx verify Test time: %3.2f (sec)"%(chip_type[0],(time.time()- test_time)),log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log)
    return testfail   
    
def RxVerify(parent,ni,dut_id,term,chip_type,AntChOffsetTab,cal_freq,log):
    parent.SendMessage(dut_id,"%s Rx verify Start..."%chip_type[0],log)
    test_time = time.time()
    testResult=0
    nCnt=0
    for times in xrange(10):
        try:
           freqOffset=lWaitCmdTerm(term,"iw %s e2p get freq_offset"%chip_type[1],promp,5)
           freqOffset=int(freqOffset.split('set')[-1].split('root')[0].strip()); #print freqOffset
           break
        except: 
           if times==9: raise Except ("ErrorCode[2000]: DUT Issue | Freqoffset Get Error (%s)"%freqOffset)
           else: continue 
    ver_item=str()
    ver_flow=list()
    print_flow=dict()
    if cal_freq is '2G':
        flag=cl2432_ver_parameter['flag']
        if flag: ver_paramter=cl2432_ver_parameter['RX']
        else: print_flow=manual_flow
    else: 
        flag=cl2430_ver_parameter['flag']
        if flag: ver_paramter=cl2430_ver_parameter['RX']
        else: print_flow=manual_flow
    if flag:
        for channel in ver_paramter[0]:
            for mode in ver_paramter[1]:
                if mode is 'HT40_MCS7' and channel in [10,11,12,13]: continue
                else:
                    for ant in ver_paramter[2]:
                        ver_item="IQ_VERIFY_RX\t%d\t%s\tRX%d"%(channel,mode,ant); #print ver_item
                        ver_flow.append(ver_item)
        print_flow={cal_freq:ver_flow}
    #print print_flow  
    
    for i in range(len(print_flow[cal_freq])):
        msg = print_flow[cal_freq][i].split("\t") 
        if "TX" in msg[0]: continue                
        bwide=packet_dic[msg[2]][1]
        ant=int(msg[3][-1])
        mode=packet_dic[msg[2]][0]
        Evm_top=packet_dic[msg[2]][5]
        ni_bw=packet_dic[msg[2]][2] 
        ni_mode=packet_dic[msg[2]][6] 
        mode_bw=int(bwide)+int(mode)
        ni_rate=packet_dic[msg[2]][7]
        channel=int(msg[1])
        mcs=packet_dic[msg[2]][8] 
        perLimit=packet_dic[msg[2]][4]
        cable_loss=SearchPathLossTable(AntChOffsetTab,ant,channel); #print cable_loss 
        cable_compensation=cable_loss+connector_loss[int(msg[3][-1])][cal_freq]
        nCnt+=1
        if mode == 2: 
            rx_mode = int(mode)+int(bwide); 
            #mcs=int(msg[2].split('_')[-1][-1])
        elif mode == 3: 
            rx_mode = int(mode)+int(bwide)-1; 
            #mcs=int(msg[2].split('_')[-1][-1])
        else: 
            rx_mode = int(mode)
            #if rx_mode == 0: mcs = 3
            #else:  mcs = 7
        

        if channel > 15: 
            rfFreqHz=(5180+(channel-36)*5)*1000000
            rfFreqMHz = (5180+(channel-36)*5)     
        else:               
            rfFreqHz=(2412+(channel-1)*5)*1000000
            rfFreqMHz = (2412+(channel-1)*5) 
        
        inputPwr = rfPower_dic[rx_mode][mcs]
        SweepTest=0
        if (len(msg) == 6): 
          SweepTest=1      
          sweepPwr=msg[4].split("~"); #print msg[4]; #raw_input('aaa')
          inputPwr=int(sweepPwr[0])
          sweepStep=int(msg[5])

        cmd_sequential=['stop','start','rx_mode %s'%mode,'bw %s'%bwide,'gi 0','mcs %d'%mcs,'mode %s'%mode,\
                        'channel %d'%channel,'ant %d'%ant,'TXFREQOFFSET %s'%freqOffset,'stat reset','stat']
        for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)        

        testItem = "%s , ch%s , %s , %s , "%(msg[0].strip(),msg[1].strip(),msg[2].strip(),msg[3].strip())  
        while True:   #SweepTest          
          parent.SendMessage(dut_id, "%d.%s InputPwr: %.1f, Path Loss: %.2f + %.2f"%(nCnt, testItem, inputPwr, cable_loss,connector_loss[int(msg[3][-1])][cal_freq]),log)
          parent.SendMessage(dut_id,"----------------------------------------------------------------------------------------------------",log)
          retryCnt=0; failCnt=0;
          interval=str(0.0001)
          while retryCnt<RX_RETRY_TIMES and failCnt<RX_RETRY_TIMES:
            MAC_hex=int('0x110000C0FFEE',16)+int(i)+int(failCnt)
            MAC=str(hex(MAC_hex)[:-1]); #print MAC
            if failCnt: interval= str(float(interval)+0.0002)
            if chip_type[0] is 'cl2432':
               if bwide: rfFreqMHz = int(chip_type[2][0])+((int(channel)+2)-1)*5
            lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd_sequential[-2]),promp,5)
            ni.RFGenerate(int(rfFreqMHz), cable_compensation, ni_bw, ni_mode, ni_rate, inputPwr,1000,MAC,interval)
            time.sleep((packet_dic[msg[2]][3]+0.5))
            try:
              data=lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd_sequential[-1]),promp,5)
              result=int(data.split('Rx success=')[-1].split('RSSI')[0].strip()); #print 'result:%d'%result
              if result>=1000: result=1000
              Per=((1000-result)/1000.0)*100.0               
              strPer="%s PER = %.3f (%.1f ~ 0.0) Percent"%(msg[3], Per, perLimit)   
            except ValueError:
              retryCnt+=1
              strPer="-%s : Fail to get the 'Stat'"%msg[3]
              parent.SendMessage(dut_id, "-%d: error to get the %s state"%(retryCnt,msg[3]),log)
              continue              
            if Per > perLimit:
              failCnt+=1
              strPer += "     Fail"
              parent.SendMessage(dut_id, "-Rty%d: Packetloss PER: %.3f"%(failCnt,Per),log)           
              cmd_sequential=['stop','start','rx_mode %s'%mode,'bw %s'%bwide,'gi 0','mcs %d'%mcs,'mode %s'%mode,\
                              'channel %d'%channel,'ant %d'%ant,'TXFREQOFFSET %s'%freqOffset,'stat reset','stat']
              for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)    
            else: break

          if "Fail" in strPer: 
            if run_flow: testResult=1; parent.SendMessage(dut_id, "%s"%strPer,log,color=1)
            else: raise Except ("ErrorCode[2000]: DUT Issue | %s"%strPer)
          else: 
          	parent.SendMessage(dut_id, "%s"%strPer,log,color=2); testResult=0
            
          if SweepTest:
            if abs(inputPwr) >= abs(int(sweepPwr[1])): break
            inputPwr-=sweepStep
          else: break
        
    if testResult:
        if run_flow: parent.SendMessage(dut_id,"%s Rx verify FAIL"%chip_type[0],log,color=1)
        else: raise Except ("ErrorCode[2000]: DUT Issue | [%s] Rx Verify FAIL..."%chip_type[0])
    else: parent.SendMessage(dut_id,"%s Rx verify PASS"%chip_type[0],log,color=2)
    parent.SendMessage(dut_id, "%s Rx Verify Test time: %3.2f (sec)"%(chip_type[0],(time.time()- test_time)),log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log)   
    return testResult

def Poweroffset(parent,dut_id,term,offset_table,log):
    parent.SendMessage(dut_id,"Setup Power offset table",log)
    test_time=time.time()
    failflag=0
    for retry in range(3):
      for band in xrange(3):
        if not failflag:
          parent.SendMessage(dut_id,"SET [%s]:%s"%(offset_table[band][0],offset_table[band][1]),log)
          lWaitCmdTerm(term,"nvram_set %s %s"%(offset_table[band][0],offset_table[band][1]),promp,5)        
      for band_ in xrange(3):
        data=lWaitCmdTerm(term,"nvram_get %s"%(offset_table[band_][0]),promp,5)
        table=''.join(offset_table[band_][1].split("\\"))
        if table in data: failflag=0; parent.SendMessage(dut_id,"GET [%s]:%s"%(offset_table[band_][0],data),log)
        else: failflag=1; break
      if not failflag: break
      elif retry == 2: raise Except("ErrorCode[2000]: DUT Issue | Poweroffset setup Fail >> [%s]:%s"%(offset_table[band_][0],data)) 
    parent.SendMessage(dut_id, "Power Offset setup time: %3.2f (sec)"%(time.time()-test_time),log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log)
    return 1

def ClverSetup(parent,dut_id,term,production_dirver,shipping_driver,log):
    test_time=time.time()
    failflag=0
    for retry in xrange(10):
        driver_version=lWaitCmdTerm(term,"cat /nvram/clver",promp,5)    
        if driver_version == production_dirver:
            lWaitCmdTerm(term,"echo %s > /nvram/clver"%shipping_driver,promp,5)
        if driver_version == shipping_driver: break
        if retry == 9: raise Except("ErrorCode[2000]: DUT Issue | /nvram/clver setup Fail") 
    parent.SendMessage(dut_id,"/nvram/clver is (%s)"%driver_version,log)
    parent.SendMessage(dut_id, "/nvram/clver setup time: %3.2f (sec)"%(time.time()-test_time),log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log)

def BootFromGA(parent,dut_id,arm_ip,time_out,log):
    test_time=time.time()  
    if not IsConnect(arm_ip,time_out): raise Except("ErrorCode[2000]: DUT Issue | Can't Ping Arm") 
    #term =htx_wifi.Telnet(cpu)    
    arm_term=Telnet_arm(parent,dut_id,arm_ip,log)
    lWaitCmdTerm(arm_term,'doc','docsis>',5)
    lWaitCmdTerm(arm_term,'bootfrom 1','changed to 1',5)
    lWaitCmdTerm(arm_term,'exit','>',5)
    arm_term<<'exit'
    parent.SendMessage(dut_id,"Boot from sector 1 setup time: %3.2f (sec)"%(time.time()- test_time),log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------\n",log)
    
def Sector_check(parent,dut_id,arm_ip,time_out,log):
    test_time=time.time()  
    if not IsConnect(arm_ip,time_out): raise Except("ErrorCode[2000]: DUT Issue | Can't Ping Arm") 
    #term =htx_wifi.Telnet(cpu)    
    arm_term=Telnet_arm(parent,dut_id,arm_ip,log)
    lWaitCmdTerm(arm_term,'doc','docsis>',5)
    data=lWaitCmdTerm(arm_term,'dir','docsis>',5)
    parent.SendMessage(dut_id,data,log)
    if 'Selected sector is 1'in data: 
        data=lWaitCmdTerm(arm_term,'bootfrom 2','changed to 2',5)
        parent.SendMessage(dut_id,"boot sector switched 2 done. Plz reboot..",log)
        raise Except("ErrorCode[2000]: Operating Issue | Default Boot Sector Wrong") 
    lWaitCmdTerm(arm_term,'exit','>',5)
    arm_term<<'exit'
    parent.SendMessage(dut_id,"Boot Sector check time: %3.2f (sec)"%(time.time()- test_time),log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------\n",log)

def Sector_check_switch(parent,dut_id,arm_ip,time_out,log):
    test_time=time.time()  
    if not IsConnect(arm_ip,time_out): raise Except("ErrorCode[2000]: DUT Issue | Can't Ping Arm") 
    arm_term=Telnet_arm(parent,dut_id,arm_ip,log)
    lWaitCmdTerm(arm_term,'doc','docsis>',5)
    data=lWaitCmdTerm(arm_term,'dir','docsis>',5)
    parent.SendMessage(dut_id,data,log)
    if 'Selected sector is 1'in data: 
        lWaitCmdTerm(arm_term,'bootfrom 2','changed to 2',5)
        arm_term << 'reboot'; time.sleep(5)
        if not IsConnect(arm_ip,5): parent.SendMessage(dut_id,"boot sector switched 2 done.",log)
        else: raise Except("ErrorCode[2000]: DUT Issue | Can't Ping Arm")
    parent.SendMessage(dut_id,"Boot Sector check time: %3.2f (sec)"%(time.time()- test_time),log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)
    parent.SendMessage(dut_id,"Rebooting..",log)
    time.sleep(30)