import os,time,traceback
from testlibs import *
from toolslib import *
from htx import Win32Message
import wx
import random
from NIWTS import *

execfile("config.ini")
execfile("IQ_DUT.ini")




##############################################
class Except:
    """    example:
        try:
            if ....:
                raise Except("Error!!")
        except Except, msg:
            print msg    """
    def __init__(self,msg):
        self.value = msg
    def __str__(self):
        return self.value
    def __repr__(self):
        return self.value
'''
def lWaitCmdTerm(term,cmd,waitstr,sec,count=1):
    for i in range(count):
        term << "%s"%cmd
        data = term.wait("%s"%waitstr,sec)
        if waitstr in data[-1]:
            return data[-1]
        term.get()
    raise Except("failed: %s,%s"%(cmd,data[-1].strip()))
'''

    
def lWaitCmdTerm(term,cmd,waitstr,sec,count=1):
    for i in range(count):
        term<<""
        term.get() 
        #time.sleep(0.2)
        term << "%s"%cmd
        data = term.wait("%s"%waitstr,sec)
        print data[-1]
        
        if "ttyS" in data[-1]:
            time.sleep(2)
            term<<""
            term.get()            
            #data = term.wait("%s"%promp,sec) 
            term << "%s"%cmd
            data = term.wait("%s"%waitstr,sec)
            #print data[-1]
        
        if waitstr in data[-1]:
            return data[-1]
        term<<""
        term.get()
    raise Except("failed: %s"%cmd)
    
def TelnetLogin(term,username=None,password=None):
    print "Telnet Login..."
    data = term.wait('login:',5)
    term<<username
    data = term.wait('Password:',5)
    term<<password
    data = term.wait('#',5)
    
    
#def SearchPathLossTable(AntChOffsetTab,ant,ch): 
#    for i in AntChOffsetTab:
#        if ant== i[0] and ch == i[1]:
#            return i[2] 

def ReadCompensation(filename,path=""):
    import glob
    result = []
    if not path:
        path = "."
    if path[-1] not in ["/","\\"]: path += "/"
    fs = glob.glob(path+filename+".*")
    if not fs:
        print "Can't read %s%s.*"%(path,filename)
        #parent.SendMessage("Can't read %s%s.*\n"%(path,filename),log)
    else:
        fs.sort()
        #print fs
        print "Read Compensation from:",fs[-1]
        #parent.SendMessage("Read Compensation from:\n"%fs[-1],log)
        for i in open(fs[-1]).readlines():
            if not i.strip(): continue
            if 'Loss' in i: continue
            ant,ch,offset = i.split(',')
            result.append((int(ant),
                           int(ch),
                           float(offset)))
    return result
    
    

def IQInitial():
    print "Initialize Lib."
    iqapi.LP_INIT_LIB()
    print "Reset Tester."
    iqapi.InitTester1(ip="%s"%IQip) 



    
def WaitWifiBoot(parent,dut_id,term,interface,log):
    test_time = time.time()
    parent.SendMessage(dut_id,"Wait DUT Boot Ready...\n" ,log)
    retry = 0
    while retry<100:
        retry = retry + 1 
        data=lWaitCmdTerm(term,"iwpriv %s stat"%interface,promp,10)
        print data
        if  "no private ioctls" in data:
            print "waiting for boot done.%d Retry"%retry            
            time.sleep(1)
        elif "Tx success" in data:
            print "Wifi boot done."
            break
        elif "Invalid command : stat" in data:
            log.set("waiting for boot done.%d Retry"%retry)            
            time.sleep(1)
        else:
            pass
    
    if retry>=100:
        raise Except("Wifi boot FAIL.")
    parent.SendMessage(dut_id,"DUT boot ready time: %3.2f (sec)\n"%(time.time()- test_time) ,log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------\n",log)
            
def ModifyBinFile(parent,term,log):
    test_time = time.time()
    parent.SendMessage("Fine tune e2p for Tx target power...\n" ,log)
    for i in ep2_bin.keys(): 
        if ep2_bin[i][:2]=='00': val_str = ep2_bin[i][2:]
        else: val_str = ep2_bin[i]
        lWaitCmdTerm(term,"iwpriv rai0 e2p %s=%s"%(i,ep2_bin[i]),":%s"%val_str,5)
    #lWaitCmdTerm(term,"ifconfig rai0 down"%interface,"forwarding state",5)
    #term.get()
    #lWaitCmdTerm(term,"ifconfig %s up"%interface,"forwarding state",20)
    #lWaitCmdTerm(term,"ifconfig rai0 up"%interface,"entering learning state",20)
    lWaitCmdTerm(term,"","#",5)
    parent.SendMessage( "Fine tune Tx power ready time: %3.2f (sec)\n"%(time.time()- test_time) ,log)
    parent.SendMessage( "---------------------------------------------------------------------------\n",log)

def SetWifiDefault(term,interface):
    print "Set default values for DUT..."
    lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATEDA=FF:FF:FF:FF:FF:FF"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATESA=00:0C:43:41:40:9A"%interface,promp,5) #
    lWaitCmdTerm(term,"iwpriv %s set ATEBSSID=00:11:22:33:44:55"%interface,promp,5)#Different in 3052 and 2880
    lWaitCmdTerm(term,"iwpriv %s set ATETXGI=0"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATETXLEN=1024"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATETXCNT=2000000"%interface,promp,5)
    

def Calcu_OSC_Index(start_index,stop_index): # 0 freq erro is the one we want
    target_freqError = (freq_cal_err[0]+freq_cal_err[1])/2
    k=(OSC_value[stop_index]-OSC_value[start_index])/(stop_index-start_index)
    cal_osc=int((target_freqError-OSC_value[stop_index])/k + stop_index)
    print "OSC value adjustment begin from %.2f"%cal_osc
    return cal_osc  

def Calcu_2G_Gain(parent,TX_Gain,dut_id,log): #including TX0 TX1
    test_fail = 0
    parent.SendMessage(dut_id,"Calculate 2G channels gain\n",log)
    parent.SendMessage(dut_id,"\n",log) 
    msg = "CH     "
    for i in range(2):
        msg = msg + "Gain%d    "%i
    parent.SendMessage(dut_id,msg + "\n",log)
    parent.SendMessage(dut_id,"-------------------------------------------------\n")
    parent.SendMessage(dut_id,"Befor Calculate...\n") 
    #IQ_CAL_TX_CHANNEL_2G
    CH_STRART = IQ_CAL_TX_CHANNEL_2G[0]
    CH_MID = IQ_CAL_TX_CHANNEL_2G[1]
    CH_END = IQ_CAL_TX_CHANNEL_2G[2]
    
    for channel in range(1,15):
        msg = "%d	 "%channel
        for i in range(2):
            #log.set("%d	 %d	 %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel]))
            msg = msg + "%d	 "%TX_Gain[i][channel] 
        parent.SendMessage(dut_id,msg + "\n",log)    
    parent.SendMessage(dut_id,"-------------------------------------------------\n")
    #for anten in range(2):
    for anten in range(2):
        for i in range(2,CH_MID):
            TX_Gain[anten][i]= (float(TX_Gain[anten][CH_MID]-TX_Gain[anten][CH_STRART])/float(CH_MID-CH_STRART))*(i-CH_STRART)+ TX_Gain[anten][CH_STRART] #Calculate the Gain of the other channels
            
            TX_Gain[anten][i]=int(round(TX_Gain[anten][i]))
            if TX_Gain[anten][i]>31 or TX_Gain[anten][i]<0:
                test_fail+=1
                parent.SendMessage(dut_id,"TX Gain Error (>31),Please Check the TX and Re-Cal.\n",log,1)
                return test_fail                      
        for i in range(7,CH_END):
            TX_Gain[anten][i]= (float(TX_Gain[anten][CH_END]-TX_Gain[anten][CH_MID])/float(CH_END-CH_MID))*(i-CH_MID)+ TX_Gain[anten][CH_MID] #Calculate the Gain of the other channels
            TX_Gain[anten][i]=int(round(TX_Gain[anten][i]))
            if TX_Gain[anten][i]>31 or TX_Gain[anten][i]<0:
                test_fail+=1
                parent.SendMessage(dut_id,"TX Gain Error (>31),Please Check the TX and Re-Cal.",log,1)
                return test_fail                 
        for i in range(14,15):
            TX_Gain[anten][i]=TX_Gain[anten][CH_END]
            if TX_Gain[anten][i]>31 or TX_Gain[anten][i]<0:
                test_fail+=1
                parent.SendMessage(dut_id,"TX Gain Error (>31),Please Check the TX and Re-Cal.",log,1)
                return test_fail 

    parent.SendMessage(dut_id,"Afrer Calculate\n",log)   
    for channel in range(1,15):
        #log.set("%d	 %d	 %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel]))
        msg = "%d	 "%channel
        for i in range(2):
            msg = msg + "%d	 "%TX_Gain[i][channel] 
        parent.SendMessage(dut_id,msg + "\n",log)
    return TX_Gain   

def Calcu_5G_2T2R_Gain(CH_STRART,CH_END): #including TX0 TX1
    print "Calculate 5G channels' gain"
    print "\n"
    print "CH     Gain0    Gain1"
    print "-----------------------"
   
    for anten in range(2):
        for i in range(CH_STRART+1,CH_END):
            TX_Gain[anten][i]= (float(TX_Gain[anten][CH_END]-TX_Gain[anten][CH_STRART])/float(CH_END-CH_STRART))*(i-CH_STRART)+ TX_Gain[anten][CH_STRART] #Calculate the Gain of the other channels
            
            TX_Gain[anten][i]=int(round(TX_Gain[anten][i]))
            if TX_Gain[anten][i]>48 or TX_Gain[anten][i]<0:
                raise Except("TX Gain Error (>48),Please Check the TX and Re-Cal.") #For HOT_DEBUG
                     
        
    print "Afrer Calculate" 
    if  CH_END == 161:
        for i in range(CH_END+1,CH_END+5):
            TX_Gain[0][i] = TX_Gain[0][CH_END]  #E2p last channel = 165
            TX_Gain[1][i] = TX_Gain[1][CH_END]  #E2p last channel = 165
             
        for channel in range(CH_STRART,CH_END+5):
            print "%d	 %d	 %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel])
    else:
        for channel in range(CH_STRART,CH_END+1):
            print "%d	 %d	 %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel])

def Calcu_5G_3T3R_Gain(term,CH_STRART,CH_END): #including TX0 TX1
    print "Calculate 5G channels' gain"
    print "\n"
    print "CH     Gain0    Gain1    Gain2"
    print "------------------------------"

    for anten in range(3):
        for i in range(CH_STRART+1,CH_END):
            TX_Gain[anten][i]= (float(TX_Gain[anten][CH_END]-TX_Gain[anten][CH_STRART])/float(CH_END-CH_STRART))*(i-CH_STRART)+ TX_Gain[anten][CH_STRART] #Calculate the Gain of the other channels

            TX_Gain[anten][i]=int(round(TX_Gain[anten][i]))
            if TX_Gain[anten][i]>48 or TX_Gain[anten][i]<0:
                raise Except("TX Gain Error (>31),Please Check the TX and Re-Cal.") #For HOT_DEBUG


    print "Afrer Calculate"
    if  CH_END == 161:
        for i in range(CH_END+1,CH_END+5):
            TX_Gain[0][i] = TX_Gain[0][CH_END]  #E2p last channel = 165
            TX_Gain[1][i] = TX_Gain[1][CH_END]  #E2p last channel = 165
            TX_Gain[2][i] = TX_Gain[2][CH_END]  #E2p last channel = 165
        for channel in range(CH_STRART,CH_END+5):
            print "%d	 %d	 %d  %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel],TX_Gain[2][channel])
    else:
        for channel in range(CH_STRART,CH_END+1):
            print "%d	 %d	 %d  %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel],TX_Gain[2][channel])
    
   
                
def Write_E2p_2G__TXPower(term,log):
    #print "Write EEPROM."
    for i in range(2,15,2):
        value0=hex(TX_Gain[0][i]<<8 | TX_Gain[0][i-1])
        value0=value0.split("0x")[-1].strip()
        value1=hex(TX_Gain[1][i]<<8 | TX_Gain[1][i-1])
        value1=value1.split("0x")[-1].strip()
        
        addr0=hex(0x50 + i) #for TX0
        addr0=addr0.split("0x")[-1].strip()
        addr1=hex(0x5E + i) #for TX1
        addr1=addr1.split("0x")[-1].strip()
        
        lWaitCmdTerm(term,"iwpriv ra0 e2p %s=%s"%(addr0,value0),promp,5) 
        lWaitCmdTerm(term,"iwpriv ra0 e2p %s=%s"%(addr1,value1),promp,5) 
    log.set("Write 2G Tx Power to EEPROM....Done")

def Write_E2p_2GTXPower(parent,TX_Gain,dut_id,term,chip_type,log):
    #print "Write EEPROM." 
    cnt = 1
    for i in range(len(chip_prameter_dic[chip_type][2][0])):
        for j in range(2):
            val = hex(TX_Gain[j][cnt+1]<<8 | TX_Gain[j][cnt])
            val = val.split("0x")[-1].strip()
            addr = chip_prameter_dic[chip_type][2][j][i]
            print lWaitCmdTerm(term,"iwpriv ra0 e2p %s=%s"%(addr,val),promp,5)
        cnt+=2
            
    parent.SendMessage(dut_id,"Write 2G Tx Power to EEPROM....Done\n",log)

def Write_2T2R_E2p_5GTXPower(term,interface):
    print "Write 5G Tx Power to EEPROM..."
    ch = [[36,38],[40,44],[46,48],[52,54],
          [56,60],[62,64],[100,102],[104,108],
          [110,112],[116,118],[120,124],[126,128],
          [132,134],[136,140],[149,151],[153,157],
          [159,161],[165,166]]
    for i in range(len(ch)):
        if ch[i][0] <> 165:
            value0=hex(TX_Gain[0][ch[i][1]]<<8 | TX_Gain[0][ch[i][0]])
            value1=hex(TX_Gain[1][ch[i][1]]<<8 | TX_Gain[1][ch[i][0]])
        else:
            value0=hex(TX_Gain[0][ch[i][0]])
            value1=hex(TX_Gain[1][ch[i][0]])
            
        value0=value0.split("0x")[-1].strip()
        value1=value1.split("0x")[-1].strip()        
        addr0=hex(0x78 + i*2) #for TX0
        addr0=addr0.split("0x")[-1].strip()
        addr1=hex(0xA6 + i*2) #for TX1
        addr1=addr1.split("0x")[-1].strip()
        
        print lWaitCmdTerm(term,"iwpriv rai0 e2p %s=%s"%(addr0,value0),promp,5) 
        print lWaitCmdTerm(term,"iwpriv rai0 e2p %s=%s"%(addr1,value1),promp,5) 

def Write_3T3R_E2p_5GTXPower(term,interface):
    #interface = int_dic[freq]
    print "Write 5G Tx Power to EEPROM..."
    ch = [[36,38],[40,44],[46,48],[52,54],
          [56,60],[62,64],[100,102],[104,108],
          [110,112],[116,118],[120,124],[126,128],
          [132,134],[136,140],[149,151],[153,157],
          [159,161],[165,166]]
    for i in range(len(ch)):
        if ch[i][0] <> 165:
            value0=hex(TX_Gain[0][ch[i][1]]<<8 | TX_Gain[0][ch[i][0]])
            value1=hex(TX_Gain[1][ch[i][1]]<<8 | TX_Gain[1][ch[i][0]])
            value2=hex(TX_Gain[2][ch[i][1]]<<8 | TX_Gain[2][ch[i][0]])
        else:
            value0=hex(TX_Gain[0][ch[i][0]])
            value1=hex(TX_Gain[1][ch[i][0]])
            value2=hex(TX_Gain[2][ch[i][0]])

        value0=value0.split("0x")[-1].strip()
        value1=value1.split("0x")[-1].strip()
        value2=value2.split("0x")[-1].strip()



        addr0=hex(0x96 + i*2) #for TX0
        addr0=addr0.split("0x")[-1].strip()
        addr1=hex(0xCA + i*2) #for TX1
        addr1=addr1.split("0x")[-1].strip()
        addr2=hex(0xFE + i*2) #for TX2
        addr2=addr2.split("0x")[-1].strip()

        print lWaitCmdTerm(term,"iwpriv %s e2p %s=%s"%(interface,addr0,value0),promp,5)
        print lWaitCmdTerm(term,"iwpriv %s e2p %s=%s"%(interface,addr1,value1),promp,5)
        print lWaitCmdTerm(term,"iwpriv %s e2p %s=%s"%(interface,addr2,value2),promp,5)


def LoadFromBinFile(term,chip_type,cal_freq,interface): #For 2.4G Only
    if chip_type == "RT3593" and cal_freq == "2.4G":  
        print lWaitCmdTerm(term,"iwpriv %s set bufferLoadFromBin=1"%interface,promp,5)
    else: pass
        
def CheckTCParameter(term,chip_type,cal_freq,interface,log):
    chk_flag = 0
    if chip_type == 'RT3593':
        freq_val = {"2.4G":0,"5G":1}
        data = lWaitCmdTerm(term,"iwpriv %s e2p 36"%interface,promp,5)
        data = data.split(']:0x')[1].split()[0]
        tc_flag = chip_prameter_dic[chip_type][5][0] 
        if data <> chip_prameter_dic[chip_type][5][1][tc_flag][3:].upper():
            chk_flag +=1  
        log.set("%s e2p 36=%s (%s)"%(interface,data,chip_prameter_dic[chip_type][5][1][tc_flag][3:].upper()))
        for i in chip_prameter_dic[chip_type][6][freq_val[cal_freq]].keys():
            data = lWaitCmdTerm(term,"iwpriv %s e2p %s"%(interface,i),promp,5)
            data = data.split(']:0x')[1].split()[0]
            if data <> chip_prameter_dic[chip_type][6][freq_val[cal_freq]][i].upper():
                chk_flag +=1 
            log.set("%s e2p %s=%s (%s)"%(interface,i,data,chip_prameter_dic[chip_type][6][freq_val[cal_freq]][i].upper()))
        if chk_flag > 0: print 'Check TC parameter Fail'
        else: log.set('Check TC parameter Pass\n')
        return chk_flag
    else: pass
     
######################################    
#argv : term,cbterm,bp,bw,freqplan,log
def FreqCalibrate(parent,ni,dut_id,term,chip_type,interface,cal_freq,AntChOffsetTab,log):
    test_time = time.time()
    parent.SendMessage(dut_id,"%s Freq Calibrate Start...\n"%cal_freq ,log)
    testfail = 0
    retry = 0
    samplingTimeSecs=0.0001
    port=dut_id+1
    if interface == 'ra0':
        channel = 6
        rfFreqMHz = 2412+(channel-1)*5 
        rfFreqHz=(2412+(channel-1)*5)*1000000 
    else:
        channel = 100
        rfFreqMHz = 5180+(channel-36)*5 
        rfFreqHz=(5180+(channel-36)*5)*1000000
    extAttenDb = SearchPathLossTable(AntChOffsetTab,0,channel)
    triggerLevelDb=-25
    rfAmplDb=4+5-extAttenDb #gain 5
    ni.RFSAConfig(rfFreqMHz,extAttenDb,"BW20","A_G",0,10)
    parent.SendMessage(dut_id,"%s OSC Value    OSC Freq(Hz)\n"%cal_freq ,log)
    parent.SendMessage(dut_id,"------------------------------------------------\n",log)    
    lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATETXANT=1"%interface,promp,5) 
    lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%d"%(interface,channel),promp,5)#Calibrate the freq at channel    
    lWaitCmdTerm(term,"iwpriv %s set ATETXBW=0"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATETXMODE=1"%interface,promp,5)  # ATETXMODE=1 OFDM
    lWaitCmdTerm(term,"iwpriv %s set ATETXMCS=7"%interface,promp,5) # ATETXMCS=7 OFDM 54MHz
    lWaitCmdTerm(term,"iwpriv %s set ATETXPOW0=5"%interface,promp,5)    
    for i in chip_prameter_dic[chip_type][0]:
        lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)
        lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,i),promp,5)        
        lWaitCmdTerm(term,"iwpriv %s set ATE=TXFRAME"%interface,promp,5)
        #result = ni.RFSAConfig(rfFreqMHz,extAttenDb,"BW20","A_G")
        result=ni.RFSARead()
        OSC_value[i] =(result["FreqErr"]/rfFreqHz)*1000000 
        
    try_freq_index = Calcu_OSC_Index(chip_prameter_dic[chip_type][0][0],chip_prameter_dic[chip_type][0][1])
    
    while 1:
        lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)
        lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,try_freq_index),promp,5)
        lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%d"%(interface,channel),promp,5)
        lWaitCmdTerm(term,"iwpriv %s set ATETXANT=1"%interface,promp,5)        
        lWaitCmdTerm(term,"iwpriv %s set ATE=TXFRAME"%interface,promp,5)              
        #result = ni.RFSAConfig(rfFreqMHz,extAttenDb,"BW20","A_G")
        result=ni.RFSARead()
        freq_err_ppm =(result["FreqErr"]/rfFreqHz)*1000000        
        
        if (freq_err_ppm  < freq_cal_err[0]) or (freq_err_ppm >freq_cal_err[1]):
            retry = retry + 1 
            parent.SendMessage(dut_id,"Retry %d freq %s index = %d, freq error = %.2f ppm\n"%(retry,cal_freq,try_freq_index,freq_err_ppm),log) 
            if retry>20:
                parent.SendMessage(dut_id,"%s Freq calibrate fail\n"%freq,log,color=1)
                testfail+=1
                raise Except ("%s Freq Calibratet FAIL"%cal_freq)   
                 
            if  freq_err_ppm > 0:
                try_freq_index =  try_freq_index + 1 
            else:
                try_freq_index =  try_freq_index - 1 
            if try_freq_index < 0: try_freq_index = 0
        else:
           
            lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTOP"%interface,promp,5)
            time.sleep(1)
            parent.SendMessage(dut_id,"%s freq index = %d, freq error = %.2f (%.2f~%.2f) ppm\n"%(cal_freq,try_freq_index,freq_err_ppm,freq_cal_err[0],freq_cal_err[1]),log,color=2) 
            term.get()
            data=lWaitCmdTerm(term,"iwpriv %s e2p %s"%(interface,chip_prameter_dic[chip_type][1]),promp,5)
            parent.SendMessage(dut_id,data + "\n",log) 
            if "[0x00%s]"%chip_prameter_dic[chip_type][1] in data:
                data=data.split("]:0x")[1].split("\n")[0].strip()
            X_value = "%X"%try_freq_index
            if len(X_value) < 2: X_value = "0"+ X_value  
            new_values = data[:2] + str(X_value)
            data = lWaitCmdTerm(term,"iwpriv %s e2p %s=%s"%(interface,chip_prameter_dic[chip_type][1],new_values),promp,5) 
            parent.SendMessage(dut_id,data + "\n",log)
            parent.SendMessage(dut_id,"Store %s OSC value = %s to EEPROM Done\n"%(cal_freq,new_values))            
            break
            #return testfail 
    
    parent.SendMessage(dut_id, "%s Freq Calibrate Test time: %3.2f (sec)\n"%(cal_freq,(time.time()- test_time)) ,log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------\n",log)

def Cal2GTxPower(parent,ni,dut_id,term,chip_type,interface,cal_freq,AntChOffsetTab,log):
    test_time = time.time()
    TX_Gain={} #store the Gain of each channel of both TX
    TX_Gain[0]=[1]*166
    TX_Gain[1]=[1]*166
    TX_Gain[2]=[1]*166
    parent.SendMessage(dut_id,"%s Power Calibrate Start...\n"%cal_freq ,log)
    testfail = 0
    extAttenDb=SearchPathLossTable(AntChOffsetTab,0,1)
    cal_gain=[None,None]
    IQ_CAL_TX_CHANNEL = IQ_CAL_TX_CHANNEL_2G
    CalPower = chip_prameter_dic[chip_type][3][0] 
    mode = 1
    mode_type = "54M"             
    freqOffset = GetOffset(term,chip_type,interface)
    parent.SendMessage(dut_id,"Calibrating %s %s ..\n"%(cal_freq,mode_type),log)
    parent.SendMessage(dut_id,"-------------------------------------------------------\n",log)
    lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)  
    lWaitCmdTerm(term,"iwpriv %s set ATETXMODE=%d"%(interface,mode),promp,5)  # For 0->b mode(cck), 1-> g mode(OFDM), 2->n mode 
    lWaitCmdTerm(term,"iwpriv %s set ATETXMCS=7"%interface,promp,5)#For msc7
    lWaitCmdTerm(term,"iwpriv %s set ATETXBW=0"%interface,promp,5)    
    lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,freqOffset),promp,5)  
    for channel in IQ_CAL_TX_CHANNEL:
        lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%d"%(interface,channel),promp,5)
        rfFreqHz=(2412+(channel-1)*5)*1000000
        rfFreqMHz=(2412+(channel-1)*5)
        gain = CalPower
        for j in range(2):
            cable_loss = SearchPathLossTable(AntChOffsetTab,j,channel)
            cable_compensation = cable_loss + connector_loss[j][cal_freq] 
            ni.RFSAConfig(rfFreqMHz,cable_compensation,"BW20","A_G",1,CalPower)
            lWaitCmdTerm(term,"iwpriv %s set ATETXANT=%d"%(interface,j+1),promp,5)  # Tx0=1, Tx1=2
            lWaitCmdTerm(term,"iwpriv %s set ATETXPOW%d=%d"%(interface,j,gain),promp,5)
            lWaitCmdTerm(term,"iwpriv %s set ATE=TXFRAME"%interface,promp,5)       
            retry = 0
            while 1:
                try:
                    result=ni.RFSARead()
                    
                    if abs(result["Power"] - CalPower) > IQ_CAL_TX_POWER_TOLERANCE:
                        retry = retry + 1 
                        parent.SendMessage(dut_id,"Retry %d Tx%d Ch%d gain = %d, power = %.2f\n"%(retry,j,channel,gain,result["Power"]),log) 
                        if retry>12:                        
                            testfail+=1
                            raise Except ("Tx power gain calibrate fail") 
                        if  (result["Power"] - CalPower) > 0:
                             gain =  gain - int(round(float(result["Power"] - CalPower)/0.5)) 
                        else:
                            gain =  gain + int(round(abs(float(result["Power"] - CalPower))/0.5))     
                        lWaitCmdTerm(term,"iwpriv %s set ATETXPOW%d=%d"%(interface,j,gain),promp,5)
                        lWaitCmdTerm(term,"iwpriv %s set ATE=TXFRAME"%interface,promp,5) 
                    else:
                        TX_Gain[j][channel] = gain
                        parent.SendMessage(dut_id,"Tx%d  ch %d p_loss %.2f+%.2f gain %d  power = %.2f   dBm (%.2f~%.2f)\n"%(j,channel,cable_loss ,connector_loss[j][cal_freq],gain,result["Power"],CalPower+IQ_CAL_TX_POWER_TOLERANCE,CalPower-IQ_CAL_TX_POWER_TOLERANCE),log,color=2) 
                        break
                except  KeyError:
                    retry+=1
                    if retry > 3: raise Except ("Tx measure no power") 
    #lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTOP"%interface,promp,5)              
    TX_Gain = Calcu_2G_Gain(parent,TX_Gain,dut_id,log)
    Write_E2p_2GTXPower(parent,TX_Gain,dut_id,term,chip_type,log)
    parent.SendMessage(dut_id, "2G power calibration test time: %3.2f (sec)\n"%(time.time()- test_time) ,log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------\n",log)

def Cal5GTxPower(parent,ni,dut_id,term,chip_type,interface,cal_freq,AntChOffsetTab,log):
    ch_val = None
    test_time = time.time()
    parent.SendMessage(dut_id,"%s Power Calibrate Start...\n"%cal_freq ,log)
    testfail = 0
    gain=[None,None]
    CalPower = chip_prameter_dic[chip_type][3][1][1]
    IQ_CAL_TX_POWER_TOLERANCE = 0.8
    mode = 1
    mode_type = "54M"             
    freqOffset = GetOffset(term,chip_type,interface)
    target_pwr = chip_prameter_dic[chip_type][3][1][mode] 
    parent.SendMessage(dut_id,"Calibrating %s %s ..\n"%(cal_freq,mode_type),log)
    parent.SendMessage(dut_id,"-------------------------------------------------------\n",log)
    lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATEAUTOALC=1"%interface,promp,5)   
    lWaitCmdTerm(term,"iwpriv %s set ATETXMODE=%d"%(interface,mode),promp,5)  # For 0->b mode(cck), 1-> g mode(OFDM), 2->n mode 
    lWaitCmdTerm(term,"iwpriv %s set ATETXMCS=7"%interface,promp,5)#For msc7
    lWaitCmdTerm(term,"iwpriv %s set ATETXBW=0"%interface,promp,5)
    #lWaitCmdTerm(term,"iwpriv %s set ATETXPOWEVAL=1"%interface,promp,5)    
    lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,freqOffset),promp,5) 
    for i in IQ_CAL_TX_CHANNEL_5G:
        channel = i     
        rfFreqMHz=5180+(channel-36)*5 
        for j in range(2):
            cable_loss = SearchPathLossTable(AntChOffsetTab,j,channel)
            cable_compensation = cable_loss + connector_loss[j][cal_freq]
            ni.RFSAConfig(rfFreqMHz,cable_compensation,"BW20","A_G",1,target_pwr)                                               
            addr = chip_prameter_dic[chip_type][2][j][channel]
            for c in range(3):                            
                try:
                    term.get()                            
                    data = lWaitCmdTerm(term,"iwpriv rai0 e2p %s"%addr,promp,5)
                    #parent.SendMessage(data + '\n',log)
                    if "[0x00%s]"%addr in data:
                        data=data.split("]:0x")[1].split("\n")[0].strip().upper()
                        break
                    else: 
                        if c == 2: raise Except ("FAIL iwpriv rai0 e2p %s"%addr)
                        else:
                            print "Retry %d iwpriv rai0 e2p %s"%addr 
                            time.sleep(0.2)
                            continue  
                except:
                    pass 
            g = int(data[2:],16)
            lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)
            lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%d"%(interface,channel),promp,5)
            lWaitCmdTerm(term,"iwpriv %s set ATETXANT=%d"%(interface,j+1),promp,5)  # Tx0=1, Tx1=2 
            #lWaitCmdTerm(term,"iwpriv %s set ATETXPOWEVAL=1"%interface,promp,5)
            lWaitCmdTerm(term,"iwpriv %s set ATETXPOW%d=%d"%(interface,j,g),promp,5)
            lWaitCmdTerm(term,"iwpriv %s set ATE=TXFRAME"%interface,promp,5)
            time.sleep(0.5)
            retry = 0
            while 1:
                result=ni.RFSARead()
                if not result:
                    lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)
                    lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%d"%(interface,channel),promp,5)
                    lWaitCmdTerm(term,"iwpriv %s set ATETXANT=%d"%(interface,j+1),promp,5)     
                    #lWaitCmdTerm(term,"iwpriv %s set ATETXPOWEVAL=1"%interface,promp,5)
                    lWaitCmdTerm(term,"iwpriv %s set ATE=TXFRAME"%interface,promp,5)
                    retry+=1
                    if retry>3: raise Except ("FAIL: No Tx Output Power")
                    continue                    
                if abs(result["Power"] - target_pwr) > IQ_CAL_5G_TX_POWER_TOLERANCE:   # Tx cal power tolrance
                    retry = retry + 1
                    parent.SendMessage(dut_id,"Retry %d Tx%d Ch%d, gain = %d power = %.2f\n"%(retry,j,channel,g,result["Power"]),log) 
                    if retry>6:                        
                        testfail+=1
                        raise Except ("Tune Tx power offset fail")
                    g = g-int(round((result["Power"] - target_pwr)*2))
                    lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)
                    lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%d"%(interface,channel),promp,5)
                    lWaitCmdTerm(term,"iwpriv %s set ATETXANT=%d"%(interface,j+1),promp,5)   
                    lWaitCmdTerm(term,"iwpriv %s set ATETXPOW%d=%d"%(interface,j,g),promp,5)
                    lWaitCmdTerm(term,"iwpriv %s set ATE=TXFRAME"%interface,promp,5)
                    time.sleep(0.5)
                else:
                    #parent.SendMessage("Tx%d  ch %d p_loss %.2f+%.2f offset addr=%s power = %.2f dBm offset = %.2f dBm\n"%(j,channel,cable_loss ,connector_loss[j][cal_freq],addr,result["power"],(result["power"] - target_pwr)),log,color=2)
                    #gain[j] = int(round((result["power"] - target_pwr)*2)) 
                    gain[j] = g
                    break
            
            #val = data[:2] + hex(int(data[2:],16)- gain[j])[2:]
            val = data[:2] + hex(gain[j])[2:]
            val = val.upper()
            if val[:2] == '00': val_str = val[2:]
            elif val[:1] == '0': val_str = val[1:]
            else: val_str = val 
            lWaitCmdTerm(term,"iwpriv rai0 e2p %s=%s"%(addr,val),":%s"%val_str,5)
            parent.SendMessage(dut_id,"Tx%d  ch %d p_loss %.2f+%.2f offset addr=%s gain=%d power = %.2f offset = %.2f value= %s\n"%(j,channel,cable_loss ,connector_loss[j][cal_freq],addr,g,result["Power"],(result["Power"] - target_pwr),val),log,color=2) 
    
    lWaitCmdTerm(term,"ifconfig rai0 down","forwarding state",5)
    term.get()
    lWaitCmdTerm(term,"ifconfig rai0 up","forwarding state",20)
    #lWaitCmdTerm(term,"ifconfig rai0 up"%interface,"entering learning state",20)
    lWaitCmdTerm(term,"","#",5)
    
    parent.SendMessage(dut_id, "5G power calibration test time: %3.2f (sec)\n"%(time.time()- test_time) ,log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------\n",log)


def GetOffset(term,chip_type,interface):
    for i in range(3):
        try:
            data=lWaitCmdTerm(term,"iwpriv %s e2p %s"%(interface,chip_prameter_dic[chip_type][1]),promp,5)
            if "[0x00%s]"%chip_prameter_dic[chip_type][1] in data:
                values=data.split("]:0x")[1].split("\n")[0].strip()
                return int(values[2:5],16)
                break
        except UnboundLocalError:
            term.get() 
    return int(values[2:5],16) 



def Get2GPower(parent,dut_id,term,chip_type,interface,log):
    parent.SendMessage(dut_id,"Read Tx e2p gain value.......\n",log)
    TX_Gain={} #store the Gain of each channel of both TX
    TX_Gain[0]=[1]*166
    TX_Gain[1]=[1]*166
    TX_Gain[2]=[1]*166
    pwr = [[],[],[]]
    msg = "Channel  "
    for i in range(2):
        addr = chip_prameter_dic[chip_type][2][i] 
        for j in range(len(addr)):
            for c in range(3):
                try:
                    data=lWaitCmdTerm(term,"iwpriv %s e2p %s"%(interface,addr[j]),promp,5)
                    print data
                    if "[0x00%s]"%addr[j] in data:
                        data=data.split("]:0x")[1].split("\n")[0].strip()
                        break
                except:
                    pass
            pwr[i].append(int(data[2:4],16)) #ch1
            pwr[i].append(int(data[0:2],16)) #ch2
           
        msg = msg +  "Gain%d 	 "%i
    msg = msg + ('\n') 
    msg = msg + "--------------------------------------------------\n"            
    for channel in range(1,15):
        msg = msg + "ch%d	 "%channel 
        for i in range(2):
            TX_Gain[i][channel] = pwr[i][channel-1]
            msg = msg + "%d	 "%TX_Gain[i][channel]
        msg = msg + ('\n')
    parent.SendMessage(dut_id,msg + "\n",log)
    return TX_Gain
    #print msg
    


 
def TxVerify(parent,ni,dut_id,term,chip_type,interface,cal_freq,AntChOffsetTab,log): 
    test_time = time.time()
    parent.SendMessage(dut_id,"%s Tx verify Start...\n"%chip_type ,log)
    
    testfail = 0
    bw_delta = 0
    pwrfail = 0
    #samplingTimeSecs=0.00017
    port=dut_id+1
    if cal_freq == "2G": 
        extAttenDb=SearchPathLossTable(AntChOffsetTab,0,1)
        #TX_Gain = Get2GPower(parent,dut_id,term,chip_type,interface,log)
    else: 
        extAttenDb=SearchPathLossTable(AntChOffsetTab,36,1)
                
    triggerLevelDb=-25.0
    result={}
    #freqOffset = GetOffset(term,chip_type,interface)
    freqOffset = 40
    for i in range(len(print_flow[cal_freq])): 
        retry_flag = 1
        retry_num = 0
        msg = print_flow[cal_freq][i].split("\t")
 
        if "RX" in msg[0]: continue  
        # Defind Tx paramter              
        channel=int(msg[1])
        bwide = packet_dic[msg[2]][1]
        ant = int(msg[3][-1])+1
        mode = packet_dic[msg[2]][0]
        Evm_top = packet_dic[msg[2]][5]
        ni_bw = packet_dic[msg[2]][2] 
        ni_mode = packet_dic[msg[2]][6]          
        if cal_freq == '5G':            
            mode_bw = int(bwide) + int(mode) 
            calpwr = chip_prameter_dic[chip_type][3][1][mode_bw]              
            rfFreqHz=(5180+(channel-36)*5)*1000000
            rfFreqMHz=(5180+(channel-36)*5)
        else:
            calpwr = chip_prameter_dic[chip_type][3][0] 
            rfFreqHz=(2412+(channel-1)*5)*1000000 
            rfFreqMHz=(2412+(channel-1)*5)
        
        #if chip_type == 'MT7612': TargetPower_Offset = 1.5
        #else: TargetPower_Offset=1.5 
        TargetPower_Offset = Tx_Power_Offset[cal_freq]      
        cable_loss = SearchPathLossTable(AntChOffsetTab,int(msg[3][-1]),channel)
        print cable_loss 
        cable_compensation = cable_loss + connector_loss[int(msg[3].strip()[-1])][cal_freq]         
        extAttenDb=cable_compensation
       
        if mode==0:
            mcs = 3
            Verify_Power=calpwr+ chip_prameter_dic[chip_type][4]
            rfAmplDb=Verify_Power+3-extAttenDb+5 #target power + Pk_Avg -cableloss + range
        elif mode==1:
            Verify_Power=calpwr
            rfAmplDb=Verify_Power+10-extAttenDb+5
            mcs = 7 
        elif mode==2:
            Verify_Power=calpwr
            rfAmplDb=Verify_Power+10-extAttenDb+5
            mcs = 7 
        else:
            Verify_Power=calpwr
            rfAmplDb=Verify_Power+10-extAttenDb+5
            if  packet_dic[msg[2]][0] == 4: mcs = 9 
            else: mcs = 7
        
        parent.SendMessage(dut_id,"\n",log)
        parent.SendMessage(dut_id,"%d.%s , Path Loss: %.2f + %.2f\n"%(i,print_flow[cal_freq][i],cable_loss,connector_loss[int(msg[3][-1])][cal_freq]),log)
        parent.SendMessage(dut_id,"----------------------------------------------------------------------------------------------------\n",log)
        #parent.SendMessage("freqOffset=%d , Full Packet=%d\n"%(freqOffset,fpkt_dic[mode]),log)
        parent.SendMessage(dut_id,"freqOffset=%d\n"%(freqOffset),log)
        msg = print_flow[cal_freq][i].split("\t")
        msg_log = "%s , ch%s , %s, %s , "%(msg[0].strip(),msg[1].strip(),msg[2].strip(),msg[3].strip())  
        if 0: 
            if int(packet_dic[msg[2]][1]) == 2:
                try:
                    for c in range(3):
                        data=lWaitCmdTerm(term,"iwpriv %s e2p 52"%interface,promp,5) # Check 80 BW power delta
                        #parent.SendMessage(data + "\n",log)
                        if "[0x0052]" in data: 
                            bw_val=data.split("]:0x")[1].split("\n")[0].strip().upper()
                        else:
                            if c == 2: raise Except ("FAIL iwpriv %s e2p 52"%interface)
                            else: continue
                except: pass
                if len(bw_val) < 3: data = '00' + bw_val
       
        ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode,0,Verify_Power,fpkt_dic[mode])
        lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)  #Stop AP function and enter ATE Command mode.
        #if chip_type == 'MT7612': lWaitCmdTerm(term,"iwpriv %s set ATEAUTOALC=1"%interface,promp,5)
        #lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%s"%(interface,msg[1]),promp,5)
        lWaitCmdTerm(term,"iwpriv %s set ATETXMODE=%s"%(interface,packet_dic[msg[2]][0]),promp,5)     
        lWaitCmdTerm(term,"iwpriv %s set ATETXMCS=%d"%(interface,mcs),promp,5)    
        lWaitCmdTerm(term,"iwpriv %s set ATETXBW=%s"%(interface,packet_dic[msg[2]][1]),promp,5)
        #if chip_type == 'MT7612': lWaitCmdTerm(term,"iwpriv %s set ATETXPOWEVAL=1"%interface,promp,5)        
        #lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,freqOffset),promp,5)#For debug
        lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,40),promp,5)
        #lWaitCmdTerm(term,"iwpriv %s set ATETXANT=%s"%(interface,ant),promp,5)
        #iqapi.SetVSA(rfFreqHz, rfAmplDb, port, extAttenDb,triggerLevelDb)       
        
        while (retry_flag>0) and  (retry_num<TX_RETRY_TIMES):
            retry_flag = 0
            retry_num += 1
            #print retry_num
            #lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)
                       
            #lWaitCmdTerm(term,"iwpriv %s set ATETXMODE=%s"%(interface,packet_dic[msg[2]][0]),promp,5)     
            #lWaitCmdTerm(term,"iwpriv %s set ATETXMCS=%d"%(interface,mcs),promp,5)    
            #lWaitCmdTerm(term,"iwpriv %s set ATETXBW=%s"%(interface,packet_dic[msg[2]][1]),promp,5)
            #lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,40),promp,5)
            lWaitCmdTerm(term,"iwpriv %s set ATETXANT=%s"%(interface,ant),promp,5)
            #lWaitCmdTerm(term,"iwpriv %s set ATETXPOW%d=%d"%(interface,ant-1,TX_Gain[ant-1][channel]),promp,5)
            lWaitCmdTerm(term,"iwpriv %s set ATETXPOW%d=%d"%(interface,ant-1,34),promp,5)
            lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%s"%(interface,msg[1]),promp,5)
            lWaitCmdTerm(term,"iwpriv %s set ATE=TXFRAME"%interface,promp,5)
            #time.sleep(0.1)
            if chip_type == 'MT7615': time.sleep(0.5) 
            #result = ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode)
            result=ni.RFSARead() 
            if not result:
                retry_flag+=1
                if retry_num >=TX_RETRY_TIMES: raise Except ("%s Tx measure signal FAIL"%chip_type)
                print "retry %d ......"%retry_num 
                continue
             
            
            Evm_msg= msg_log + "Evm = %.3f (%.2f~%.2f) dB"%(result["EVM"],Evm_top,Evm_low)
            if result["EVM"]<Evm_low or result["EVM"]>Evm_top:
                Evm_msg=Evm_msg+"   Fail"
                retry_flag += 1
            result["FreqErr"] =(result["FreqErr"]/rfFreqHz)*1000000
            Freq_msg= msg_log + "Freq Err = %.2f (%.2f~%.2f) ppm"%(result["FreqErr"],(FREQ_AVG+FREQ_ERROR_LIMIT),(FREQ_AVG-FREQ_ERROR_LIMIT))
            if abs(result["FreqErr"]-FREQ_AVG)>FREQ_ERROR_LIMIT:
                Freq_msg=Freq_msg+"   Fail"
                retry_flag += 1
                     
            Power_msg= msg_log + "Power = %.3f (%.2f~%.2f) dBm"%(result["Power"],Verify_Power+TargetPower_Offset,Verify_Power-TargetPower_Offset)
            if abs(result["Power"]-Verify_Power)>TargetPower_Offset:
                #if int(packet_dic[msg[2]][1]) == 2:
                if result["Power"] < (Verify_Power - TargetPower_Offset): pwrfail+=1
                Power_msg=Power_msg+"   Fail"
                retry_flag += 1
            Mask_msg= msg_log + "Spec Mask = %.3f (%.2f~%.2f) Percent"%(result["Mask"],Mask_top,Mask_low)
            if result["Mask"]<Mask_low or result["Mask"]>Mask_top:
                Mask_msg=Mask_msg+"   Fail"
                retry_flag += 1
            #print Spec Flat and LO Leakage
            if mode==1:
                Flat_msg= msg_log + "Spec Flat = %.3f (%.2f~%.2f) pt"%(result["Flatness"],Flat_top,Flat_low)
                if result["Flatness"]<Flat_low or result["Flatness"]>Flat_top:
                    Flat_msg=Flat_msg+"   Fail"
                    retry_flag += 1
                    
                LO_msg= msg_log + "LO Leakage = %.3f (%.2f~%.2f) dB"%(result["LoLeakage"],LO_Leakage_top,LO_Leakage_low)
                if result["LoLeakage"]<LO_Leakage_low or result["LoLeakage"]>LO_Leakage_top:
                    LO_msg=LO_msg+"   Fail"
                    retry_flag += 1
                    
            if retry_flag==0 or retry_num==TX_RETRY_TIMES :
                for msg in [Freq_msg,Evm_msg,Power_msg,Mask_msg]:
                    if "Fail" in msg:
                        testfail=testfail+1
                        parent.SendMessage(dut_id,msg + "\n",log,color=1)
                    else:
                        parent.SendMessage(dut_id,msg + "\n",log,color=2)
  
                if mode==1:
                    for msg in [Flat_msg,LO_msg]:
                        if "FAIL" in msg:
                            testfail=testfail+1
                            parent.SendMessage(dut_id,msg + "\n",log,color=1)
                        else:
                            parent.SendMessage(dut_id,msg + "\n",log,color=2)
        #if (dut_id == 1 and mode == 2): raw_input("pause")  
        #lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTOP"%interface,promp,5)
    if testfail > 0 or result == 0: raise Except ("%s Tx verify FAIL"%chip_type) 
    parent.SendMessage(dut_id, "%s Tx verify Test time: %3.2f (sec)\n"%(chip_type,(time.time()- test_time)) ,log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------\n",log)    

def TxVerifyDVT(parent,ni,dut_id,term,chip_type,interface,cal_freq,AntChOffsetTab,log): 
    test_time = time.time()
    parent.SendMessage(dut_id,"%s Tx verify Start...\n"%chip_type ,log)
    
    testfail = 0
    bw_delta = 0
    pwrfail = 0
    #samplingTimeSecs=0.00017
    port=dut_id+1
    if cal_freq == "2G": 
        extAttenDb=SearchPathLossTable(AntChOffsetTab,0,1)
        #TX_Gain = Get2GPower(parent,dut_id,term,chip_type,interface,log)
    else: 
        extAttenDb=SearchPathLossTable(AntChOffsetTab,36,1)
                
    triggerLevelDb=-25.0
    result={}
    #freqOffset = GetOffset(term,chip_type,interface)
    freqOffset = 40
    TargetPower_Offset = Tx_Power_Offset[cal_freq]
    bw_name = {2:"HT20",3:"HT40",4:"VHT20",5:"VHT40",6:"VHT40"}
    count = 0
    for mod in Tx_verify_mode_bw_rate.keys():
        for bwide in Tx_verify_mode_bw_rate[mod][0].keys(): 
            modbw = mod + bwide                 
            for channel in Tx_verify_mode_bw_rate[mod][0][bwide]:
                if cal_freq == '5G':            
                    Verify_Power = chip_prameter_dic[chip_type][3][1][modbw]              
                    rfFreqHz=(5180+(channel-36)*5)*1000000
                    rfFreqMHz=(5180+(channel-36)*5)
                else:
                    calpwr = chip_prameter_dic[chip_type][3][0] 
                    rfFreqHz=(2412+(channel-1)*5)*1000000 
                    rfFreqMHz=(2412+(channel-1)*5)
                for mcs in Tx_verify_mode_bw_rate[mod][1]:
                    if mod < 2: rate_name = packet_name[mod][mcs]
                    else: rate_name = "%s_MCS%d"%(bw_name[modbw],mcs)   
                    for ant in Tx_verify_ant:
                        
                        print mod,bwide,mcs,ant,channel
                        cable_loss = SearchPathLossTable(AntChOffsetTab,ant,channel)
                        print cable_loss 
                        cable_compensation = cable_loss + connector_loss[ant][cal_freq]
                        Evm_top = packet_dic[rate_name][5]
                        ni_bw = packet_dic[rate_name][2] 
                        ni_mode = packet_dic[rate_name][6]
                        count+=1
                            
       
        
        
                        parent.SendMessage(dut_id,"\n",log)
                        parent.SendMessage(dut_id,"%d.%s , Path Loss: %.2f + %.2f\n"%(count,"IQ_VERIFY_TX",cable_loss,connector_loss[ant][cal_freq]),log)
                        parent.SendMessage(dut_id,"----------------------------------------------------------------------------------------------------\n",log)
                        #parent.SendMessage("freqOffset=%d , Full Packet=%d\n"%(freqOffset,fpkt_dic[mode]),log)
                        parent.SendMessage(dut_id,"freqOffset=%d\n"%(freqOffset),log)
                        
                        msg_log = "%s , ch%s , %s, TX%d , "%("IQ_VERIFY_TX",channel,rate_name,ant)  
                        
                       
                        ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode,0,Verify_Power,fpkt_dic[mod])
                        lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)  #Stop AP function and enter ATE Command mode.
                        lWaitCmdTerm(term,"iwpriv %s set ATETXMODE=%d"%(interface,mod),promp,5)     
                        lWaitCmdTerm(term,"iwpriv %s set ATETXMCS=%d"%(interface,mcs),promp,5)    
                        lWaitCmdTerm(term,"iwpriv %s set ATETXBW=%d"%(interface,bwide),promp,5)
                        lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,40),promp,5)
                          
                        retry_flag = 1
                        retry_num = 0
                        while (retry_flag>0) and  (retry_num<TX_RETRY_TIMES):
                            retry_flag = 0
                            retry_num += 1
                            lWaitCmdTerm(term,"iwpriv %s set ATETXANT=%d"%(interface,ant+1),promp,5)
                            lWaitCmdTerm(term,"iwpriv %s set ATETXPOW%d=%d"%(interface,ant,34),promp,5)
                            lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%d"%(interface,channel),promp,5)
                            lWaitCmdTerm(term,"iwpriv %s set ATE=TXFRAME"%interface,promp,5)
                            #time.sleep(0.1)
                            if chip_type == 'MT7615': time.sleep(0.5) 
                            #result = ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode)
                            result=ni.RFSARead() 
                            if not result:
                                retry_flag+=1
                                if retry_num >=TX_RETRY_TIMES: raise Except ("%s Tx measure signal FAIL"%chip_type)
                                print "retry %d ......"%retry_num 
                                continue
                             
                            
                            Evm_msg= msg_log + "Evm = %.3f (%.2f~%.2f) dB"%(result["EVM"],Evm_top,Evm_low)
                            if result["EVM"]<Evm_low or result["EVM"]>Evm_top:
                                Evm_msg=Evm_msg+"   Fail"
                                retry_flag += 1
                            result["FreqErr"] =(result["FreqErr"]/rfFreqHz)*1000000
                            Freq_msg= msg_log + "Freq Err = %.2f (%.2f~%.2f) ppm"%(result["FreqErr"],(FREQ_AVG+FREQ_ERROR_LIMIT),(FREQ_AVG-FREQ_ERROR_LIMIT))
                            if abs(result["FreqErr"]-FREQ_AVG)>FREQ_ERROR_LIMIT:
                                Freq_msg=Freq_msg+"   Fail"
                                retry_flag += 1
                                     
                            Power_msg= msg_log + "Power = %.3f (%.2f~%.2f) dBm"%(result["Power"],Verify_Power+TargetPower_Offset[1],Verify_Power+TargetPower_Offset[0])
                            #if abs(result["Power"]-Verify_Power)>TargetPower_Offset:
                            if ((result["Power"]-Verify_Power) < TargetPower_Offset[0]) or ((result["Power"]-Verify_Power) > TargetPower_Offset[1]):
                                #if int(packet_dic[msg[2]][1]) == 2:
                                if result["Power"] < (Verify_Power - TargetPower_Offset): pwrfail+=1
                                Power_msg=Power_msg+"   Fail"
                                retry_flag += 1
                            Mask_msg= msg_log + "Spec Mask = %.3f (%.2f~%.2f) Percent"%(result["Mask"],Mask_top,Mask_low)
                            if result["Mask"]<Mask_low or result["Mask"]>Mask_top:
                                Mask_msg=Mask_msg+"   Fail"
                                retry_flag += 1
                            #print Spec Flat and LO Leakage
                            if mod==1:
                                Flat_msg= msg_log + "Spec Flat = %.3f (%.2f~%.2f) pt"%(result["Flatness"],Flat_top,Flat_low)
                                if result["Flatness"]<Flat_low or result["Flatness"]>Flat_top:
                                    Flat_msg=Flat_msg+"   Fail"
                                    retry_flag += 1
                                    
                                LO_msg= msg_log + "LO Leakage = %.3f (%.2f~%.2f) dB"%(result["LoLeakage"],LO_Leakage_top,LO_Leakage_low)
                                if result["LoLeakage"]<LO_Leakage_low or result["LoLeakage"]>LO_Leakage_top:
                                    LO_msg=LO_msg+"   Fail"
                                    retry_flag += 1
                                    
                            if retry_flag==0 or retry_num==TX_RETRY_TIMES :
                                for msg in [Freq_msg,Evm_msg,Power_msg,Mask_msg]:
                                    if "Fail" in msg:
                                        testfail=testfail+1
                                        parent.SendMessage(dut_id,msg + "\n",log,color=1)
                                    else:
                                        parent.SendMessage(dut_id,msg + "\n",log,color=2)
                  
                                if mod==1:
                                    for msg in [Flat_msg,LO_msg]:
                                        if "FAIL" in msg:
                                            testfail=testfail+1
                                            parent.SendMessage(dut_id,msg + "\n",log,color=1)
                                        else:
                                            parent.SendMessage(dut_id,msg + "\n",log,color=2)
        #if (dut_id == 1 and mode == 2): raw_input("pause")  
        #lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTOP"%interface,promp,5)
    if testfail > 0 or result == 0: raise Except ("%s Tx verify FAIL"%chip_type) 
    parent.SendMessage(dut_id, "%s Tx verify Test time: %3.2f (sec)\n"%(chip_type,(time.time()- test_time)) ,log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------\n",log)     
    
def RxVerify(parent,ni,dut_id,term,chip_type,interface,cal_freq,AntChOffsetTab,log):
    test_time = time.time()
    parent.SendMessage(dut_id,"%s Rx Verify Start...\n"%chip_type,log)   
    port=dut_id+1  #When set to 2 even though the cable is connected to the 2,it won't get the packets.
            #Pehaps it is the bug of the API.
    testfail = 0
    
    if 0: #if chip_type == 'MT7612':
        lWaitCmdTerm(term,"ifconfig %s down"%interface,"forwarding state",5)
        term.get()
        #lWaitCmdTerm(term,"ifconfig %s up"%interface,"forwarding state",20)
        lWaitCmdTerm(term,"ifconfig %s up"%interface,"entering learning state",20)
        lWaitCmdTerm(term,"","#",5)
        SetWifiDefault(term,interface)
  
    freqOffset = GetOffset(term,chip_type,interface)
    for i in range(len(print_flow[cal_freq])):
        msg = print_flow[cal_freq][i].split("\t") 
        if "TX" in msg[0]: continue          
        retry_flag = 1
        retry_num = 0        
        channel = int(msg[1])
        lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,7)
        lWaitCmdTerm(term,"iwpriv %s set ATERXANT=%d"%(interface,int(msg[3].strip()[-1])+1),promp,7)        
        lWaitCmdTerm(term,"iwpriv %s set ATECHANNEL=%s"%(interface,msg[1]),promp,7)
        lWaitCmdTerm(term,"iwpriv %s set ATETXBW=%s"%(interface,packet_dic[msg[2]][1]),promp,7)
        lWaitCmdTerm(term,"iwpriv %s set ATETXFREQOFFSET=%d"%(interface,freqOffset),promp,10)        
        lWaitCmdTerm(term,"iwpriv %s set ResetCounter=0"%interface,promp,7)
        if chip_type <> 'MT7612':
            lWaitCmdTerm(term,"iwpriv %s set ATETXMODE=%d"%(interface,packet_dic[msg[2]][0]),promp,7)
            lWaitCmdTerm(term,"iwpriv %s set ATETXMCS=7"%(interface),promp,7)
            
        cable_loss = SearchPathLossTable(AntChOffsetTab,int(msg[3][-1]),int(msg[1])) 
        cable_compensation = cable_loss + connector_loss[int(msg[3][-1])][cal_freq]
        #ModFile = mod_path + packet_dic[msg[2]][2]
        mode = packet_dic[msg[2]][0]
        if packet_dic[msg[2]][0] == 1: rx_mode = packet_dic[msg[2]][0] + packet_dic[msg[2]][1]
        elif packet_dic[msg[2]][0] == 4:
            rx_mode = packet_dic[msg[2]][0] + packet_dic[msg[2]][1] - 2
        else: rx_mode = packet_dic[msg[2]][0] 
        ni_bw = packet_dic[msg[2]][2]
        ni_mode = packet_dic[msg[2]][6]
        ni_rate = packet_dic[msg[2]][7]
        channel = int(msg[1])  
        if channel > 15: 
            rfFreqHz=(5180+(channel-36)*5)*1000000
            rfFreqMHz = (5180+(channel-36)*5)     
        else: 
            rfFreqHz=(2412+(channel-1)*5)*1000000
            rfFreqMHz = (2412+(channel-1)*5) 
        
        #print ModFile 
        parent.SendMessage(dut_id,"\n",log)
        parent.SendMessage(dut_id,"%d.%s , Path Loss: %.2f + %.2f\n"%(i,print_flow[cal_freq][i],cable_loss,connector_loss[int(msg[3][-1])][cal_freq]),log)        
        parent.SendMessage(dut_id,"----------------------------------------------------------------------------------------------------\n",log)
        log_msg = "%s , ch%s , %s , %s , "%(msg[0].strip(),msg[1].strip(),msg[2].strip(),msg[3].strip())       
        while (retry_flag==1 and retry_num<PER_RETRY_TIMES):
            retry_num += 1 
            
            lWaitCmdTerm(term,"iwpriv %s set ResetCounter=0"%interface,promp,7)
            lWaitCmdTerm(term,"iwpriv %s set ATE=RXFRAME"%interface,promp,7)
            lWaitCmdTerm(term,"",promp,7)
            #ni.RFSGConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode,ni_rate,rfPower_dic[rx_mode])
            ni.RFGenerate(rfFreqMHz,cable_compensation,ni_bw,ni_mode,ni_rate,rfPower_dic[rx_mode])
            time.sleep(packet_dic[msg[2]][3]) #The important delay 
            Per_top = packet_dic[msg[2]][4] 
            for j in range(3):
                try:
                    data=lWaitCmdTerm(term,"iwpriv %s stat"%interface,promp,7)
                    #print data 
                    result=data.split("Rx success")[-1].split("Rx with CRC")[0].strip().split("=")[-1].strip()    
                    result=int(result)  
                    #Per=(1000-result)*0.001
                    Per=((1000-result)/1000.0)*100.0
                    #if Per<=0.1 and Per>=0:
                    if Per<= Per_top:
                        break     
                    time.sleep(0.1)
                except ValueError:
                    print "Try %d check %s stat"%(i,interface)
                    
              
            Per_msg= log_msg + "PER = %.3f (%.1f ~ 0.0) Percent"%(Per,Per_top)
            if Per>Per_top:
                Per_msg=Per_msg+"         Fail"
            else:
                retry_flag = 0

            if retry_flag==0 or retry_num==PER_RETRY_TIMES:
                if "Fail" in Per_msg:
                    parent.SendMessage(dut_id,Per_msg+ "\n",log,color=1)
                    testfail+=1
                    print mod_path
                    #raw_input("pause")
                else:
                    parent.SendMessage(dut_id,Per_msg + "\n",log,color=2)
    lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTOP"%interface,promp,5)
    parent.SendMessage(dut_id,"\n")
    if testfail > 0: raise Except ("%s Rx Verify FAIL..."%chip_type) 
    parent.SendMessage(dut_id, "%s Rx Verify Test time: %3.2f (sec)\n"%(chip_type,(time.time()- test_time)) ,log)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------\n",log)   
    return testfail

def GetMacAddress(parent):
    #val = parent.MAC.GetValue()
    val = eval('parent.MAC%d'%parent.id_).GetValue()
    try:
        #if len(val) == 12 and int(val,16):
        if (len(val) == 12 or len(val) == 10):
           return val
    except ValueError:
           pass
    raise Except("Input Label Error %s !"%val)

def GetSN(parent):
    val = parent.SN.GetValue()
    try:
        #if len(val) == 12 and int(val,16):
        if (len(val) == 12 or len(val) == 10):
           return val
    except ValueError:
           pass
    raise Except("Input Label Error %s !"%val)    


def W11(parent):
    try:
        val = parent.id_ 
        result = 0
        log = None
        th_lock = False
        mac = ""
        parent.SendMessage(val,"START",state = "START")
        start_time = end_time = 0
        ni = WTS(NI_ip,((val-1) + (wts_station-1)*4)) 
        print ni.Init()
        mac = GetMacAddress(parent)
        #sn = GetSN(parent) 
        t= str(round(time.time(),1)).split(".")
        #log = open(logPath+mac+"_%s%s.w11"%(t[0][7:],t[1]),"w")
        log = open(logPath+mac+".w11","w")
        start_time=time.time()
        parent.SendMessage(val,"RMA WIFI Calibration test program version: %s , Station: %s\n"%(version,Test_station),log)
        parent.SendMessage(val,"---------------------------------------\n",log)
        parent.SendMessage(val,"Start Time:"+time.ctime()+"\n",log)
        parent.SendMessage(val,"Scan MAC address:"+mac+"\n",log)
        #parent.SendMessage( "Scan SN:"+sn+"\n",log)
        parent.SendMessage(val, "---------------------------------------------------------------------------\n",log)

        term =htx.SerialTTY(comport[val-1],b_rate)
        for i in cal_freq: #['2G','5G']
            AntChOffsetTab = ReadCompensation("PathLoss_%s_%s_%d"%(i,ant_list[1],val),"Station.Cal")
            WaitWifiBoot(parent,val,term,interface[i],log)
            SetWifiDefault(term,interface[i])
            #th_lock = parent.IQ_lock.acquire()
            
            if i == '5G':
                #if TUNE_TX_POWER: ModifyBinFile(parent,val,term,log)
                #if FREQ_CAL: FreqCalibrate(parent,term,chip_list[i],interface[i],i,AntChOffsetTab,log)
                if TX_CAL: Cal5GTxPower(parent,ni,val,term,chip_list[i],interface[i],i,AntChOffsetTab,log)
                pass
            else:
                if FREQ_CAL: FreqCalibrate(parent,ni,val,term,chip_list[i],interface[i],i,AntChOffsetTab,log) 
                if TX_CAL: Cal2GTxPower(parent,ni,val,term,chip_list[i],interface[i],i,AntChOffsetTab,log)
                pass               
            if TX_VERIFY: 
                #TxVerify(parent,ni,val,term,chip_list[i],interface[i],i,AntChOffsetTab,log)  
                TxVerifyDVT(parent,ni,val,term,chip_list[i],interface[i],i,AntChOffsetTab,log)                                 
            if RX_VERIFY: RxVerify(parent,ni,val,term,chip_list[i],interface[i],i,AntChOffsetTab,log)
            
            
            
            
        
    except Except,msg:
        parent.SendMessage(val,"\n%s\n"%msg,log,color=1)
        result = 1
        
    except: 
        parent.SendMessage(val,"\n%s\n"% traceback.print_exc(),log,color=1)
        result = 1
        term = 0
    end_time = time.time()
    parent.SendMessage(val,'\n'+"End Time:"+time.ctime()+'\n',log)
    parent.SendMessage(val,"total time: %3.2f"%(end_time-start_time)+'\n',log)
    if result:
       parent.SendMessage(val,"Test Result:FAIL"+'\n',log,color=1)
    else:
       parent.SendMessage(val,"Test Result:PASS"+'\n',log,color=2)
    if log:log.close()
    if term: term.close()
    if mac: 
       #travel = passtravel(mac,'127.0.0.1',1800,30)
       #if travel or result:
       if result:
          parent.SendMessage(val,'\n',state = "FAIL",color=1)
       else:
          parent.SendMessage(val, "",state = "PASS")   
    else: parent.SendMessage(val,"",state = "FAIL")   
