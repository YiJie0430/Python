import os,time,traceback
#from testlibs import *
from toolslib import *
from htx import Win32Message
import wx
import random
import re


execfile("config.ini")
#execfile("IQ_DUT.ini")




##############################################

class Except:
    """    example:
        try:
            if ....:
                raise Except("Error!!")
        except Except, msg:
            print msg    """
    def __init__(self,msg):
        self.value = msg; print self.value
    def __str__(self):
        return self.value
    def __repr__(self):
        return self.value

'''
def lWaitCmdTerm(term,cmd,waitstr,sec,count=1):
    for i in range(count):
        term << "%s"%cmd
        data = term.wait("%s"%waitstr,sec)
        if waitstr in data[-1]:
            return data[-1]
        term.get()
    raise Except("failed: %s,%s"%(cmd,data[-1].strip()))
'''

    
def lWaitCmdTerm(term,cmd,waitstr,sec,count=1):
    for i in range(count):
        data=list()
        term << cmd
        data = term.wait(waitstr,sec); #raw_input(data[-1])
        if "help" in data[-1]: raise Except("wifi interface down")        
        if "ttyS" in data[-1]:
            time.sleep(2)
            term<<""
            term.get()            
            #data = term.wait("%s"%promp,sec) 
            term << "%s"%cmd
            data = term.wait("%s"%waitstr,sec)
            #print data[-1]
        data=data[-1].split(cmd)[-1].split(waitstr)[0].strip()
        return data
    raise Except("failed: %s,%s"%(cmd,data))
    
def TelnetLogin(term,username=None,password=None):
    print "Telnet Login..."
    data = term.wait('login:',5)
    term<<username
    data = term.wait('Password:',5)
    term<<password
    data = term.wait('#',5)
    
def Interpolate(yMax,yMin,xMax,xMin,xVal):
        #Description:
        #	A generic function for interpolating. Find y_val when xVal is present.
        #
        #                             (yMax - yMin)
        #    Returns y_val = yMin + (--------------- * (xVal - xMin))
        #                             (xMax - xMin)
        #
        return (float(yMin) + ((float(yMax - yMin) / float(xMax - xMin)) * float(xVal - xMin)))
            
def SearchPathLossTable(AntChOffsetTab,ant,ch): 
    #for i in AntChOffsetTab:
    for i in range(len(AntChOffsetTab)):
        if ant== AntChOffsetTab[i][0]:
            if ch == AntChOffsetTab[i][1]: return AntChOffsetTab[i][2]
            if AntChOffsetTab[i][1] > ch : 
                    max_ch = AntChOffsetTab[i][1]
                    min_ch = AntChOffsetTab[i-1][1]
                    max_val = AntChOffsetTab[i][2]
                    min_val = AntChOffsetTab[i-1][2]
                    y_val = Interpolate(max_val,min_val,max_ch,min_ch,ch)
                    return y_val 
             
                
             

def ReadCompensation(filename,path=""):
    import glob
    result = []
    if not path:
        path = "."
    if path[-1] not in ["/","\\"]: path += "/"
    fs = glob.glob(path+filename+".*")
    if not fs:
        print "Can't read %s%s.*"%(path,filename)
        #parent.SendMessage("Can't read %s%s.*"%(path,filename),log)
    else:
        fs.sort()
        #print fs
        print "Read Compensation from:",fs[-1]
        #parent.SendMessage("Read Compensation from:"%fs[-1],log)
        for i in open(fs[-1]).readlines():
            if not i.strip(): continue
            if 'Loss' in i: continue
            ant,ch,offset = i.split(',')
            result.append((int(ant),
                           int(ch),
                           float(offset)))
    return result
    
    

def IQInitial():
    print "Initialize Lib."
    iqapi.LP_INIT_LIB()
    print "Reset Tester."
    iqapi.InitTester1(ip="%s"%IQip) 



    
def WaitWifiBoot(parent,dut_id,term,interface,log):
    test_time = time.time()
    parent.SendMessage(dut_id,"Wait DUT Boot Ready..." ,log)
    retry = 0
    while retry<100:
        retry = retry + 1 
        data=lWaitCmdTerm(term,"iwpriv %s stat"%interface,promp,10)
        print data
        if  "no private ioctls" in data:
            print "waiting for boot done.%d Retry"%retry            
            time.sleep(1)
        elif "Tx success" in data:
            print "Wifi boot done."
            break
        elif "Invalid command : stat" in data:
            log.set("waiting for boot done.%d Retry"%retry)            
            time.sleep(1)
        else:
            pass
    
    if retry>=100:
        raise Except("Wifi boot FAIL.")
    lWaitCmdTerm(term,"killall repeater",promp,10)   # delete console debug message
    parent.SendMessage(dut_id,"DUT boot ready time: %3.2f (sec)"%(time.time()- test_time) ,log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)

def WaitBoot(parent,dut_id,term,log):
    test_time = time.time()
    '''
    cmd_list=['root','cp /tmp/mnt/diska1/Falcon/cl2400.tar /tmp/','cd tmp && tar -xvf  /tmp/cl2400.tar && cd /',\
              'export clr_install_dir_cl2400=/tmp/build','export clr_cfg_dir_cl2400=/nvram/cl2400',\
              'export clr_cfg_dir_cl2400_24g=/nvram/cl2400_24g','export PATH=/tmp/build/bin:/tmp/build/scripts:$PATH',\
              'cp -rf /tmp/mnt/diska1/Falcon/reset_cl2400.sh /tmp/build/scripts/reset_cl2400.sh']
    '''
    cmd_list=['root']
    parent.SendMessage(dut_id,"Wait DUT Boot Ready..." ,log)
    while 1:
        if time.time()-test_time>200: raise Except("Wifi boot FAIL.")
        term<<'';time.sleep(0.5)
        data=term.get(); print data
        term<<'';time.sleep(0.5)
        data=term.get(); print data
        if "root@intel_ce_linux" in data: break
        if "shell>" in data: term<<'boot'; continue
        if "Password:" in data: term<<''; time.sleep(5); continue
        elif "login:" in data:
           for cmd in cmd_list: term<<cmd; time.sleep(0.5)
        else: time.sleep(5)
    parent.SendMessage(dut_id,"DUT boot ready time: %3.2f (sec)"%(time.time()- test_time) ,log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)                  

def Telnet_arm(parent,dut_id,arm,log):
    test_time=time.time()
    parent.SendMessage(dut_id,"telnet to arm ", log)
    arm_term =htx.Telnet(arm)
    while 1: 
        if time.time()-test_time>20: raise Except('Telnet Arm Fail')
        arm_term << 'admin'; time.sleep(1)
        data=arm_term.get(); print data
        if 'uid' in data: 
          time.sleep(5)
          arm_term << ''
          data=arm_term.get() 
          if '>' in data: arm_term<<'reboot'; break
        elif '>' in data: arm_term<<'reboot'; break         
        
    parent.SendMessage(dut_id,"Telnet ARM to reboot time: %3.2f (sec)"%(time.time()- test_time) ,log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)

def FPing(ip,length,count,interval):
    print ip
    """    Ping(ip,length,count,interval), return the loss rate (float)
        where ip is target ip address, length is IP packet length
              count is packet number, interval is ms unit"""
    result = os.popen("Fping %s -s %d -t %d -n %d"%(ip,length,interval,count)).read()
    return float(result[result.rfind("(")+1:result.rfind("%")])

def IsConnect(ip,timeout):
    ip = ip.strip()
    current = time.time()
    timeout += current
    os.popen("arp -d").read()
    while current < timeout:
        rate = FPing(ip,64,5,1)
        if rate == 0: return 1 
        time.sleep(1)                             
        current = time.time()
    return 0

def Bridge_up(parent,dut_id,target,log):
    parent.SendMessage(dut_id,"Waitting for bridge(%s)..."%target,log)
    test_time=time.time()    
    if not IsConnect(target,300):  raise Except("FAIL: DUT Boot Fail") 
    parent.SendMessage(dut_id,"ping %s sucess time: %3.2f (sec)"%(target,(time.time()- test_time)) ,log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)

def WaitBoot(parent,dut_id,mac,term,log):
    test_time = time.time()
    cmd_list=['root','export PATH=$PATH:/cl2400/bin']
    #raise Except( "Wifi boot FAIL." )
    while 1:
        if time.time()-test_time>60: raise Except("Wifi boot FAIL.")
        term<<'';time.sleep(0.5)
        data=term.get(); #print data
        term<<'';time.sleep(0.5)
        data=term.get(); #print data
        if "root@intel_ce_linux" in data: break
        if "shell>" in data: term<<'boot'; continue
        if "Password:" in data: term<<''; time.sleep(5); continue
        elif "login:" in data:
           for cmd in cmd_list: term<<cmd; time.sleep(0.5)
        else: time.sleep(5)    
    
    parent.SendMessage(dut_id,"Celeno WIFI Calibration Version: %s , Station: %s"%(version,Test_station),log,uart=term)
    parent.SendMessage(dut_id,"---------------------------------------",log,uart=term)
    parent.SendMessage(dut_id,"Start Time:"+time.ctime()+"",log,uart=term)
    parent.SendMessage(dut_id,"Scan MAC address:"+mac+"",log,uart=term)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log,uart=term)
    
    parent.SendMessage(dut_id,"Wait ATOM Boot Ready...",log,uart=term)
    #data=lWaitCmdTerm(term,"ifconfig",promp,5)
    parent.SendMessage(dut_id,lWaitCmdTerm(term,"ifconfig",promp,5)+'',log,uart=term)
    parent.SendMessage(dut_id,"ATOM boot ready time: %3.2f (sec)"%(time.time()- test_time),log,uart=term)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log,uart=term)
    data=lWaitCmdTerm(term,"ifconfig",promp,5); #print data
    if 'wlan0_0' in data or 'wlan1_0' in data: return 1
    else: return 0

def Reset_file(parent,dut_id,term,i,log):
    test_time=time.time()
    if i is '5G': folder='/nvram/cl2400/'
    elif i is '2G': folder='/nvram/cl2400_24g/'
    parent.SendMessage(dut_id,"[%s]Delete IQ/DC Cal. file "%i,log,uart=term)
    while 1:
      if time.time()-test_time>20: raise Except("Delete File FAIL.")
      #lWaitCmdTerm(term,"find %s -name *.ini -type f -delete && find %s -name *.txt -type f -delete"%(folder,folder),promp,5)
      #data= lWaitCmdTerm(term,"find %s -name *.ini -o -name *.txt -type f"%folder,promp,5)
      #if 'dc' in data or 'iq' in data or 'temp' in data: continue
      lWaitCmdTerm(term,"rm %s/* -rf"%(folder),promp,5)
      data= (lWaitCmdTerm(term,"ls -l %s | wc -l"%folder,promp,5)).split('\n'); 
      if int(data[-1]): continue
      else: 
         data=lWaitCmdTerm(term,"ls %s -al"%folder,promp,5)
         parent.SendMessage(dut_id,"%s"%data,log,uart=term)
         break
    parent.SendMessage(dut_id,"Delete file time: %3.2f (sec)"%(time.time()- test_time),log,uart=term)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log,uart=term)
    
def InitWifiProduction(parent,dut_id,chip,term,log):
    testflag=0
    test_time = time.time()
    parent.SendMessage(dut_id,"Init %s..."%chip[0],log,uart=term)
    cmd_dict={'cl2432':'ce_host.sh production 24g',\
              'cl2430':'ce_host.sh production'}    
    term.get()
    data=lWaitCmdTerm(term,'%s'%cmd_dict[chip[0]],'root@intel_ce_linux:/#',80)
    if 'NOT detected' in data: lWaitCmdTerm(term,'%s'%cmd_dict[chip[0]],'does not exists',80)
    for re_try in xrange(3):
        term.get()
        data=lWaitCmdTerm(term,'ifconfig',promp,5); print data
        #term.get()
        #term<<'ifconfig'
        time.sleep(0.1)
        #data=term.get() 
        if chip[1] not in data: testflag=1; continue
        else: testflag=0; break                 
        parent.SendMessage(dut_id,'%s'%data,log,uart=term)
    if testflag: raise Except("Wifi Enter Production FAIL.")
    parent.SendMessage(dut_id,"Wifi Init time: %3.2f (sec)"%(time.time()- test_time),log,uart=term)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log,uart=term)

def InitWifiProduction_(parent,dut_id,term,log):
    testflag=0
    test_time = time.time()
    parent.SendMessage(dut_id,"Enter wifi production mode...",log)
    data=lWaitCmdTerm(term,'ht_cl_prod.sh','[/nvram/cl2400_24g/fcu]',200); print data        
    for try_ in xrange(3):
        data=lWaitCmdTerm(term,'ifconfig',promp,5)                 
        if 'wlan0_0' not in data or 'wlan1_0' not in data: testflag=1; continue
        else: testflag=0; break                 
        parent.SendMessage(dut_id,'%s'%data ,log)
    if testflag: raise Except("Wifi Enter Production FAIL.")
    parent.SendMessage(dut_id,"Wifi Init time: %3.2f (sec)"%(time.time()- test_time) ,log)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log)
    
def ModifyBinFile(parent,term,log):
    test_time = time.time()
    parent.SendMessage("Fine tune e2p for Tx target power..." ,log)
    for i in ep2_bin.keys(): 
        if ep2_bin[i][:2]=='00': val_str = ep2_bin[i][2:]
        else: val_str = ep2_bin[i]
        lWaitCmdTerm(term,"iwpriv rai0 e2p %s=%s"%(i,ep2_bin[i]),":%s"%val_str,5)
    #lWaitCmdTerm(term,"ifconfig rai0 down"%interface,"forwarding state",5)
    #term.get()
    #lWaitCmdTerm(term,"ifconfig %s up"%interface,"forwarding state",20)
    #lWaitCmdTerm(term,"ifconfig rai0 up"%interface,"entering learning state",20)
    lWaitCmdTerm(term,"","#",5)
    parent.SendMessage( "Fine tune Tx power ready time: %3.2f (sec)"%(time.time()- test_time) ,log)
    parent.SendMessage( "---------------------------------------------------------------------------",log)

def SetWifiDefault(term,interface):
    print "Set default values for DUT..."
    lWaitCmdTerm(term,"iwpriv %s set ATE=ATESTART"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATEDA=FF:FF:FF:FF:FF:FF"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATESA=00:0C:43:41:40:9A"%interface,promp,5) #
    lWaitCmdTerm(term,"iwpriv %s set ATEBSSID=00:11:22:33:44:55"%interface,promp,5)#Different in 3052 and 2880
    lWaitCmdTerm(term,"iwpriv %s set ATETXGI=0"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATETXLEN=1024"%interface,promp,5)
    lWaitCmdTerm(term,"iwpriv %s set ATETXCNT=2000000"%interface,promp,5)
    
def GetMacAddress_lab(parent):
    #val = parent.MAC.GetValue()
    val = eval('parent.MAC%d'%parent.id_).GetValue()
    try:
        #if len(val) == 12 and int(val,16):
        #if (len(val) == 12 or len(val) == 10 or len(val) == 3):
        return val
        
    except ValueError:
           pass
    raise Except("Input Label Error %s !"%val)


def GetSN(parent):
    val = parent.SN.GetValue()
    try:
        #if len(val) == 12 and int(val,16):
        #if (len(val) == 12 or len(val) == 10):
           return val
    except ValueError:
           pass
    raise Except("Input Label Error %s !"%val)

def find(pattern, string):
    match = re.search(pattern,string)
    if match: return match.group()
    else: 
    	#print "\------------------------%s%s<------------------------"%(pattern, string)
    	raise Except("re string not find")   
    
def GetOffset(term,chip_type,interface):
    index = [None,None]
    
    for j in range(len(chip_prameter_dic[chip_type][1])):
        lWaitCmdTerm(term,"",promp,5)
        data=lWaitCmdTerm(term,"iwpriv %s e2p %s"%(interface,chip_prameter_dic[chip_type][1][j]),"]:0x",5)
        #print data
        pat = r"]:0x\w+"
        val = int(find(pat,data)[6:],16)
        if chip_prameter_dic[chip_type][1][j] == 'F4':
            if (val & 0x80) == 0x80:    ## check bit7 valid
                val = val & 0x7f      # get bit 0 ~ 6
            else: raise Except(" F4 bit 7 invalid")
        else:
            if (val & 0x40) == 0x40: c = -1  # check inceaseor decrese
            else: c = 1
            val = (val & 0x3f) * c      # get bit 0 ~ 5 ,             
        index[j]= val
    return  index[0]+index[1]  

