import htx,time
from ctypes import *
from htx import Win32Message
execfile('config.ini')
execfile('IQ_DUT.ini')


IQmeas = cdll.LoadLibrary("IQmeasure.dll")
#samplingRate = 160e6  #For IQxls
samplingRate = 80e6   #For IQflex

def ShowErrorMsg(title,result):
    Ret=IQmeas.LP_GetErrorString
    Ret.restype=c_char_p
    char_point=c_char_p(" "*20)
    char_point=IQmeas.LP_GetErrorString(c_int(result))
    boxtitle = "Error %s"%title
    bodymsg = "ERROR:%s!!"%char_point
    Win32Message(boxtitle,bodymsg)
    
def IniIQ(IQip):
    '''
    print "Try to connect IQ tester at %s"%IQip
    if not htx.IsConnect(IQip,connect_timeout):
        raise Except("%s never connect"%IQip)
    print "Initialize Lib."
    IQmeas.LP_Init()
    print "Reset Tester."
    IQmeas.InitTester1(ip="%s"%IQip)
    print "IQ instrument initial OK...."
    '''
    print "IQ flex initial.........."
    result = IQmeas.LP_Init()      #1: IQ-Xel
    if result<>0: ShowErrorMsg("LP_Init",result)
    result = IQmeas.LP_DualHead_ConOpen(1,                  #tokenID    1=left,2=right
                                         c_char_p("%s"%IQip),       #testerIP,		//*ipAddress1
                                         c_void_p(0).value,  #null, #ctypes.c_void_p(0).value == None  			//*ipAddress2
                                         c_void_p(0).value,  #null,			//*ipAddress3
                                         c_void_p(0).value)  #null			//*ipAddress4
    if result<>0: ShowErrorMsg("LP_DualHead_ConOpen",result)
    result = IQmeas.LP_DualHead_ObtainControl(c_uint(500),					#probeTimeMS
    						                              c_uint(10000))	      #timeOutMS
    
    if result<>0: ShowErrorMsg("LP_DualHead_ObtainControl",result)
    result = IQmeas.LP_SetDefault()
    if result<>0: ShowErrorMsg("LP_SetDefault",result)
    print "IQ flex initial..........Done"

def Vsg2Vsa(IQip,channel):
    if channel > 15: 
        rfFreqHz=(5180+(channel-36)*5)*1000000
    elif channel==14:
        rfFreqHz=2484*1000000     
    else: 
        rfFreqHz=(2412+(channel-1)*5)*1000000
    IQmeas.LP_EnableVsgRF(c_int(1))
    result = IQmeas.LP_SetVsg(c_double(rfFreqHz),
			                        c_double(-10),
			                        c_int(3))         #port PORT_RIGHT
    if result<>0: ShowErrorMsg("LP_SetVsg",result)
    #result = IQmeas.LP_SetVsgModulation(c_char_p("C:/IQ_file/Xel_Mod/WiFi_OFDM-54.iqvsg"))
    result = IQmeas.LP_SetVsgModulation(c_char_p(mod_path + "/54_sen.mod"),c_int(0))
    #result = IQmeas.LP_SetVsgModulation(c_char_p("WiFi_OFDM-54.iqvsg"))
    if result<>0: ShowErrorMsg("LP_SetVsgModulation",result)
    if result<>0: ShowErrorMsg("IQmeasLP_EnableVsgRF",result)
    result = IQmeas.LP_SetVsa(c_double(rfFreqHz),   #rfFreqHz 
						                  c_double(-10 + 10.0 - amp_level),     #double rfAmplDb = target pwr + PeakToAvg - cable loss
						                  c_int(2),   #port PORT_LEFT
						                  c_double(-10),           #externAtten
						                  c_double(-25),		#double triggerLevelDb
						                  c_double(5e-6),		#triggerPreTime
						                  c_double(0.0))
    if result<>0: ShowErrorMsg("LP_SetVsa",result)
    time.sleep(0.5)
    result = IQmeas.LP_VsaDataCapture(c_double(500e-6), #samplingTimeSecs
	                                    c_int(6),	       #1: IQV_TRIG_TYPE_FREE_RUN
														                           #IQV_TRIG_TYPE_IF2_NO_CAL
							                        c_double(samplingRate), #double sampleFreqHz
							                        c_int(0),         # int ht40Mode
                                      c_int(0))	       
    if result<>0: ShowErrorMsg("LP_VsaDataCapture",result)
    #result = IQmeas.LP_SaveVsaSignalFile(c_char_p("OFDM_save.iqvsa"),c_int(0))
    #if result<>0: ShowErrorMsg("LP_SaveVsaSignalFile",result)
    result = IQmeas.LP_Analyze80211ag(c_int(2),		#int ph_corr_mode
                            										  #IQV_PH_CORR_OFF        = 1,               
                            										  #IQV_PH_CORR_SYM_BY_SYM = 2,              
                            										  #IQV_PH_CORR_MOVING_AVG = 3           
                      								c_int(1),		#int ch_estimate 
                      										        #IQV_CH_EST_RAW		=1            
                      										        #IQV_CH_EST_RAW_LONG	= IQV_CH_EST_RAW
                      										        #IQV_CH_EST_2ND_ORDER	= 2
                      										        #IQV_CH_EST_RAW_FULL	= 3 
                      								c_int(2),		#int sym_tim_corr:  
                      										        #IQV_SYM_TIM_OFF		= 1,                  
                      										        #IQV_SYM_TIM_ON		= 2        
                      								c_int(2),		#int freq_sync
                      										        #IQV_FREQ_SYNC_SHORT_TRAIN = 1,          
                      										        #IQV_FREQ_SYNC_LONG_TRAIN  = 2,  
                      										        #IQV_FREQ_SYNC_FULL_PACKET = 3      
                      								c_int(1))		#int ampl_track
                      										        #IQV_AMPL_TRACK_OFF	= 1
                      										        #IQV_AMPL_TRACK_ON	= 2
                      								#c_double(8.8e-6),
                      								#c_double(15.2e-6))
    
    if result<>0: ShowErrorMsg("LP_Analyze80211ag",result)
    Ret=IQmeas.LP_GetScalarMeasurement
    Ret.restype=c_double
    val_pwr = IQmeas.LP_GetScalarMeasurement(c_char_p("rmsPowerNoGap"),c_int(0))
    return val_pwr
    


