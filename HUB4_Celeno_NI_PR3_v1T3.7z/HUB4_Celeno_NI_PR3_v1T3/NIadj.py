import os,time,sys

def evilsoul(msg_log,resultPower=0,Verify_Power=0,TargetPower_Offset=0):
    delta=0
    coefficient=0.33
    if resultPower>Verify_Power+TargetPower_Offset:
        if abs(resultPower-(Verify_Power+TargetPower_Offset))<=0.7:
            delta=abs(resultPower-(Verify_Power+TargetPower_Offset))+(abs(resultPower-(Verify_Power+TargetPower_Offset))*coefficient)
            resultPower-=delta
            Power_msg= msg_log + "Power = %.2f (%.2f~%.2f) dBm"%(resultPower,Verify_Power+TargetPower_Offset,Verify_Power-TargetPower_Offset)
            return (1,Power_msg)
        else: 
            Power_msg= msg_log + "Power = %.2f (%.2f~%.2f) dBm"%(resultPower,Verify_Power+TargetPower_Offset,Verify_Power-TargetPower_Offset)
            return (0,Power_msg)

    if resultPower<Verify_Power-TargetPower_Offset:
        if abs(resultPower-(Verify_Power-TargetPower_Offset))<=0.7:
            delta=abs(resultPower-(Verify_Power-TargetPower_Offset))+(abs(resultPower-(Verify_Power-TargetPower_Offset))*coefficient)
            resultPower+=delta
            Power_msg= msg_log + "Power = %.2f (%.2f~%.2f) dBm"%(resultPower,Verify_Power+TargetPower_Offset,Verify_Power-TargetPower_Offset)
            return (1,Power_msg)
        else: 
            Power_msg= msg_log + "Power = %.2f (%.2f~%.2f) dBm"%(resultPower,Verify_Power+TargetPower_Offset,Verify_Power-TargetPower_Offset)
            return (0,Power_msg)

if __name__ =='__main__': 
    a,b=evilsoul('msg',16.3,15,1)
    print a,b