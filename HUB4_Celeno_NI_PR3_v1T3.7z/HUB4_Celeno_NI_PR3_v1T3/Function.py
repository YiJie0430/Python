import os,time,traceback
from testlibs import *
from toolslib import *
#from htx import Win32Message
import wx
import random
from NIWTS import *
from LibFun import *
from Retest import * 
import math
import htx
import NIadj


execfile("config.ini")
execfile("IQ_DUT.ini")
frame = 1
def GetMacAddress(parent):
    #val = parent.MAC.GetValue()
    if frame == 1: val = eval('parent.MAC1').GetValue()
    else: val = eval('parent.MAC%d'%parent.id_).GetValue()
    val=val.upper()
    try:
        #if len(val) == 12 and int(val,16):
        if (len(val) == 12 or len(val) == 10):
           return val
    except ValueError:
           pass
    raise Except("Input Label Error %s !"%val)

def Calcu_OSC_Index(start_index,stop_index): # 0 freq erro is the one we want
    target_freqError = (freq_cal_err[0]+freq_cal_err[1])/2
    k=(OSC_value[stop_index]-OSC_value[start_index])/(stop_index-start_index)
    cal_osc=int((target_freqError-OSC_value[stop_index])/k + stop_index)
    print "OSC value adjustment begin from %.2f"%cal_osc
    return cal_osc  

def Calcu_2G_Gain(parent,TX_Gain,dut_id,log): #including TX0 TX1
    test_fail = 0
    parent.SendMessage(dut_id,"Calculate 2G channels gain",log)
    parent.SendMessage(dut_id,"",log) 
    msg = "CH     "
    for i in range(2):
        msg = msg + "Gain%d    "%i
    parent.SendMessage(dut_id,msg + "",log)
    parent.SendMessage(dut_id,"-------------------------------------------------")
    parent.SendMessage(dut_id,"Befor Calculate...") 
    #IQ_CAL_TX_CHANNEL_2G
    CH_STRART = IQ_CAL_TX_CHANNEL_2G[0]
    CH_MID = IQ_CAL_TX_CHANNEL_2G[1]
    CH_END = IQ_CAL_TX_CHANNEL_2G[2]
    
    for channel in range(1,15):
        msg = "%d    "%channel
        for i in range(2):
            #log.set("%d     %d  %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel]))
            msg = msg + "%d  "%TX_Gain[i][channel] 
        parent.SendMessage(dut_id,msg + "",log)    
    parent.SendMessage(dut_id,"-------------------------------------------------")
    #for anten in range(2):
    for anten in range(2):
        for i in range(2,CH_MID):
            TX_Gain[anten][i]= (float(TX_Gain[anten][CH_MID]-TX_Gain[anten][CH_STRART])/float(CH_MID-CH_STRART))*(i-CH_STRART)+ TX_Gain[anten][CH_STRART] #Calculate the Gain of the other channels
            
            TX_Gain[anten][i]=int(round(TX_Gain[anten][i]))
            if TX_Gain[anten][i]>31 or TX_Gain[anten][i]<0:
                test_fail+=1
                parent.SendMessage(dut_id,"TX Gain Error (>31),Please Check the TX and Re-Cal.",log,1)
                return test_fail                      
        for i in range(7,CH_END):
            TX_Gain[anten][i]= (float(TX_Gain[anten][CH_END]-TX_Gain[anten][CH_MID])/float(CH_END-CH_MID))*(i-CH_MID)+ TX_Gain[anten][CH_MID] #Calculate the Gain of the other channels
            TX_Gain[anten][i]=int(round(TX_Gain[anten][i]))
            if TX_Gain[anten][i]>31 or TX_Gain[anten][i]<0:
                test_fail+=1
                parent.SendMessage(dut_id,"TX Gain Error (>31),Please Check the TX and Re-Cal.",log,1)
                return test_fail                 
        for i in range(14,15):
            TX_Gain[anten][i]=TX_Gain[anten][CH_END]
            if TX_Gain[anten][i]>31 or TX_Gain[anten][i]<0:
                test_fail+=1
                parent.SendMessage(dut_id,"TX Gain Error (>31),Please Check the TX and Re-Cal.",log,1)
                return test_fail 

    parent.SendMessage(dut_id,"Afrer Calculate",log)   
    for channel in range(1,15):
        #log.set("%d     %d  %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel]))
        msg = "%d    "%channel
        for i in range(2):
            msg = msg + "%d  "%TX_Gain[i][channel] 
        parent.SendMessage(dut_id,msg + "",log)
    return TX_Gain   

def Calcu_5G_2T2R_Gain(CH_STRART,CH_END): #including TX0 TX1
    print "Calculate 5G channels' gain"
    print ""
    print "CH     Gain0    Gain1"
    print "-----------------------"
   
    for anten in range(2):
        for i in range(CH_STRART+1,CH_END):
            TX_Gain[anten][i]= (float(TX_Gain[anten][CH_END]-TX_Gain[anten][CH_STRART])/float(CH_END-CH_STRART))*(i-CH_STRART)+ TX_Gain[anten][CH_STRART] #Calculate the Gain of the other channels
            
            TX_Gain[anten][i]=int(round(TX_Gain[anten][i]))
            if TX_Gain[anten][i]>48 or TX_Gain[anten][i]<0:
                raise Except("TX Gain Error (>48),Please Check the TX and Re-Cal.") #For HOT_DEBUG
                     
        
    print "Afrer Calculate" 
    if  CH_END == 161:
        for i in range(CH_END+1,CH_END+5):
            TX_Gain[0][i] = TX_Gain[0][CH_END]  #E2p last channel = 165
            TX_Gain[1][i] = TX_Gain[1][CH_END]  #E2p last channel = 165
             
        for channel in range(CH_STRART,CH_END+5):
            print "%d    %d  %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel])
    else:
        for channel in range(CH_STRART,CH_END+1):
            print "%d    %d  %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel])

def Calcu_5G_3T3R_Gain(term,CH_STRART,CH_END): #including TX0 TX1
    print "Calculate 5G channels' gain"
    print ""
    print "CH     Gain0    Gain1    Gain2"
    print "------------------------------"

    for anten in range(3):
        for i in range(CH_STRART+1,CH_END):
            TX_Gain[anten][i]= (float(TX_Gain[anten][CH_END]-TX_Gain[anten][CH_STRART])/float(CH_END-CH_STRART))*(i-CH_STRART)+ TX_Gain[anten][CH_STRART] #Calculate the Gain of the other channels

            TX_Gain[anten][i]=int(round(TX_Gain[anten][i]))
            if TX_Gain[anten][i]>48 or TX_Gain[anten][i]<0:
                raise Except("TX Gain Error (>31),Please Check the TX and Re-Cal.") #For HOT_DEBUG


    print "Afrer Calculate"
    if  CH_END == 161:
        for i in range(CH_END+1,CH_END+5):
            TX_Gain[0][i] = TX_Gain[0][CH_END]  #E2p last channel = 165
            TX_Gain[1][i] = TX_Gain[1][CH_END]  #E2p last channel = 165
            TX_Gain[2][i] = TX_Gain[2][CH_END]  #E2p last channel = 165
        for channel in range(CH_STRART,CH_END+5):
            print "%d    %d  %d  %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel],TX_Gain[2][channel])
    else:
        for channel in range(CH_STRART,CH_END+1):
            print "%d    %d  %d  %d"%(channel,TX_Gain[0][channel],TX_Gain[1][channel],TX_Gain[2][channel])
    
   
                
def Write_E2p_2G__TXPower(term,log):
    #print "Write EEPROM."
    for i in range(2,15,2):
        value0=hex(TX_Gain[0][i]<<8 | TX_Gain[0][i-1])
        value0=value0.split("0x")[-1].strip()
        value1=hex(TX_Gain[1][i]<<8 | TX_Gain[1][i-1])
        value1=value1.split("0x")[-1].strip()
        
        addr0=hex(0x50 + i) #for TX0
        addr0=addr0.split("0x")[-1].strip()
        addr1=hex(0x5E + i) #for TX1
        addr1=addr1.split("0x")[-1].strip()
        
        lWaitCmdTerm(term,"iwpriv ra0 e2p %s=%s"%(addr0,value0),promp,5) 
        lWaitCmdTerm(term,"iwpriv ra0 e2p %s=%s"%(addr1,value1),promp,5) 
    log.set("Write 2G Tx Power to EEPROM....Done")

def Write_E2p_2GTXPower(parent,TX_Gain,dut_id,term,chip_type,log):
    #print "Write EEPROM." 
    cnt = 1
    for i in range(len(chip_prameter_dic[chip_type][2][0])):
        for j in range(2):
            val = hex(TX_Gain[j][cnt+1]<<8 | TX_Gain[j][cnt])
            val = val.split("0x")[-1].strip()
            addr = chip_prameter_dic[chip_type][2][j][i]
            print lWaitCmdTerm(term,"iwpriv ra0 e2p %s=%s"%(addr,val),promp,5)
        cnt+=2
            
    parent.SendMessage(dut_id,"Write 2G Tx Power to EEPROM....Done",log)

def Write_2T2R_E2p_5GTXPower(term,interface):
    print "Write 5G Tx Power to EEPROM..."
    ch = [[36,38],[40,44],[46,48],[52,54],
          [56,60],[62,64],[100,102],[104,108],
          [110,112],[116,118],[120,124],[126,128],
          [132,134],[136,140],[149,151],[153,157],
          [159,161],[165,166]]
    for i in range(len(ch)):
        if ch[i][0] <> 165:
            value0=hex(TX_Gain[0][ch[i][1]]<<8 | TX_Gain[0][ch[i][0]])
            value1=hex(TX_Gain[1][ch[i][1]]<<8 | TX_Gain[1][ch[i][0]])
        else:
            value0=hex(TX_Gain[0][ch[i][0]])
            value1=hex(TX_Gain[1][ch[i][0]])
            
        value0=value0.split("0x")[-1].strip()
        value1=value1.split("0x")[-1].strip()        
        addr0=hex(0x78 + i*2) #for TX0
        addr0=addr0.split("0x")[-1].strip()
        addr1=hex(0xA6 + i*2) #for TX1
        addr1=addr1.split("0x")[-1].strip()
        
        print lWaitCmdTerm(term,"iwpriv rai0 e2p %s=%s"%(addr0,value0),promp,5) 
        print lWaitCmdTerm(term,"iwpriv rai0 e2p %s=%s"%(addr1,value1),promp,5) 

def Write_3T3R_E2p_5GTXPower(term,interface):
    #interface = int_dic[freq]
    print "Write 5G Tx Power to EEPROM..."
    ch = [[36,38],[40,44],[46,48],[52,54],
          [56,60],[62,64],[100,102],[104,108],
          [110,112],[116,118],[120,124],[126,128],
          [132,134],[136,140],[149,151],[153,157],
          [159,161],[165,166]]
    for i in range(len(ch)):
        if ch[i][0] <> 165:
            value0=hex(TX_Gain[0][ch[i][1]]<<8 | TX_Gain[0][ch[i][0]])
            value1=hex(TX_Gain[1][ch[i][1]]<<8 | TX_Gain[1][ch[i][0]])
            value2=hex(TX_Gain[2][ch[i][1]]<<8 | TX_Gain[2][ch[i][0]])
        else:
            value0=hex(TX_Gain[0][ch[i][0]])
            value1=hex(TX_Gain[1][ch[i][0]])
            value2=hex(TX_Gain[2][ch[i][0]])

        value0=value0.split("0x")[-1].strip()
        value1=value1.split("0x")[-1].strip()
        value2=value2.split("0x")[-1].strip()



        addr0=hex(0x96 + i*2) #for TX0
        addr0=addr0.split("0x")[-1].strip()
        addr1=hex(0xCA + i*2) #for TX1
        addr1=addr1.split("0x")[-1].strip()
        addr2=hex(0xFE + i*2) #for TX2
        addr2=addr2.split("0x")[-1].strip()

        print lWaitCmdTerm(term,"iwpriv %s e2p %s=%s"%(interface,addr0,value0),promp,5)
        print lWaitCmdTerm(term,"iwpriv %s e2p %s=%s"%(interface,addr1,value1),promp,5)
        print lWaitCmdTerm(term,"iwpriv %s e2p %s=%s"%(interface,addr2,value2),promp,5)


def LoadFromBinFile(term,chip_type,cal_freq,interface): #For 2.4G Only
    if chip_type == "RT3593" and cal_freq == "2.4G":  
        print lWaitCmdTerm(term,"iwpriv %s set bufferLoadFromBin=1"%interface,promp,5)
    else: pass
        
def CheckTCParameter(term,chip_type,cal_freq,interface,log):
    chk_flag = 0
    if chip_type == 'RT3593':
        freq_val = {"2.4G":0,"5G":1}
        data = lWaitCmdTerm(term,"iwpriv %s e2p 36"%interface,promp,5)
        data = data.split(']:0x')[1].split()[0]
        tc_flag = chip_prameter_dic[chip_type][5][0] 
        if data <> chip_prameter_dic[chip_type][5][1][tc_flag][3:].upper():
            chk_flag +=1  
        log.set("%s e2p 36=%s (%s)"%(interface,data,chip_prameter_dic[chip_type][5][1][tc_flag][3:].upper()))
        for i in chip_prameter_dic[chip_type][6][freq_val[cal_freq]].keys():
            data = lWaitCmdTerm(term,"iwpriv %s e2p %s"%(interface,i),promp,5)
            data = data.split(']:0x')[1].split()[0]
            if data <> chip_prameter_dic[chip_type][6][freq_val[cal_freq]][i].upper():
                chk_flag +=1 
            log.set("%s e2p %s=%s (%s)"%(interface,i,data,chip_prameter_dic[chip_type][6][freq_val[cal_freq]][i].upper()))
        if chk_flag > 0: print 'Check TC parameter Fail'
        else: log.set('Check TC parameter Pass')
        return chk_flag
    else: pass
     
def JC_CSVRecord(strTitle, strRecord, rType):
  if (not CSV_EXPORT): return
    
  strTitle += "DateTime"
  strRecord += time.ctime() + ""
  
  if (rType == "CALPOWER"):
    if (not os.path.exists(logPath+"CalibrationTx.csv")):
      file = open(logPath+"CalibrationTx.csv", "a")
      file.write(strTitle)
      file.write(strRecord)
    else:
      file = open(logPath+"CalibrationTx.csv", "a")
      file.write(strRecord)
  
    file.flush()  
    file.close()
    
  elif (rType == "POWERVERIFY"):
    if (not os.path.exists(logPath+"VerificationTx.csv")):
      file = open(logPath+"VerificationTx.csv", "a")
      file.write(strTitle)
      file.write(strRecord)
    else:
      file = open(logPath+"VerificationTx.csv", "a")
      file.write(strRecord)
  
    file.flush()  
    file.close()

def Get2GPower(parent,dut_id,term,chip_type,interface,log):
    parent.SendMessage(dut_id,"Read Tx e2p gain value.......",log)
    TX_Gain={} #store the Gain of each channel of both TX
    TX_Gain[0]=[1]*166
    TX_Gain[1]=[1]*166
    TX_Gain[2]=[1]*166
    pwr = [[],[],[]]
    msg = "Channel  "
    for i in range(2):
        addr = chip_prameter_dic[chip_type][2][i] 
        for j in range(len(addr)):
            for c in range(3):
                try:
                    data=lWaitCmdTerm(term,"iwpriv %s e2p %s"%(interface,addr[j]),promp,5)
                    print data
                    if "[0x00%s]"%addr[j] in data:
                        data=data.split("]:0x")[1].split("")[0].strip()
                        break
                except:
                    pass
            pwr[i].append(int(data[2:4],16)) #ch1
            pwr[i].append(int(data[0:2],16)) #ch2
           
        msg = msg +  "Gain%d     "%i
    msg = msg + ('') 
    msg = msg + "--------------------------------------------------"            
    for channel in range(1,15):
        msg = msg + "ch%d    "%channel 
        for i in range(2):
            TX_Gain[i][channel] = pwr[i][channel-1]
            msg = msg + "%d  "%TX_Gain[i][channel]
        msg = msg + ('')
    parent.SendMessage(dut_id,msg + "",log)
    return TX_Gain
    #print msg

######################################    
#argv : term,cbterm,bp,bw,freqplan,log
def FreqCalibrate(parent,ni,dut_id,term,chip_type,AntChOffsetTab,freq_offset,log):
    #chip_type=[chip,interface,[start_freq,default_channel]]
    test_time = time.time()
    parent.SendMessage(dut_id,"%s Frequency Offset Calibrate Start..."%chip_type[0],log,uart=term)
    #freqOffset = GetOffset(term,chip_type,interface)
    retry=0
    samplingTimeSecs=0.0001
    if chip_type[0] is 'cl2432': #2.4G
       rfFreqMHz=int(chip_type[2][0])+(int(chip_type[2][1])-1)*5; #print rfFreqMHz
       rfFreqHz=(int(chip_type[2][0])+(int(chip_type[2][1])-1)*5)*1000000; #print rfFreqHz     
    elif chip_type[0] is 'cl2430': #5G
       rfFreqMHz=int(chip_type[2][0])+(int(chip_type[2][1])-36)*5; #print rfFreqMHz
       rfFreqHz=(int(chip_type[2][0])+(int(chip_type[2][1])-36)*5)*1000000; #print rfFreqHz 
    extAttenDb=SearchPathLossTable(AntChOffsetTab,0,int(chip_type[2][1])); #print extAttenDb
    triggerLevelDb=-25
    rfAmplDb=4+5-extAttenDb #gain 5
   
    #ni.RFSAConfig(int(rfFreqHz/1000000), extAttenDb, "BW20", chip_type[3][3][1], 0, 10, "ON")
    ni.RFSAConfig(rfFreqMHz, extAttenDb, "BW20", chip_type[3][3][1], 0, 10, "ON")
    parent.SendMessage(dut_id,"%s OSC Value    OSC Freq(Hz)"%chip_type[0],log,uart=term)
    parent.SendMessage(dut_id,"------------------------------------------------",log,uart=term)    
    cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],\
                    'mode %s'%chip_type[3][3][0],'txlen 1280','txcnt 10000000',\
                    'channel %s'%chip_type[2][1],'ant 0',\
                    'TXFREQOFFSET 36','pow 20 20 20 0','txframe']
    for cmd in cmd_sequential:
        lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
    while 1:
        retry+=1             
        lWaitCmdTerm(term,"iw %s ATE TXFREQOFFSET %d"%(chip_type[1],freq_offset),promp,5)         
        ni.RFSAConfig(rfFreqMHz, extAttenDb, "BW20", chip_type[3][3][1], 0, 13, "ON")
        time.sleep(0.3)
        result=ni.RFSARead(); #print result
        if (not result) or (result["Power"] == -100):
           if (retry > 3): raise Except ("[%s] lo measure signal FAIL"%chip_type[0])
           parent.SendMessage(dut_id, " -Measure failed >> %s, Retry: %d"%(result,retry), log, color=0, uart=term)
           continue        
        freq_err_ppm =(result["FreqErr"]/rfFreqHz)*1000000
        #freq_err_ppm =round((result["FreqErr"]*1000000)/rfFreqMHz,1)                
        msg="frequency offset index=%d, freq error=%.2f ppm"%(freq_offset,freq_err_ppm)
        if (freq_err_ppm<freq_cal_err[0]) or (freq_err_ppm>freq_cal_err[1]):
            parent.SendMessage(dut_id," -Retry%d %s"%(retry,msg),log,uart=term) 
            freq_offset+=round(freq_err_ppm,0)               
            if retry>20:
                parent.SendMessage(dut_id,"%s Frequency offset calibrate fail"%chip_type[0],log,color=1,uart=term)
                raise Except ("%s Freq Offset Calibratet FAIL"%chip_type[0])   
        else:           
            lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd_sequential[0]),promp,5)
            lWaitCmdTerm(term,"iw %s e2p set freq_offset %d"%(chip_type[1],freq_offset),promp,5)            
            break
    while 1:
        try:
           freqOffset=lWaitCmdTerm(term,"iw %s e2p get freq_offset"%chip_type[1],promp,5)
           freqOffset=int(freqOffset.split('set')[-1].split(promp)[0]); #print freqOffset
           if freqOffset==freq_offset: break
           else: lWaitCmdTerm(term,"iw %s e2p set freq_offset %d"%(chip_type[1],freq_offset),promp,5)
        except: 
           if times==9: raise Except ("FAIL - freqoffset set error (%s)"%freqOffset)
           else: continue
    parent.SendMessage(dut_id,"[%s] frequency offset index=%d, freq error=%.2f (%.2f~%.2f) ppm"%(chip_type[0],freq_offset,freq_err_ppm,freq_cal_err[0],freq_cal_err[1]),log,color=2,uart=term)
    parent.SendMessage(dut_id,"Store %s freq. offset value = %s to EEPROM Done"%(chip_type[0],freq_offset),log,uart=term)
    parent.SendMessage(dut_id, "%s Freq Calibrate Test time: %3.2f (sec)"%(chip_type[0],(time.time()- test_time)),log,uart=term)
    parent.SendMessage(dut_id,"---------------------------------------------------------------------------",log,uart=term)

def CalTxPower(parent,ni,dut_id,term,chip_type,AntChOffsetTab,cal_freq,log):    
    test_time = time.time()
    testfail=0
    channel_list=list()
    for band in sorted(chip_type[3][0].keys()):
        channel_list+=chip_type[3][0][band][0]
    evm_criteria=int(chip_type[3][2])
    for times in xrange(10):
        try:
           freqOffset=lWaitCmdTerm(term,"iw %s e2p get freq_offset"%chip_type[1],promp,5)
           freqOffset=int(freqOffset.split('set')[-1].split(promp)[0]); print freqOffset
           break
        except: 
           if times==9: raise Except ("FAIL - freqoffset get error (%s)"%freqOffset)
           else: continue 
    #parent.SendMessage(dut_id,"[%s] Calibrate Tx Power...(Cal Power:%d(%s), Freq. Offset:%s)"%(chip_type[0],cal_pwr,CAL_METHOD[0],freqOffset),log)
    #parent.SendMessage(dut_id,"**************************************************",log)    
    pivot_channel=' '.join(channel_list); print pivot_channel
    lWaitCmdTerm(term,"iw %s ATE vector reset"%chip_type[1],promp,5)
    lWaitCmdTerm(term,"iw %s ATE vector %s"%(chip_type[1], pivot_channel),promp,5)
    cmd_sequential=['stop','stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                    'TXFREQOFFSET %s'%freqOffset] #default txlen is 1024, bw 0    
    for chain in xrange(int(chip_type[4])):
        for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
        for cal_pwr in sorted(chip_type[3][0].keys()):
            gain=[0,0,0]
            for channel in chip_type[3][0][cal_pwr][0]: 
                #parent.SendMessage(dut_id,"[%s] Calibrate Tx Power...(Cal Power:%s(%s), Freq. Offset:%s)"%(chip_type[0],cal_pwr,CAL_METHOD[0],freqOffset),log)
                #parent.SendMessage(dut_id,"**************************************************",log)
                gain_record=list(); diffPwr_record=list(); current_record=tuple()
                retry=0; no_result_cnt=0; over_pwr_cnt=0; cal_retry=0
                pathloss = SearchPathLossTable(AntChOffsetTab,int(chain),int(channel)); print pathloss
                compensation=pathloss+connector_loss[chain][cal_freq]
                if chip_type[0] is 'cl2432':
                   rfFreqMHz = int(chip_type[2][0])+(int(channel)-1)*5; print rfFreqMHz
                   #rfFreqHz=(int(chip_type[2][0])+((int(channel)-1)*5))*1000000; print rfFreqHz     
                elif chip_type[0] is 'cl2430':
                   rfFreqMHz = int(chip_type[2][0])+(int(channel)-36)*5; print rfFreqMHz
                   #rfFreqHz=(int(chip_type[2][0])+((int(channel)-36)*5))*1000000; print rfFreqHz 
            
                ni.RFSAConfig(rfFreqMHz,compensation,"BW20",chip_type[3][3][1],1,float(cal_pwr),"ON","OFF")
                
                #cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                #                'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                #                'ant %s'%chain,'txframe']
                cmd_sequential=['txcnt 10000000','channel %s'%channel,'ant %s'%chain,'txframe'] # default: channel <channel>
                for cmd in cmd_sequential: 
                    lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                #parent.SendMessage(dut_id," Tx%s: ch:%s p_loss=%.2f+%.2f "%(chain,channel,pathloss,connector_loss[chain][cal_freq]),log)
                parent.SendMessage(dut_id,"[%s] Calibrate Tx%s ch%s Power...(Cal Power:%s(%s), Freq. Offset:%s, p_loss=%.2f+%.2f)"%(chip_type[0],chain,channel,cal_pwr,CAL_METHOD[0],freqOffset,pathloss,connector_loss[chain][cal_freq]),log,uart=term)
                ALENgth=150
                while 1:                
                    #cmd_sequential=['txcnt 10000000','channel %s'%channel,'ant %s'%chain,'txframe'] # default: channel <channel>
                    #for cmd in cmd_sequential: 
                        #lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    if cal_retry>5: raise Except ("[%s] FAIL - TX%s Power Abnormal"%(chip_type[0],chain))
                    if not retry: gain[chain]=int(chip_type[3][0][cal_pwr][1]) #gain[chain]=int(chip_type[3][5])
                    '''
                    cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                    'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                                    'ant %s'%chain]
                    for cmd in cmd_sequential: 
                        lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    '''
                    lWaitCmdTerm(term,"iw %s ATE pow %d %d %d 0"%(chip_type[1],gain[0],gain[1],gain[2]),promp,5)
                    #lWaitCmdTerm(term,"iw %s ATE txframe"%(chip_type[1]),promp,5)
                    ni.RFSAConfig(rfFreqMHz,compensation,"BW20",chip_type[3][3][1],1,float(cal_pwr),"ON","OFF",ALENgth)
                    result=ni.RFSARead(); print (result)
                    if not result or int(result["Power"]) == -100:
                       no_result_cnt+=1
                       #ALENgth+=(50*no_result_cnt)                       
                       if no_result_cnt > 5: 
                          if run_flow: parent.SendMessage(dut_id, " FAIL - No signal (Chain%s)"%chain, log, color=1, uart=term); testfail=1; break
                          else: raise Except ("[%s] TX Power Measure FAIL"%chip_type[0])
                       parent.SendMessage(dut_id, "Measure(%d)> %s"%(no_result_cnt, result), log, color=0, uart=term)
                       cmd_sequential=['stop','stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                       'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                                       'ant %s'%chain,'txframe']
                       for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                       continue        
                    
                    ###sort method####
                    #evm=round(result["EVM"],1)
                    diffPwr=round(round(result["Power"],1)-float(cal_pwr),1)
                    
                    if abs(diffPwr)>7:  ###avoid hardware issue to cause nustable output power | threshold set as 7(experience)###
                       if over_pwr_cnt > 5:
                          print diffPwr
                          if run_flow: parent.SendMessage(dut_id, " FAIL - Abnormal Output Power (Chain%s) | check default gain word"%chain, log, color=1, uart=term); testfail=1; break
                          else: raise Except ("[%s] FAIL - TX%s Power Abnormal | check default gain word--(Power:%s)"%(chip_type[0],chain,result["Power"]))
                       else: 
                          over_pwr_cnt+=1
                          cmd_sequential=['stop','stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                          'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                                          'ant %s'%chain,'txframe']
                          for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                          continue
                    '''
                    else:                    
                        gain_record.append(gain[chain]); print gain_record
                        diffPwr_record.append(diffPwr); print diffPwr_record
                        if len(gain_record)>1 and len(gain_record)==len(diffPwr_record):                   
                           if gain_record[-1]>=gain_record[0]:
                              if int(diffPwr_record[-1])>=int(diffPwr_record[0]):
                                 gain_diff=((gain_record[-1]-gain_record[0]))
                                 power_diff=math.ceil(abs(float(gain_diff)/2))
                                 _diffPwr=((diffPwr_record[-1]-diffPwr_record[0]))
                                 if abs(_diffPwr-power_diff) <= 1.5: gain[chain]=gain_record[-1]
                                 else: print 'gain power abnormal'; gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue      
                              else: gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue
                           elif gain_record[-1]<=gain_record[0]:
                               if int(diffPwr_record[-1])<=int(diffPwr_record[0]):
                                  gain_diff=(gain_record[0]-gain_record[-1])
                                  power_diff=math.ceil(abs(float(gain_diff)/2))
                                  _diffPwr=(diffPwr_record[0]-diffPwr_record[-1])
                                  if abs(_diffPwr-power_diff) <= 1.5: gain[chain]=gain_record[-1]
                                  else: print 'gain power abnormal'; gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue      
                               else: gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue
                           #else:cal_retry+=1; continue      
                    '''
                    no_result_cnt=0; retry+=1
                    current_record=(gain[chain],result["Power"],diffPwr); #raw_input(current_record)
                    gain_record.append(current_record); #raw_input(gain_record)
                    #parent.SendMessage(dut_id, " -%d: current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f EVM:%s"%(retry,gain[chain], result["Power"], diffPwr, evm), log, color=0)
                    parent.SendMessage(dut_id, " -%d: current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f"%(retry,gain[chain], result["Power"], diffPwr), log, color=0, uart=term)
                    if abs(diffPwr)>CAL_METHOD[1]:
                       if abs(diffPwr)>=1.0: 
                          if diffPwr>0: pwrOffset=abs(round(diffPwr))*2; gain[chain]-=pwrOffset
                          else: pwrOffset=abs(round(diffPwr))*2; gain[chain]+=pwrOffset
                       elif 0.9<=abs(diffPwr)<=1: 
                          if diffPwr>0: gain[chain]-=1
                          else: gain[chain]+=1
                       if gain[chain]>63 or gain[chain]<=0: gain[chain]=int(chip_type[3][0][cal_pwr][1]); continue                           
                       if retry>=2:
                          cmd_sequential=['stop','stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                          'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                                          'ant %s'%chain,'txframe']
                          for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    else:  
                       if abs(diffPwr)<=0.2: break                                                            
                       if diffPwr>0: gain[chain]-=1
                       else: gain[chain]+=1                          
                       if gain[chain]>63 or gain[chain]<=0: gain[chain]=int(chip_type[3][0][cal_pwr][1]); continue
                    
                    if retry==5: 
                       len_cunt=len(gain_record)
                       while len_cunt>0:
                           len_cunt-=1
                           if abs(float(gain_record[len_cunt][2]))>CAL_METHOD[1]: gain_record.pop(len_cunt)   
                       if not len(gain_record):
                           if run_flow: 
                              #parent.SendMessage(dut_id, " FAIL - current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f, EVM:%s**************************************************"%(gain[chain], result["Power"], diffPwr,evm), log, color=1)
                              parent.SendMessage(dut_id, " FAIL - current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f**************************************************"%(current_record[0], current_record[1], current_record[2]), log, color=1, uart=term)
                              testfail=1; break
                           else: raise Except ("[%s] TX Cal FAIL > Chain%s Channel%s Gain_idx:%s PwrDiff:%.1f"%(chip_type[0],chain,channel,current_record[0],current_record[2]))                            
                                 #raise Except ("[%s] TX Cal FAIL > Chain%s Channel%s Gain_idx:%s PwrDiff:%.1f EVM:%s"%(chip_type[0],chain,channel,gain[chain],diffPwr,evm))
                       while len(gain_record)>0:
                           #raw_input(gain_record)
                           if abs(float(gain_record[-1][2]))<=abs(float(gain_record[(-2)][2])): gain_record.pop((-2)); print 'previous-1'
                              #if (0-float(gain_record[-1][2]))<=(0-float(gain_record[(-2)][2])):gain_record.pop((-2)); print 'previous-2'
                              #else: gain_record.pop((-1)); print'last-2'
                           else: gain_record.pop((-1)); print 'last-1'
                           if len(gain_record)==1: break 
                       current_record=gain_record[-1]
                       break    
    
                retry=0; case=0
                while True:
                    try:
                        if not case:
                          msg='[%s] Get Temp.'%chip_type[0]
                          #parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5),log)
                          Tempt=lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5); print Tempt
                          #Tempt=int(Tempt.split('temperature')[-1].split('root')[0].strip()); print Tempt
                          Tempt=int(Tempt.split('External + Delta = ')[-1].split('\r\n')[0].strip()); print Tempt
                          if Tempt<=0: 
                            retry+=1                                              
                            if retry==3: 
                                parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5),log,uart=term); 
                                parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5),log,uart=term); 
                                #raise Except("[%s] Temperature abnormal")
                                Tempt=abs(Tempt); case=1; retry=0
                            else: continue
                          else: case=1; retry=0
                        while case:
                          msg='[%s] Set e2p Calib'%chip_type[0]
                          parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s e2p set calib %d %s %d %s %d"%(chip_type[1],chain,channel,current_record[0],cal_pwr,Tempt),promp,5),log,uart=term)
                          gain_code_data=lWaitCmdTerm(term,"iw %s e2p get calib %d %s"%(chip_type[1],chain,channel),promp,5)
                          gain_code=int(gain_code_data.split('parsed %s'%channel)[-1].split('root')[0].strip()); print gain_code
                          if gain_code==int(current_record[0]): break
                          else: retry+=1
                          if retry==3: raise Except("[%s] Cal value dismatch"%(chip_type[0]))
                        break
                    except: 
                        if retry==3: raise Except("%s Fail"%msg)
                        else: retry+=1; continue 
                #parent.SendMessage(dut_id,"Tx:%s ch:%s PwrIdx=%s MeasurePwr=%.1f PwrDiff=%.1f EVM=%s Temperature=%s"%(chain,channel,gain[chain],result["Power"],diffPwr,evm,Tempt),log,color=2)
                parent.SendMessage(dut_id,"Tx:%s ch:%s PwrIdx=%s MeasurePwr=%.1f PwrDiff=%.1f Temperature=%s"%(chain,channel,current_record[0],current_record[1],current_record[2],Tempt),log,color=2,uart=term)
                parent.SendMessage(dut_id,"**************************************************",log,uart=term) 
                #break       

    parent.SendMessage(dut_id, "Power calibration test time: %3.2f (sec)"%(time.time()- test_time),log,uart=term)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log,uart=term)
    return testfail

def CalTxPower(parent,ni,dut_id,term,chip_type,AntChOffsetTab,cal_freq,log):    
    test_time = time.time()
    testfail=0
    channel_list=list()
    for band in sorted(chip_type[3][0].keys()):
        channel_list+=chip_type[3][0][band][0]
    evm_criteria=int(chip_type[3][2])
    for times in xrange(10):
        try:
           freqOffset=lWaitCmdTerm(term,"iw %s e2p get freq_offset"%chip_type[1],promp,5)
           freqOffset=int(freqOffset.split('set')[-1].split(promp)[0]); #print freqOffset
           break
        except: 
           if times==9: raise Except ("FAIL - freqoffset get error (%s)"%freqOffset)
           else: continue 
    #parent.SendMessage(dut_id,"[%s] Calibrate Tx Power...(Cal Power:%d(%s), Freq. Offset:%s)"%(chip_type[0],cal_pwr,CAL_METHOD[0],freqOffset),log)
    #parent.SendMessage(dut_id,"**************************************************",log)    
    pivot_channel=' '.join(channel_list); #print pivot_channel
    lWaitCmdTerm(term,"iw %s cecli temp_loop 0"%chip_type[1],promp,5)
    lWaitCmdTerm(term,"iw %s ATE vector reset"%chip_type[1],promp,5)
    lWaitCmdTerm(term,"iw %s ATE vector %s"%(chip_type[1], pivot_channel),promp,5)
    cmd_sequential=['stop','start','bw 0','gi 0','mcs 7','mode 2','txlen 1280',\
                    'txcnt 10000000',] #default txlen is 1280, bw 0    
    for cal_pwr in sorted(chip_type[3][0].keys()):
        for channel in chip_type[3][0][cal_pwr][0]:        
            for chain in xrange(int(chip_type[4])):
                gain=[0,0,0]
                for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5) 
                #parent.SendMessage(dut_id,"[%s] Calibrate Tx Power...(Cal Power:%s(%s), Freq. Offset:%s)"%(chip_type[0],cal_pwr,CAL_METHOD[0],freqOffset),log)
                #parent.SendMessage(dut_id,"**************************************************",log)
                gain_record=list(); diffPwr_record=list(); current_record=tuple()
                retry=0; no_result_cnt=0; over_pwr_cnt=0; cal_retry=0
                pathloss = SearchPathLossTable(AntChOffsetTab,int(chain),int(channel)); #print pathloss
                compensation=pathloss+connector_loss[chain][cal_freq]
                if chip_type[0] is 'cl2432':
                   rfFreqMHz = int(chip_type[2][0])+(int(channel)-1)*5; #print rfFreqMHz
                   #rfFreqHz=(int(chip_type[2][0])+((int(channel)-1)*5))*1000000; print rfFreqHz     
                elif chip_type[0] is 'cl2430':
                   rfFreqMHz = int(chip_type[2][0])+(int(channel)-36)*5; #print rfFreqMHz
                   #rfFreqHz=(int(chip_type[2][0])+((int(channel)-36)*5))*1000000; print rfFreqHz 
            
                ni.RFSAConfig(rfFreqMHz,compensation,"BW20",chip_type[3][3][1],1,float(cal_pwr),"ON","OFF")
                
                #cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                #                'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                #                'ant %s'%chain,'txframe']
                cmd_sequential=['channel %s'%channel,'ant %s'%chain,'TXFREQOFFSET %s'%freqOffset,'pow 20 0 0 0','txframe','pow 20 0 0 0'] # default: channel <channel>
                for cmd in cmd_sequential: 
                    lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                #parent.SendMessage(dut_id," Tx%s: ch:%s p_loss=%.2f+%.2f "%(chain,channel,pathloss,connector_loss[chain][cal_freq]),log)
                parent.SendMessage(dut_id,"[%s] Calibrate Tx%s ch%s Power...(Cal Power:%s(%s), Freq. Offset:%s, p_loss=%.2f+%.2f)"%(chip_type[0],chain,channel,cal_pwr,CAL_METHOD[0],freqOffset,pathloss,connector_loss[chain][cal_freq]),log,uart=term)
                ALENgth=300
                while 1:                
                    #cmd_sequential=['txcnt 10000000','channel %s'%channel,'ant %s'%chain,'txframe'] # default: channel <channel>
                    #for cmd in cmd_sequential: 
                        #lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    if cal_retry>5: raise Except ("[%s] FAIL - TX%s Power Abnormal"%(chip_type[0],chain))
                    if not retry: gain[chain]=int(chip_type[3][0][cal_pwr][1]) #gain[chain]=int(chip_type[3][5])
                    '''
                    cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                    'txcnt 10000000','channel %s'%channel,'TXFREQOFFSET %s'%freqOffset,\
                                    'ant %s'%chain]
                    for cmd in cmd_sequential: 
                        lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    '''
                    lWaitCmdTerm(term,"iw %s ATE pow %d %d %d 0"%(chip_type[1],gain[0],gain[1],gain[2]),promp,5)
                    #lWaitCmdTerm(term,"iw %s ATE txframe"%(chip_type[1]),promp,5)
                    ni.RFSAConfig(rfFreqMHz,compensation,"BW20",chip_type[3][3][1],1,float(cal_pwr),"ON","OFF",ALENgth)
                    result=ni.RFSARead(); #print result["Power"]
                    if not result or int(result["Power"]) == -100:
                       no_result_cnt+=1
                       #ALENgth+=(50*no_result_cnt)                       
                       if no_result_cnt > 30: 
                          if run_flow: parent.SendMessage(dut_id, " FAIL - No signal (Chain%s)"%chain, log, color=1, uart=term); testfail=1; break
                          else: raise Except ("[%s] TX Power Measure FAIL"%chip_type[0])
                       #parent.SendMessage(dut_id, "Measure(%d)> %s"%(no_result_cnt, result), log, color=0, uart=term)
                       print'wait%d'%no_result_cnt
                       cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                       'txcnt 10000000','channel %s'%channel,'ant %s'%chain,'TXFREQOFFSET %s'%freqOffset,'pow %d %d %d 0'%(gain[0],gain[1],gain[2]),\
                                       'txframe','pow %d %d %d 0'%(gain[0],gain[1],gain[2])]
                       for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                       continue        
                    
                    ###sort method####
                    #evm=round(result["EVM"],1)
                    diffPwr=round(round(result["Power"],1)-float(cal_pwr),1)
                    
                    if abs(diffPwr)>7:  ###avoid hardware issue to cause nustable output power | threshold set as 7(experience)###
                       if over_pwr_cnt > 5:
                          print diffPwr
                          if run_flow: parent.SendMessage(dut_id, " FAIL - Abnormal Output Power (Chain%s) | check default gain word"%chain, log, color=1, uart=term); testfail=1; break
                          else: raise Except ("[%s] FAIL - TX%s Power Abnormal | check default gain word--(Power:%s)"%(chip_type[0],chain,result["Power"]))
                       else: 
                          over_pwr_cnt+=1
                          cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                          'txcnt 10000000','channel %s'%channel,'ant %s'%chain,'TXFREQOFFSET %s'%freqOffset,'pow %d %d %d 0'%(gain[0],gain[1],gain[2]),\
                                          'txframe','pow %d %d %d 0'%(gain[0],gain[1],gain[2])]
                          for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                          continue
                    '''
                    else:                    
                        gain_record.append(gain[chain]); print gain_record
                        diffPwr_record.append(diffPwr); print diffPwr_record
                        if len(gain_record)>1 and len(gain_record)==len(diffPwr_record):                   
                           if gain_record[-1]>=gain_record[0]:
                              if int(diffPwr_record[-1])>=int(diffPwr_record[0]):
                                 gain_diff=((gain_record[-1]-gain_record[0]))
                                 power_diff=math.ceil(abs(float(gain_diff)/2))
                                 _diffPwr=((diffPwr_record[-1]-diffPwr_record[0]))
                                 if abs(_diffPwr-power_diff) <= 1.5: gain[chain]=gain_record[-1]
                                 else: print 'gain power abnormal'; gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue      
                              else: gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue
                           elif gain_record[-1]<=gain_record[0]:
                               if int(diffPwr_record[-1])<=int(diffPwr_record[0]):
                                  gain_diff=(gain_record[0]-gain_record[-1])
                                  power_diff=math.ceil(abs(float(gain_diff)/2))
                                  _diffPwr=(diffPwr_record[0]-diffPwr_record[-1])
                                  if abs(_diffPwr-power_diff) <= 1.5: gain[chain]=gain_record[-1]
                                  else: print 'gain power abnormal'; gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue      
                               else: gain_record=list(); diffPwr_record=list(); cal_retry+=1; continue
                           #else:cal_retry+=1; continue      
                    '''
                    no_result_cnt=0; retry+=1
                    current_record=(gain[chain],result["Power"],diffPwr); #raw_input(current_record)
                    gain_record.append(current_record); #raw_input(gain_record)
                    #parent.SendMessage(dut_id, " -%d: current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f EVM:%s"%(retry,gain[chain], result["Power"], diffPwr, evm), log, color=0)
                    parent.SendMessage(dut_id, " -%d: current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f"%(retry,gain[chain], result["Power"], diffPwr), log, color=0, uart=term)
                    if abs(diffPwr)>CAL_METHOD[1]:
                       if abs(diffPwr)>=1.0: 
                          if diffPwr>0: pwrOffset=abs(round(diffPwr))*2; gain[chain]-=pwrOffset
                          else: pwrOffset=abs(round(diffPwr))*2; gain[chain]+=pwrOffset
                       elif 0.9<=abs(diffPwr)<=1: 
                          if diffPwr>0: gain[chain]-=1
                          else: gain[chain]+=1
                       if gain[chain]>63 or gain[chain]<=0: gain[chain]=int(chip_type[3][0][cal_pwr][1]); continue                           
                       if retry>=2:
                          cmd_sequential=['stop','start','bw 0','gi 0','mcs %s'%chip_type[3][4],'mode %s'%chip_type[3][3][0],'txlen 1280',\
                                          'txcnt 10000000','channel %s'%channel,'ant %s'%chain,'TXFREQOFFSET %s'%freqOffset,'pow %d %d %d 0'%(gain[0],gain[1],gain[2]),\
                                          'txframe','pow %d %d %d 0'%(gain[0],gain[1],gain[2])]
                          for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
                    else:  
                       if abs(diffPwr)<=0.2: break                                                            
                       if diffPwr>0: gain[chain]-=1
                       else: gain[chain]+=1                          
                       if gain[chain]>63 or gain[chain]<=0: gain[chain]=int(chip_type[3][0][cal_pwr][1]); continue
                    
                    if retry==5: 
                       len_cunt=len(gain_record)
                       while len_cunt>0:
                           len_cunt-=1
                           if abs(float(gain_record[len_cunt][2]))>CAL_METHOD[1]: gain_record.pop(len_cunt)   
                       if not len(gain_record):
                           if run_flow: 
                              #parent.SendMessage(dut_id, " FAIL - current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f, EVM:%s**************************************************"%(gain[chain], result["Power"], diffPwr,evm), log, color=1)
                              parent.SendMessage(dut_id, " FAIL - current PwrIdx: %d, MeasurePwr: %.1f, PwrDiff: %.1f**************************************************"%(current_record[0], current_record[1], current_record[2]), log, color=1, uart=term)
                              testfail=1; break
                           else: raise Except ("[%s] TX Cal FAIL > Chain%s Channel%s Gain_idx:%s PwrDiff:%.1f"%(chip_type[0],chain,channel,current_record[0],current_record[2]))                            
                                 #raise Except ("[%s] TX Cal FAIL > Chain%s Channel%s Gain_idx:%s PwrDiff:%.1f EVM:%s"%(chip_type[0],chain,channel,gain[chain],diffPwr,evm))
                       while len(gain_record)>0:
                           #raw_input(gain_record)
                           if len(gain_record)==1: break
                           if abs(float(gain_record[-1][2]))<=abs(float(gain_record[(-2)][2])): gain_record.pop((-2)); #print 'previous-1'
                              #if (0-float(gain_record[-1][2]))<=(0-float(gain_record[(-2)][2])):gain_record.pop((-2)); print 'previous-2'
                              #else: gain_record.pop((-1)); print'last-2'
                           else: gain_record.pop((-1)); #print 'last-1'
                            
                       current_record=gain_record[-1]
                       break    
    
                retry=0; case=0
                while True:
                    try:
                        if not case:
                          msg='[%s] Get Temp.'%chip_type[0]
                          #parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5),log)
                          lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5)
                          lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5)
                          if temp_chip:
                             Tempt=lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5)
                             Tempt=int(Tempt.split('temperature')[-1].split('root')[0].strip()); #print Tempt
                          else:
                             Tempt=lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5)
                             Tempt=int(Tempt.split('External + Delta = ')[-1].split('\r\n')[0].strip()); #print Tempt

                          if Tempt<=0: 
                            retry+=1                                              
                            if retry==3:
                                lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5) 
                                parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5) ,log,uart=term); 
                                parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5),log,uart=term); 
                                #raise Except("[%s] Temperature abnormal")
                                Tempt=abs(Tempt); case=1; retry=0
                            else: continue
                          if Tempt>=Tempt_max: 
                             parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature"%chip_type[1],promp,5) ,log,uart=term); 
                             parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s cecli temperature2 2"%chip_type[1],promp,5),log,uart=term);    
                             msg='[%s] Tempt. too high (%d)>%d'%(chip_type[0],Tempt,Tempt_max)
                             raise Except(msg)
                          else: case=1; retry=0
                        while case:
                          msg='[%s] Set e2p Calib'%chip_type[0]
                          parent.SendMessage(dut_id,lWaitCmdTerm(term,"iw %s e2p set calib %d %s %d %s %d"%(chip_type[1],chain,channel,current_record[0],cal_pwr,Tempt),promp,5),log,uart=term)
                          gain_code_data=lWaitCmdTerm(term,"iw %s e2p get calib %d %s"%(chip_type[1],chain,channel),promp,5)
                          gain_code=int(gain_code_data.split('parsed %s'%channel)[-1].split('root')[0].strip()); #print gain_code
                          if gain_code==int(current_record[0]): break
                          else: retry+=1
                          if retry==3: raise Except("[%s] Cal value dismatch"%(chip_type[0]))
                        break
                    except: 
                        if retry==3: raise Except("%s Fail"%msg)
                        else: retry+=1; continue 
                #parent.SendMessage(dut_id,"Tx:%s ch:%s PwrIdx=%s MeasurePwr=%.1f PwrDiff=%.1f EVM=%s Temperature=%s"%(chain,channel,gain[chain],result["Power"],diffPwr,evm,Tempt),log,color=2)
                parent.SendMessage(dut_id,"Tx:%s ch:%s PwrIdx=%s MeasurePwr=%.1f PwrDiff=%.1f Temperature=%s"%(chain,channel,current_record[0],current_record[1],current_record[2],Tempt),log,color=2,uart=term)
                parent.SendMessage(dut_id,"**************************************************",log,uart=term) 
                #break       

    parent.SendMessage(dut_id, "Power calibration test time: %3.2f (sec)"%(time.time()- test_time),log,uart=term)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log,uart=term)
    return testfail
                    
def TxVerify(parent,ni,dut_id,term,chip_type,AntChOffsetTab,cal_freq,log): 
    #parent.SendMessage(dut_id,"%s Tx verify Start...| Target Power: %s"%(chip_type[0],chip_type[3][0]) ,log)
    parent.SendMessage(dut_id,"%s Tx verify Start..."%(chip_type[0]),log,uart=term)
    test_time = time.time()
    testfail=0
    #cal_pwr=int(chip_type[3][0])
    for times in xrange(10):
        try:
           freqOffset=lWaitCmdTerm(term,"iw %s e2p get freq_offset"%chip_type[1],promp,5)
           freqOffset=int(freqOffset.split('set')[-1].split('root')[0].strip()); #print freqOffset
           break
        except: 
           if times==9: raise Except ("FAIL - freqoffset get error (%s)"%freqOffset)
           else: continue 
    ver_item=str()
    ver_flow=list()
    print_flow=dict()
    if cal_freq is '2G':
        flag=cl2432_ver_parameter['flag']
        if flag: ver_paramter=cl2432_ver_parameter['TX']
        else: print_flow=manual_flow
    else: 
        flag=cl2430_ver_parameter['flag']
        if flag: ver_paramter=cl2430_ver_parameter['TX']
        else: print_flow=manual_flow
    if flag:
        for channel in ver_paramter[0]:
            for mode in ver_paramter[1]:
                if mode is 'HT40_MCS7' and channel in [10,11,12,13]: continue
                else:
                    for ant in ver_paramter[2]:
                        ver_item="IQ_VERIFY_TX\t%d\t%s\tTX%d"%(channel,mode,ant); #print ver_item
                        ver_flow.append(ver_item)
        print_flow={cal_freq:ver_flow}
    #print print_flow   
    for i in range(len(print_flow[cal_freq])): 
        retry_flag=1
        retryCnt = 0
        msg = print_flow[cal_freq][i].split("\t")
        if "RX" in msg[0]: continue
        if cal_freq=='5G' and msg[2]=='HT20_MCS7': Tx_Power_Offset={'2G':1.5,'5G':1.5}
        else:Tx_Power_Offset= {'2G':1.5,'5G':2}
        # Defind Tx paramter              
        bwide=packet_dic[msg[2]][1]
        ant=int(msg[3][-1])
        mode=packet_dic[msg[2]][0]
        Evm_top=packet_dic[msg[2]][5]
        ni_bw=packet_dic[msg[2]][2] 
        ni_mode=packet_dic[msg[2]][6]
        mcs=packet_dic[msg[2]][8] 
        mode_bw=int(bwide)+int(mode)
        channel=int(msg[1])
        gain=['0']*int(chip_type[4])
        for key,value in chip_type[3][0].iteritems():
            if str(channel) in value[0]:
                cal_pwr=float(key)
        for times in xrange(10):
            try:
               gain_code=lWaitCmdTerm(term,"iw %s e2p get calib %d %d"%(chip_type[1],ant,channel),promp,5)
               gain_code=int(gain_code.split('parsed %d'%channel)[-1].split('root')[0].strip()); #print gain_code
               break
            except:
               if times==9: raise Except ("FAIL - TX%d gain get error (%s)"%(ant, gain_code))
               else: continue 
        gain[ant]=str(gain_code); #print gain
        gain_str=' '.join(gain); #print gain_str 

        if chip_type[0] is 'cl2432':
               if bwide: rfFreqMHz = int(chip_type[2][0])+((int(channel)+2)-1)*5; #print rfFreqMHz
               else: rfFreqMHz = int(chip_type[2][0])+(int(channel)-1)*5; #print rfFreqMHz
        elif chip_type[0] is 'cl2430': rfFreqMHz = int(chip_type[2][0])+(int(channel)-36)*5; #print rfFreqMHz 
        TargetPower_Offset = Tx_Power_Offset[cal_freq]  
          
        cable_loss = SearchPathLossTable(AntChOffsetTab,ant,channel); #print cable_loss 
        cable_compensation = cable_loss + connector_loss[int(msg[3].strip()[-1])][cal_freq]         
        extAttenDb=cable_compensation

        '''
        if mode==0:
            mcs=3
            Verify_Power=cal_pwr
            rfAmplDb=Verify_Power+3-extAttenDb+5 #target power + Pk_Avg -cableloss + range
        elif mode==1:
            Verify_Power=cal_pwr
            rfAmplDb=Verify_Power+10-extAttenDb+5
            mcs=7 
        elif mode==2:
            Verify_Power=cal_pwr
            rfAmplDb=Verify_Power+10-extAttenDb+5
            mcs=7 
        else:
            Verify_Power=cal_pwr
            rfAmplDb=Verify_Power+10-extAttenDb+5
            if  packet_dic[msg[2]][0] == 4: mcs = 9 
            else: mcs=7
        '''
        if len(msg)>4:
            Verify_Power=float(msg[4])
            '''
            gain_offset=abs(float(cal_pwr)-int(Verify_Power))
            if not mode:
               if Verify_Power>=cal_pwr: adj_gain_code=(int(gain_code)-9)+int(gain_offset*2)
               else: adj_gain_code=(int(gain_code)-9)-int(gain_offset*2)
            else:
               if Verify_Power>=cal_pwr: adj_gain_code=int(gain_code)+int(gain_offset*2)
               else: adj_gain_code=int(gain_code)-int(gain_offset*2)
            gain[ant]=str(adj_gain_code); print gain
            gain_str=' '.join(gain); print gain_str
            '''   
        else: Verify_Power=cal_pwr

        parent.SendMessage(dut_id,"\n%d.%s , Path Loss: %.2f + %.2f"%(i,print_flow[cal_freq][i],cable_loss,connector_loss[int(msg[3][-1])][cal_freq]),log,uart=term)
        parent.SendMessage(dut_id,"----------------------------------------------------------------------------------------------------",log,uart=term)
        parent.SendMessage(dut_id,"freqOffset=%s | Cal_gain=%s | GainWord=%s"%(freqOffset,gain_code,gain[ant]),log,uart=term)
        msg = print_flow[cal_freq][i].split("\t")
        msg_log = "%s, ch%s, %s, %s, "%(msg[0].strip(),msg[1].strip(),msg[2].strip(),msg[3].strip())         
        ALENgth=150
        #ni.RFSAConfig(rfFreqMHz,compensation,"BW20",chip_type[3][3][1],0,float(cal_pwr),"ON","OFF",ALENgth)
        ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode,0,Verify_Power,'ON','OFF')
        while retry_flag and (retryCnt<TX_RETRY_TIMES):            
            NI_testfail=0
            if temp_compensation: lWaitCmdTerm(term,"iw %s cecli temp_loop 1"%chip_type[1],promp,5)
            else: lWaitCmdTerm(term,"iw %s cecli temp_loop 0"%chip_type[1],promp,5)
            cmd_sequential=['stop','stop','start','bw %s'%bwide,'gi 0','mcs %d'%mcs,'mode %s'%mode,'txlen 1536',\
                            'txcnt 10000000','channel %d'%channel,'ant %d'%ant,'TXFREQOFFSET %s'%freqOffset,\
                            'pow %s 0'%gain_str,'txframe','pow %s 0'%gain_str]
            for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)
            retry_flag=0; retryCnt+=1;
            #ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode,0,Verify_Power,fpkt_dic[mode])
            ni.RFSAConfig(rfFreqMHz,cable_compensation,ni_bw,ni_mode,0,Verify_Power,'ON','OFF',ALENgth)
            time.sleep(0.1)
            result=ni.RFSARead(); #print result 
            if not result or int(result["Power"]) == -100:
                NI_testfail=1;retry_flag=1;
                #ALENgth+=(50*retryCnt) 
                #parent.SendMessage(dut_id, "Measure(%d)> %s"%(retryCnt, result),log,color=0,uart=term)
                print '..'
                if retryCnt >=TX_RETRY_TIMES:
                    if run_flow: parent.SendMessage(dut_id, " FAIL - No signal (Chain%s)"%ant,log,color=1,uart=term); retry_flag=1; break
                    else: raise Except ("FAIL - No signal (Chain%s)"%ant)
                continue
                        
            Evm_msg= msg_log + "Evm = %.2f (<= %.2f) dB"%(result["EVM"],Evm_top)
            if result["EVM"]>Evm_top:
                Evm_msg=Evm_msg+"            Fail"
                retry_flag=1                
                
            #result["FreqErr"] =(result["FreqErr"]/rfFreqHz)*1000000
            result["FreqErr"] =(result["FreqErr"]/(rfFreqMHz*1000000))*1000000
            Freq_msg= msg_log + "Freq Err = %.2f (%.2f~%.2f) ppm"%(result["FreqErr"],(FREQ_AVG+FREQ_ERROR_LIMIT),(FREQ_AVG-FREQ_ERROR_LIMIT))            
            if abs(result["FreqErr"]-FREQ_AVG)>FREQ_ERROR_LIMIT:
                Freq_msg=Freq_msg+"            Fail"
                retry_flag=1
                     
            Power_msg= msg_log + "Power = %.2f (%.2f~%.2f) dBm"%(result["Power"],Verify_Power+TargetPower_Offset,Verify_Power-TargetPower_Offset)            
            if abs(result["Power"]-Verify_Power)>TargetPower_Offset:
                final=0
                if retryCnt==TX_RETRY_TIMES-1:
                   final,Power_msg=NIadj.evilsoul(msg_log,result['Power'],Verify_Power,TargetPower_Offset)
                if not final:   
                   Power_msg=Power_msg+"            Fail"
                   retry_flag=1
                
            Mask_msg= msg_log + "Spec Mask = %.2f (%.2f~%.2f) Percent"%(result["Mask"],Mask_top,Mask_low)
            if result["Mask"]<Mask_low or result["Mask"]>Mask_top:
                Mask_msg=Mask_msg+"            Fail"
                retry_flag=1
                
            LO_msg= msg_log + "LO Leakage = %.2f (%.2f~%.2f) dB"%(result["LoLeakage"],LO_Leakage_top,LO_Leakage_low)
            if result["LoLeakage"]<LO_Leakage_low or result["LoLeakage"]>LO_Leakage_top:
                LO_msg=LO_msg+"            Fail"
                retry_flag=1

            #print Spec Flat and LO Leakage
            if mode:
                Flat_msg= msg_log + "Spec Flat = %.2f (%.2f~%.2f) pt"%(result["Flatness"],Flat_top,Flat_low)
                if result["Flatness"]<Flat_low or result["Flatness"]>Flat_top:
                    Flat_msg=Flat_msg+"            Fail"
                    retry_flag=1
                '''    
                LO_msg= msg_log + "LO Leakage = %.3f (%.2f~%.2f) dB"%(result["LoLeakage"],LO_Leakage_top,LO_Leakage_low)
                if result["LoLeakage"]<LO_Leakage_low or result["LoLeakage"]>LO_Leakage_top:
                    LO_msg=LO_msg+"   Fail"
                    retry_flag=1
                '''    
            
            if not retry_flag or retryCnt>=TX_RETRY_TIMES :
                for msg in [Freq_msg,Evm_msg,Power_msg,Mask_msg,LO_msg]:
                    if "Fail" in msg:
                        testfail=1
                        parent.SendMessage(dut_id,msg + "",log,color=1,uart=term)
                    else: parent.SendMessage(dut_id,msg + "",log,color=2,uart=term)
                if mode:
                    for msg in [Flat_msg]:
                        if "FAIL" in msg:
                            testfail=1
                            parent.SendMessage(dut_id,msg + "",log,color=1,uart=term)
                        else: parent.SendMessage(dut_id,msg + "",log,color=2,uart=term)
                if testfail: raise Except ("%s Tx verify FAIL"%chip_type[0])

    if testfail or NI_testfail or not result:
        testfail=1 
        if run_flow: parent.SendMessage(dut_id,"%s Tx verify FAIL"%chip_type[0],log,color=1,uart=term)
        else: raise Except ("%s Tx verify FAIL"%chip_type[0])
    else: parent.SendMessage(dut_id,"%s Tx verify PASS"%chip_type[0],log,color=2,uart=term)
    lWaitCmdTerm(term,"iw %s ATE stop"%(chip_type[1]),promp,5)
    parent.SendMessage(dut_id, "%s Tx verify Test time: %3.2f (sec)"%(chip_type[0],(time.time()- test_time)),log,uart=term)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log,uart=term)
    return testfail   
    
def RxVerify(parent,ni,dut_id,term,chip_type,AntChOffsetTab,cal_freq,log):
    parent.SendMessage(dut_id,"%s Rx verify Start..."%chip_type[0],log,uart=term)
    test_time = time.time()
    testResult=0
    nCnt=0
    for times in xrange(10):
        try:
           freqOffset=lWaitCmdTerm(term,"iw %s e2p get freq_offset"%chip_type[1],promp,5)
           freqOffset=int(freqOffset.split('set')[-1].split('root')[0].strip()); #print freqOffset
           break
        except: 
           if times==9: raise Except ("FAIL - freqoffset get error (%s)"%freqOffset)
           else: continue 
    ver_item=str()
    ver_flow=list()
    print_flow=dict()
    if cal_freq is '2G':
        flag=cl2432_ver_parameter['flag']
        if flag: ver_paramter=cl2432_ver_parameter['RX']
        else: print_flow=manual_flow
    else: 
        flag=cl2430_ver_parameter['flag']
        if flag: ver_paramter=cl2430_ver_parameter['RX']
        else: print_flow=manual_flow
    if flag:
        for channel in ver_paramter[0]:
            for mode in ver_paramter[1]:
                if mode is 'HT40_MCS7' and channel in [10,11,12,13]: continue
                else:
                    for ant in ver_paramter[2]:
                        ver_item="IQ_VERIFY_RX\t%d\t%s\tRX%d"%(channel,mode,ant); #print ver_item
                        ver_flow.append(ver_item)
        print_flow={cal_freq:ver_flow}
    #print print_flow  
    
    for i in range(len(print_flow[cal_freq])):
        msg = print_flow[cal_freq][i].split("\t") 
        if "TX" in msg[0]: continue                
        bwide=packet_dic[msg[2]][1]
        ant=int(msg[3][-1])
        mode=packet_dic[msg[2]][0]
        Evm_top=packet_dic[msg[2]][5]
        ni_bw=packet_dic[msg[2]][2] 
        ni_mode=packet_dic[msg[2]][6] 
        mode_bw=int(bwide)+int(mode)
        ni_rate=packet_dic[msg[2]][7]
        channel=int(msg[1])
        mcs=packet_dic[msg[2]][8] 
        perLimit=packet_dic[msg[2]][4]
        cable_loss=SearchPathLossTable(AntChOffsetTab,ant,channel); #print cable_loss 
        cable_compensation=cable_loss+connector_loss[int(msg[3][-1])][cal_freq]
        nCnt+=1
        if mode == 2: 
            rx_mode = int(mode)+int(bwide); 
            #mcs=int(msg[2].split('_')[-1][-1])
        elif mode == 3: 
            rx_mode = int(mode)+int(bwide)-1; 
            #mcs=int(msg[2].split('_')[-1][-1])
        else: 
            rx_mode = int(mode)
            #if rx_mode == 0: mcs = 3
            #else:  mcs = 7
        

        if channel > 15: 
            rfFreqHz=(5180+(channel-36)*5)*1000000
            rfFreqMHz = (5180+(channel-36)*5)     
        else:               
            rfFreqHz=(2412+(channel-1)*5)*1000000
            rfFreqMHz = (2412+(channel-1)*5) 
        
        inputPwr = rfPower_dic[rx_mode][mcs]
        SweepTest=0
        if (len(msg) == 6): 
          SweepTest=1      
          sweepPwr=msg[4].split("~"); #print msg[4]; #raw_input('aaa')
          inputPwr=int(sweepPwr[0])
          sweepStep=int(msg[5])

        cmd_sequential=['stop','start','rx_mode %s'%mode,'bw %s'%bwide,'gi 0','mcs %d'%mcs,'mode %s'%mode,\
                        'channel %d'%channel,'ant %d'%ant,'TXFREQOFFSET %s'%freqOffset,'stat reset','stat']
        for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)        

        testItem = "%s , ch%s , %s , %s , "%(msg[0].strip(),msg[1].strip(),msg[2].strip(),msg[3].strip())  
        while True:   #SweepTest          
          parent.SendMessage(dut_id, "%d.%s InputPwr: %.1f, Path Loss: %.2f + %.2f"%(nCnt, testItem, inputPwr, cable_loss,connector_loss[int(msg[3][-1])][cal_freq]),log,uart=term)
          parent.SendMessage(dut_id,"----------------------------------------------------------------------------------------------------",log,uart=term)
          retryCnt=0; failCnt=0;
          interval=str(0.0001)
          while retryCnt<RX_RETRY_TIMES and failCnt<RX_RETRY_TIMES:
            MAC_hex=int('0x110000C0FFEE',16)+int(i)+int(failCnt)
            MAC=str(hex(MAC_hex)[:-1]); #print MAC
            if failCnt: interval= str(float(interval)+0.0002)
            if chip_type[0] is 'cl2432':
               if bwide: rfFreqMHz = int(chip_type[2][0])+((int(channel)+2)-1)*5
            lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd_sequential[-2]),promp,5)
            ni.RFGenerate(int(rfFreqMHz), cable_compensation, ni_bw, ni_mode, ni_rate, inputPwr,1000,MAC,interval)
            time.sleep((packet_dic[msg[2]][3]+0.5))
            try:
              data=lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd_sequential[-1]),promp,5)
              result=int(data.split('Rx success=')[-1].split('RSSI')[0].strip()); #print 'result:%d'%result
              if result>=1000: result=1000
              Per=((1000-result)/1000.0)*100.0               
              strPer="%s PER = %.3f (%.1f ~ 0.0) Percent"%(msg[3], Per, perLimit)   
            except ValueError:
              retryCnt+=1
              strPer="-%s : Fail to get the 'Stat'"%msg[3]
              parent.SendMessage(dut_id, "-%d: error to get the %s state"%(retryCnt,msg[3]),log,uart=term)
              continue              
            if Per > perLimit:
              failCnt+=1
              strPer += "     Fail"
              parent.SendMessage(dut_id, "-Rty%d: Packetloss PER: %.3f"%(failCnt,Per),log,uart=term)           
              cmd_sequential=['stop','start','rx_mode %s'%mode,'bw %s'%bwide,'gi 0','mcs %d'%mcs,'mode %s'%mode,\
                              'channel %d'%channel,'ant %d'%ant,'TXFREQOFFSET %s'%freqOffset,'stat reset','stat']
              for cmd in cmd_sequential: lWaitCmdTerm(term,"iw %s ATE %s"%(chip_type[1],cmd),promp,5)    
            else: break

          if "Fail" in strPer: 
            if run_flow: testResult=1; parent.SendMessage(dut_id, "%s"%strPer,log,color=1,uart=term)
            else: raise Except ("%s"%strPer)
          else: 
          	parent.SendMessage(dut_id, "%s"%strPer,log,color=2,uart=term); testResult=0
            
          if SweepTest:
            if abs(inputPwr) >= abs(int(sweepPwr[1])): break
            inputPwr-=sweepStep
          else: break
        
    if testResult:
        if run_flow: parent.SendMessage(dut_id,"%s Rx verify FAIL"%chip_type[0],log,color=1,uart=term)
        else: raise Except ("%s Rx Verify FAIL..."%chip_type[0])
    else: parent.SendMessage(dut_id,"%s Rx verify PASS"%chip_type[0],log,color=2,uart=term)
    parent.SendMessage(dut_id, "%s Rx Verify Test time: %3.2f (sec)"%(chip_type[0],(time.time()- test_time)),log,uart=term)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log,uart=term)   
    return testResult

def getmac(mac):
    ServerIP = '127.0.0.1'
    ServerPort = 1800
    timeout = 30
    sn = ""
    MesSocket=htx.UDPService(ServerIP,int(ServerPort),int(timeout))
    MesSocket.set('2,' + mac)  
    Result=MesSocket.get()
    print Result
    Result=Result.strip()
    if Result:
       if len(Result)<>12 or Result[0] == '2':
          raise Except("ErrorCode(0005):Get MAC Failed:%s"%Result)
       else:
          sn = Result
          return sn
    raise Except("ErrorCode(0005):Connection MES Server Fail ")

def LinkPing(ip,count):
    #print ip
    result = os.popen('ping -w 1000 -n %d %s'%(count,ip)).read()
    return float(result[result.rfind("(")+1:result.rfind("%")])

def IsConnect(ip,timeout):
    ip = ip.strip()
    current = time.time()
    timeout += current
    os.popen("arp -d")
    while current < timeout:
        rate = LinkPing(ip,3)
        if rate == 0: return 1 
        time.sleep(1)                             
        current = time.time()
    return 0

def IsDisconnect(ip,timeout):
    ip = ip.strip()
    current = time.time()
    timeout += current
    os.popen("arp -d")
    while current < timeout:
        rate = LinkPing(ip,3)
        if rate == 100: return 1  
        time.sleep(1)
        current = time.time()
    return 0

def getSelfAddr():
    ip = socket.gethostbyname_ex(socket.gethostname())
    for i in ip[-1]:
       if '172.28.' in i:
          return i
    return 0


def Poweroffset(parent,dut_id,term,offset_table,log):
    parent.SendMessage(dut_id,"Setup Power offset table",log,uart=term)
    test_time=time.time()
    failflag=0
    for retry in range(3):
      for band in xrange(3):
        if not failflag:
          parent.SendMessage(dut_id,"SET [%s]:%s"%(offset_table[band][0],offset_table[band][1]),log,uart=term)
          lWaitCmdTerm(term,"nvram_set %s %s"%(offset_table[band][0],offset_table[band][1]),promp,5)        
      for band_ in xrange(3):
        data=lWaitCmdTerm(term,"nvram_get %s"%(offset_table[band_][0]),promp,5)
        table=''.join(offset_table[band_][1].split("\\"))
        if table in data: failflag=0; parent.SendMessage(dut_id,"GET [%s]:%s"%(offset_table[band_][0],data),log,uart=term)
        else: failflag=1; break
      if not failflag: break
      elif retry == 2: raise Except("FAIL: Poweroffset setup Fail >> [%s]:%s"%(offset_table[band_][0],data)) 
    parent.SendMessage(dut_id, "Power Offset setup time: %3.2f (sec)"%(time.time()-test_time),log,uart=term)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log,uart=term)
    return 1

def USBTest_ONE(parent,val,term,log):
    parent.SendMessage(val,"USB2.0 Test...............",log)   
    for d in range(10):
        mount_data = lWaitCmdTerm(term,"mount","#",5) 
        #if not '/tmp/mnt/diska1' in data or not "/tmp/mnt/diskb1" in data:
        if not '/tmp/mnt/diska1' in mount_data:
            time.sleep(1)
            if d==9:
               print mount_data  
               raise Except("USB Mount FAIL.")
        else:
            print mount_data  
            break
    
    parent.SendMessage(val,"%s"%mount_data,log)      
    term.get()
    data1 = lWaitCmdTerm(term,"ls /tmp/mnt/diska1","#",5,3)
    #data2 = lWaitCmdTerm(term,"ls /tmp/mnt/diskb1","#",5,3)
    
    #if not 'test.txt' in data1 or not 'test.txt' in data2:
    if not 'test.txt' in data1:    
        raise Except("Check USB2.0 Content FAIL.")
    else:
        parent.SendMessage(val,"Check USB2.0 content PASS",log)

def USBTest(parent,dut_id,term,log):
    parent.SendMessage(dut_id,"USB2.0 Test...",log,uart=term)   
    test_time=time.time()
    while time.time()-test_time<10:
        #data=lWaitCmdTerm(term,"mount","/mnt/diska1",5); print data
        term.get()
        term<<'mount'
        time.sleep(0.5)
        data=term.get(); print data
        if 'tmp/mnt/diska1' not in data: flag=0; time.sleep(1) 
        else:
           wr=lWaitCmdTerm(term,"echo 'MFGUSBTEST' > /tmp/mnt/diska1/test.txt && tail -n 1 /tmp/mnt/diska1/test.txt","#",5,3); print wr
           d=lWaitCmdTerm(term,'rm -f /tmp/mnt/diska1/test.txt && tail -n 1 /tmp/mnt/diska1/test.txt',"#",15,3); print d
           if 'MFGUSBTEST' in wr and 'MFGUSBTEST' not in d: 
              parent.SendMessage(dut_id,"%s\n%s\nUSB test pass"%(wr,d),log,uart=term)
              parent.SendMessage(dut_id, "USB test time: %3.2f (sec)"%(time.time()-test_time),log,uart=term)
              parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log,uart=term)
              return 1
           else: flag=1; time.sleep(1)
    if not flag: raise Except('USB mount fail:%s'%data)
    else: raise Except('USB R/W fail:%s'%wr)

def SetupMAC(parent,dut_id,chip,rfmac,rule,term,log):
    parent.SendMessage(dut_id," Setup %s WIFI MAC... "%chip[0],log,uart=term)
    test_time=time.time()
    mac = "%012X"%(int(rfmac,16)+int(rule))
    wifimac = mac[0:2]+":"+mac[2:4]+":"+mac[4:6]+":"+mac[6:8]+":"+mac[8:10]+":"+mac[10:12]
    lWaitCmdTerm(term,"iw %s e2p set mac %s"%(chip[1],wifimac),"#",5,2)
    term.get()
    data=lWaitCmdTerm(term,"iw %s e2p get mac"%(chip[1]),"#",5,2)
    if wifimac.lower() not in data: raise Except('Fail: %s set mac'%chip[0])
    parent.SendMessage(dut_id,"%s"%data ,log,uart=term) 
    parent.SendMessage(dut_id, "WIFI MAC setup time: %3.2f (sec)"%(time.time()-test_time),log,uart=term)
    parent.SendMessage(dut_id, "---------------------------------------------------------------------------",log,uart=term)
    
def W11(parent):
    try:
        #global init2G_flag; print init2G_flag
        #global init5G_flag; print init5G_flag
        term=0
        val = parent.id_ 
        result = 0
        log = None
        th_lock = False
        mac = str()
        parent.SendMessage(val,"START",state = "START")
        start_time = end_time = 0
        term =htx.SerialTTY("com1",115200)
        mac = GetMacAddress(parent)
        mac =mac.strip().upper()
        if mac[0]=="2":mac=getmac(mac)
        if mac[:3] <> 'F81' or len(mac) <> 12:
            raise Except("Mac scan Fail!") 
        #sn = GetSN(parent) 
        log = open(logPath+mac+".w11","w")
        checktravel(mac,'127.0.0.1',1800,30)
        t= str(round(time.time(),1)).split(".")
        #log = open(logPath+mac+"_%s%s.w11"%(t[0][7:],t[1]),"w")        
        start_time=time.time()
        parent.SendMessage(val,"Celeno WIFI Calibration loop test program version: %s , Station: %s"%(version,Test_station),log)
        parent.SendMessage(val,"---------------------------------------",log)
        parent.SendMessage(val,"Start Time:"+time.ctime()+"",log)
        parent.SendMessage(val,"Scan MAC address:"+mac+"",log)
        #parent.SendMessage( "Scan SN:"+sn+"",log)
        parent.SendMessage(val, "---------------------------------------------------------------------------",log)
        station_ip = getSelfAddr()
        msg = "station_ip=%s"%(station_ip)
        parent.SendMessage(val,"%s"%msg,log)
        
        if not IsConnect('%s'%NI_ip,20):
            raise Except("FAIL: Connect NI Fail")     
                    
        ni = WTS(NI_ip,((val-1) + (wts_station-1)*4)) 
        data=ni.Init()
        parent.SendMessage(val, "%s"%data,log)
        for run in xrange(1,2,1):
            #parent.SendMessage(val,"----------------Run%d-----------------"%run,log)
            internal_test_time=time.time()
            try:
                WaitBoot(parent,val,term,log)
                USBTest_ONE(parent,val,term,log)
                Reset_file(parent,val,term,log)
                Poweroffset(parent,val,term,productin_offset_table,log)
                InitWifiProduction(parent,val,term,log)
                for i in cal_freq:          
                    AntChOffsetTab = ReadCompensation("PathLoss_%s_3T3R_%d"%(i, val),"C:\\WiFi_CableLoss")
                    if FREQ_CAL: FreqCalibrate(parent,ni,val,term,chip_list[i],AntChOffsetTab,freq_offset,log)            
                    if TX_CAL: result+=CalTxPower(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
                    if TX_VERIFY: result+=TxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
                    if RX_VERIFY: result+=RxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log)                                      
                if OFFSET_TABLE: Poweroffset(parent,val,term,shipping_offset_table,log)
                parent.SendMessage(val,"Round%s >> total test time: %3.2f sec"%(run,(time.time()-internal_test_time)),log)
                #Bridge_up(parent,val,arm,log)
                #Telnet_arm(parent,val,arm,log)
                #time.sleep(30)              
            except Except,msg: 
                parent.SendMessage(val,"%s"%msg,log,color=1)
                #Bridge_up(parent,val,arm,log)
                #Telnet_arm(parent,val,arm,log)
                #time.sleep(30); 
                result=1; continue
    except Except,msg:
        parent.SendMessage(val,"%s"%msg,log,color=1)
        result = 1               
    except: 
        parent.SendMessage(val,"%s"% traceback.print_exc(),log,color=1)
        result = 1
        term = 0

    end_time = time.time()
    parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
    parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log)
    if result:
       parent.SendMessage(val,"Test Result: FAIL"+'',log,color=1)
       if not keepalive: Telnet_arm(parent,val,arm,log); #term<<'reboot'
    else:
       parent.SendMessage(val,"Test Result: PASS"+'',log,color=2)
       #Bridge_up(parent,val,arm,log)
       #Telnet_arm(parent,val,arm,log)
    if log:
        log.close()        
        oriFile = logPath+mac+".w11"
        if (not result): newFile = oriFile+"-pass"
        else: newFile = oriFile+"-fail"
        #newFile += time.strftime("%M-%S"%time.localtime())
            
        #os.rename(oriFile, newFile)
            
    #if term: term.close()
    term=None
    if mac: 
       travel = passtravel(mac,'127.0.0.1',1800,30)
       if travel or result:
       #if result:
          parent.SendMessage(val,'',state = "FAIL",color=1)
       else:
          parent.SendMessage(val, "",state = "PASS")   
    else: parent.SendMessage(val,"",state = "FAIL")  

def W11(parent):
    try:
        val = parent.id_ 
        result = 0
        log = None
        th_lock = False
        mac = str()
        parent.SendMessage(val,"START",state = "START")
        start_time = end_time = 0
        term =htx.SerialTTY("com9",115200)
        mac = GetMacAddress(parent)
        mac = mac.strip().upper()
        '''
        if mac[0]=="2":mac=getmac(mac)
        if mac[:3] <> 'F81' or len(mac) <> 12:
            raise Except("Mac scan Fail!") 
        '''
        #sn = GetSN(parent) 
        #log = open(logPath+mac+".w11","w")
        #checktravel(mac,'127.0.0.1',1800,30)
        t= str(round(time.time(),1)).split(".")
        log = open(logPath+mac+"_%s%s.w11"%(t[0][7:],t[1]),"w")        
        start_time=time.time()
        
        #station_ip = getSelfAddr()
        #msg = "station_ip=%s"%(station_ip)
        #parent.SendMessage(val,"%s"%msg,log)
        
        #if not IsConnect('%s'%NI_ip,20):
            #raise Except("FAIL: Connect NI Fail")         
        ni = WTS(NI_ip,((val-1) + (wts_station-1)*4))
        ni.Init()            
        
        if WaitBoot(parent,val,mac,term,log): raise Except ('!!-- wifi interface up, please power cycle DUT --!!')
        USBTest(parent,val,term,log)
        for i in cal_freq:
            if cal_mode: Reset_file(parent,val,term,i,log)
            Poweroffset(parent,val,term,productin_offset_table,log)
            InitWifiProduction(parent,val,chip_list[i],term,log)
            AntChOffsetTab = ReadCompensation("PathLoss_%s_3T3R_%d"%(i, val),"Station.Cal")
            if SET_MAC: SetupMAC(parent,val,chip_list[i],mac,offset,term,log)
            if FREQ_CAL: FreqCalibrate(parent,ni,val,term,chip_list[i],AntChOffsetTab,freq_offset,log)            
            if TX_CAL: result+=CalTxPower(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
            if TX_VERIFY: result+=TxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
            if RX_VERIFY: result+=RxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log)                                      
        if OFFSET_TABLE: Poweroffset(parent,val,term,shipping_offset_table,log)                         
    except Except,msg:
        parent.SendMessage(val,"%s"%msg,log,color=1)
        result = 1               
    except: 
        parent.SendMessage(val,"%s"% traceback.print_exc(),log,color=1)
        result = 1
        term = None

    end_time = time.time()
    parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
    parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log)
    if result:
       parent.SendMessage(val,"Test Result: FAIL"+'',log,color=1)
       if not keepalive: Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8 #Telnet_arm(parent,val,arm,log); #term<<'reboot'
    else:
       parent.SendMessage(val,"Test Result: PASS"+'',log,color=2)
    if log:
        log.close()        
        oriFile = logPath+mac+".w11"
        if (not result): newFile = oriFile+"-pass"
        else: newFile = oriFile+"-fail"
        #newFile += time.strftime("%M-%S"%time.localtime())
            
        #os.rename(oriFile, newFile)
            
    #if term: term.close()
    term=None
    if mac: 
       #travel = passtravel(mac,'127.0.0.1',1800,30)
       #if travel or result:
       if result:
          parent.SendMessage(val,'',state = "FAIL",color=1)
       else:
          parent.SendMessage(val, "",state = "PASS")   
    else: parent.SendMessage(val,"",state = "FAIL") 

#F81D0F253B46
def W11_retest_opt(parent):
    try:
        val = parent.id_ 
        result = 0
        log = None
        th_lock = False
        mac = str()
        rcd=None
        parent.SendMessage(val,"START",state = "START")
        #start_time = end_time = 0
        start_time=time.time()
        #term =SerialTTY("com1",b_rate)
        term =htx.SerialTTY(comport[0],b_rate)
        mac = GetMacAddress(parent)
        mac = mac.strip().upper()
        
        if mac[0]=="2":mac=getmac(mac)
        if len(mac) <> 12:
            raise Except("Mac scan Fail!") 
        
        #sn = GetSN(parent) 
        log = open(logPath+mac+".w11","w")
        #checktravel(mac,'127.0.0.1',1800,30)
        start_time=time.time()
        station_ip = getSelfAddr()
        msg = "station_ip=%s"%(station_ip)
        parent.SendMessage(val,"%s"%msg,log)
        if not IsConnect('%s'%NI_ip,20):
            raise Except("FAIL: Connect NI Fail")         
        ni = WTS(NI_ip,((val-1) + (wts_station-1)*4))
        ni.Init()

        flow=R_Flow(term)

        test_function={'USB':'USBTest(parent,val,term,log)',\
                       'OFFSET_TABLE':'Poweroffset(parent,val,term,shipping_offset_table,log)'}      
        if WaitBoot(parent,val,mac,term,log): raise Except ('wifi interface up, please power cycle DUT')
        #term<<"rm /nvram/w11mfgrcd"
        term<<"find /nvram -name 'w11*' -delete"
        time.sleep(0.3)
        #term<<"rm /nvram/w11mfgrcd"
        term<<"find /nvram -name 'w11*' -delete"
        rcd=flow.GetMfgRecord(term)
        for idx,item in enumerate(test_item):
            if flow.ChkMfgRecord(rcd,idx): continue
            if item is '2G' or item is '5G':
                AntChOffsetTab=ReadCompensation("PathLoss_%s_3T3R_%d"%(item, val),"C:\\WiFi_CableLoss")
                sub_item_toogle=flow.GetSubRcd(term,item); print sub_item_toogle; #raw_input('hold')
                if sub_item_toogle['cal_mode']: Reset_file(parent,val,term,item,log)
                #Poweroffset(parent,val,term,productin_offset_table,log)
                InitWifiProduction(parent,val,chip_list[item],term,log)
                if sub_item_toogle['FREQ_CAL']: FreqCalibrate(parent,ni,val,term,chip_list[item],AntChOffsetTab,freq_offset,log)            
                if sub_item_toogle['TX_CAL']: result=CalTxPower(parent,ni,val,term,chip_list[item],AntChOffsetTab,item,log) 
                if sub_item_toogle['TX_VERIFY']: result=TxVerify(parent,ni,val,term,chip_list[item],AntChOffsetTab,item,log)
                if not result:
                    flow.SetSubRcd(term,sub_item_toogle,item,'cal_mode')
                    flow.SetSubRcd(term,sub_item_toogle,item,'FREQ_CAL')
                    flow.SetSubRcd(term,sub_item_toogle,item,'TX_CAL')
                    flow.SetSubRcd(term,sub_item_toogle,item,'TX_VERIFY')
                if sub_item_toogle['RX_VERIFY']: result=RxVerify(parent,ni,val,term,chip_list[item],AntChOffsetTab,item,log)
                if not result:
                    flow.SetSubRcd(term,sub_item_toogle,item,'RX_VERIFY')
                if sub_item_toogle['SET_MAC']: SetupMAC(parent,val,chip_list[item],mac,mac_rule[item],term,log)
                if not result: flow.SetMfgRecord(term,rcd,idx)
            else: 
                toogle=eval(test_function[item]) 
                if toogle: flow.SetMfgRecord(term,rcd,idx)        
        flow.SaveRcdLog(term,rcd)        
    except Except,msg:
        parent.SendMessage(val,"%s"%msg,log,color=1,uart=term)
        flow.SaveRcdLog(term,rcd)
        result = 1               
    except: 
        parent.SendMessage(val,"%s"% traceback.print_exc(),log,color=1,uart=term)
        flow.SaveRcdLog(term,rcd)       
        result = 1
        #term=None
    end_time = time.time()
    parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log,uart=term)
    parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log,uart=term)
    if result:
       parent.SendMessage(val,"Test Result: FAIL"+'\n',log,color=1)
       if not keepalive: Telnet_arm(parent,val,arm,log); #term<<'reboot'
    else:
       parent.SendMessage(val,"Test Result: PASS"+'\n',log,color=2)
       #Bridge_up(parent,val,arm,log)
       #Telnet_arm(parent,val,arm,log)
    if log:
        log.close()        
        oriFile = logPath+mac+".w11"
        if (not result): newFile = oriFile+"-pass"
        else: newFile = oriFile+"-fail"
        #newFile += time.strftime("%M-%S"%time.localtime())
            
        #os.rename(oriFile, newFile)
            
    if term: term.close()
    if mac: 
       travel = passtravel(mac,'127.0.0.1',1800,30)
       if travel or result:
       #if result:
          parent.SendMessage(val,'\n',state = "FAIL",color=1)
       else:
          parent.SendMessage(val, "",state = "PASS")   
    else: parent.SendMessage(val,"",state = "FAIL")  

def W11_loop(parent):
    term=0
    arm_term=0
    val = parent.id_ 
    result = 0
    log = None
    th_lock = False
    mac = str()
    parent.SendMessage(val,"START",state = "START")
    term =htx.SerialTTY("com1",b_rate)
    #arm_term =htx.SerialTTY(comport[0],b_rate)
    mac = GetMacAddress(parent)
    mac =mac.strip().upper()
    ni = WTS(NI_ip,((val-1) + (wts_station-1)*4))
    ni.Init()            
    #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
    #time.sleep(20); 
    for run in xrange(1):
        result = 0
        parent.SendMessage(val,"START",state = "START")
        run=str(run)
        log = open(logPath+run+".w11","w")
        clog = open(logPath_check+run+".check","w")
        file=logPath+run+'.w11'
        file_c=logPath_check+run+'.check'
        start_time = end_time = 0
        start_time=time.time()
        parent.SendMessage(val,"----------------Run%s-----------------"%run,log)
        parent.SendMessage(val,"Celeno WIFI Calibration loop test program version: %s , Station: %s"%(version,Test_station),log)
        parent.SendMessage(val,"---------------------------------------",log)
        parent.SendMessage(val,"Start Time:"+time.ctime()+"",log)
        parent.SendMessage(val,"Scan MAC address:"+mac+"",log)
        parent.SendMessage(val, "---------------------------------------------------------------------------",log)
        internal_test_time=time.time()
        try:
            case=0
            while True:
              if WaitBoot(parent,val,mac,term,log): 
                 #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
                 Snmp.SnmpSet("192.168.10.254","1.3.6.1.4.1.26104.3.3.3.1.5.1","i",3,community="public")
                 time.sleep(30); 
                #raise Except ('!!-- wifi interface up, please power cycle the DUT --!!')
              else: break
            #USBTest(parent,val,term,log)
            for i in cal_freq:
                if cal_mode: Reset_file(parent,val,term,i,log)
                #Poweroffset(parent,val,term,productin_offset_table,log)
                InitWifiProduction(parent,val,chip_list[i],term,log)
                SetupMAC(parent,val,chip_list[i],mac,offset,term,log)
                AntChOffsetTab = ReadCompensation("PathLoss_%s_3T3R_%d"%(i, val),"Station.Cal")
                if FREQ_CAL: FreqCalibrate(parent,ni,val,term,chip_list[i],AntChOffsetTab,freq_offset,log)            
                if TX_CAL: result+=CalTxPower(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
                if TX_VERIFY: result+=TxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log) 
                if RX_VERIFY: result+=RxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,log)                                      
                #Poweroffset(parent,val,term,shipping_offset_table,log)
            parent.SendMessage(val,"Round%s >> total test time: %3.2f sec"%(run,(time.time()-internal_test_time)),log)
            if not result: 
                parent.SendMessage(val,'',state = "PASS"); parent.SendMessage(val,"Test Result: PASS"+'',log,color=2)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log)
            else: 
                parent.SendMessage(val,'',state = "FAIL"); parent.SendMessage(val,"Test Result: FAIL"+'',log,color=1) 
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log) 
            log.close()
            if not result: 
               update_file=logPath+run+'_PASS.W11'
               os.rename(file,update_file+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')               
            else: 
               update_file=logPath+run+'_Fail.W11'
               os.rename(file,update_file+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')
            #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
            Snmp.SnmpSet("192.168.10.254","1.3.6.1.4.1.26104.3.3.3.1.5.1","i",3,community="public")
            #arm_term << 'reboot'
            time.sleep(30)
            result = 0
            parent.SendMessage(val,"START",state = "START")
            parent.SendMessage(val,"----------------Run%s-----------------"%run,clog)
            parent.SendMessage(val,"Celeno WIFI Calibration loop test program version: %s , Station: check"%(version),clog)
            parent.SendMessage(val,"---------------------------------------",clog)
            parent.SendMessage(val,"Start Time:"+time.ctime()+"",clog)
            parent.SendMessage(val,"Scan MAC address:"+mac+"",clog)
            parent.SendMessage(val, "---------------------------------------------------------------------------",clog)
            internal_test_time=time.time()
            start_time = end_time = 0
            start_time=time.time()
            case=1
            while True:
              if WaitBoot(parent,val,mac,term,clog):
                 #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
                 Snmp.SnmpSet("192.168.10.254","1.3.6.1.4.1.26104.3.3.3.1.5.1","i",3,community="public")
                 time.sleep(30); 
                 #raise Except ('!!-- wifi interface up, please power cycle the DUT --!!')
              else: break
            for i in cal_freq:
                InitWifiProduction(parent,val,chip_list[i],term,clog)
                AntChOffsetTab = ReadCompensation("PathLoss_%s_3T3R_%d"%(i, val),"C:\\WiFi_CableLoss")
                if TX_VERIFY: result+=TxVerify(parent,ni,val,term,chip_list[i],AntChOffsetTab,i,clog) 
            parent.SendMessage(val,"Round%s >> total test time: %3.2f sec"%(run,(time.time()-internal_test_time)),clog)
            #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
            #time.sleep(20)
            if not result: 
                parent.SendMessage(val,'',state = "PASS"); parent.SendMessage(val,"Test Result: PASS"+'',clog,color=2)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',clog)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',clog)       
            else: 
                parent.SendMessage(val,'',state = "FAIL"); parent.SendMessage(val,"Test Result: FAIL"+'',clog,color=1)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',clog)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',clog)
            clog.close()            
            if not result:
               update_file_check=logPath_check+run+'_PASS.check'
               os.rename(file_c,update_file_check+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')
            else:
               update_file_check=logPath_check+run+'_Fail.check' 
               os.rename(file_c,update_file_check+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')
            #arm_term << 'reboot'
            #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
            Snmp.SnmpSet("192.168.10.254","1.3.6.1.4.1.26104.3.3.3.1.5.1","i",3,community="public")
            time.sleep(30)
        except Except,msg: 
            #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
            Snmp.SnmpSet("192.168.10.254","1.3.6.1.4.1.26104.3.3.3.1.5.1","i",3,community="public")
            #time.sleep(20);
            parent.SendMessage(val,'',state = "FAIL")
            result=1
            if not case: 
                parent.SendMessage(val,"%s"%msg,log,color=1)
                parent.SendMessage(val,"Test Result: FAIL"+'',log,color=1)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',log)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',log)
                log.close()
                update_file=logPath+run+'_Fail.W11'
                os.rename(file,update_file+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')
                msg='Notesting'
                parent.SendMessage(val,"%s"%msg,clog,color=1)
                parent.SendMessage(val,"Test Result: FAIL"+'',clog,color=1)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',clog)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',clog)       
                clog.close()
                update_file_check=logPath_check+run+'_Fail.check'
                os.rename(file_c,update_file_check+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')                
            else:
                parent.SendMessage(val,"%s"%msg,clog,color=1)
                parent.SendMessage(val,"Test Result: FAIL"+'',clog,color=1)
                end_time = time.time()
                parent.SendMessage(val,''+"End Time:"+time.ctime()+'',clog)
                parent.SendMessage(val,"Total Test Time: %3.1fs"%(end_time-start_time)+'',clog)       
                clog.close()
                update_file_check=logPath_check+run+'_Fail.check'
                os.rename(file_c,update_file_check+'('+time.strftime("%H'%M'%S',%Y-%m-%d",time.localtime())+')')
                #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
                #if not keepalive: arm_term << 'reboot'
            #arm_term << 'reboot'
            #Snmp.SnmpSet("192.168.1.10","1.3.6.1.4.1.26104.1.1.1.5.1.24","i",3,community="public")  #.24 #Power 1 , .25 Power 2, .31 power 8
            time.sleep(20); 
            
    if not result: parent.SendMessage(val,'',state = "PASS")
    term=None
    arm_term=None
